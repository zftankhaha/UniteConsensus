//
//  KYCViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/21.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "KYCViewCell.h"

@implementation KYCViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        WEAKSELF
        self.actionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.actionButton.frame = CGRectMake(30,10,SCREEN_WIDTH-60,KYCViewCellHeight-20);
        self.actionButton.backgroundColor = [UIColor clearColor];
        self.actionButton.titleLabel.font = CommonFontRegular(17.0f);
        [self.actionButton setTitleColor:kBackBColor forState:UIControlStateNormal];
        self.actionButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.actionButton actionForButton:^(UIButton *button)
        {
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(clickPickerAction:)])
            {
                [weakSelf.delegate clickPickerAction:weakSelf];
            }
        }];
        self.actionButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        [self.contentView addSubview:self.actionButton];
    }
    
    return self;
}

@end
