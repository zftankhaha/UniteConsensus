//
//  LastViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/28.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "KYCViewController.h"

@interface LastViewController : KYCViewController

@end
