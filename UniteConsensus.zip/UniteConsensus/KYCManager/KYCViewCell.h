//
//  KYCViewCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/21.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

#define KYCViewCellHeight   110

@protocol KYCViewCellDelegate <NSObject>

- (void)clickPickerAction:(id)myCell;

@end

@interface KYCViewCell : UITableViewCell

@property (nonatomic,weak) id delegate;

@property (nonatomic,strong) UIButton *actionButton;

@end
