//
//  LastViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/28.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "LastViewController.h"

@interface LastViewController ()

@end

@implementation LastViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"支付宝认证";
}

- (void)createListView {
    
    self.listPhoto = [NSMutableArray arrayWithObjects:@"1",nil];
    self.listData = @[@"支付宝收款二维码"];
    [self.view addSubview:self.listView];
    self.enterIdentity.placeholder = @"支付宝帐号";
}

- (void)clickUploadAction {
    
    
}

@end
