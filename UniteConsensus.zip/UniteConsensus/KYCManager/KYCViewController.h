//
//  KYCViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/17.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"
#import "AuthenManager.h"

@interface KYCViewController : BaseViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UITextField *enterIdentity;

@property (nonatomic,weak) NSIndexPath *selectIndex;
@property (nonatomic,strong) NSMutableArray *listPhoto;

@property (nonatomic,strong) AuthenManager *authenManager;

- (void)createListView;

- (void)clickUploadAction;

@end
