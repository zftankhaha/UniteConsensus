//
//  ShowViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/21.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "ShowViewController.h"
#import "KYCViewController.h"

@interface ShowViewController ()

@property (nonatomic,strong) UITableView *listView;

@end

@implementation ShowViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"认证说明";
    
    [self.view addSubview:self.listView];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor whiteColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        //添加headerView
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,300)];
        headerView.backgroundColor = [UIColor clearColor];
        _listView.tableHeaderView = headerView;
        
        UILabel *stitle = [[UILabel alloc] initWithFrame:CGRectMake(25,10,SCREEN_WIDTH-50,190)];
        stitle.backgroundColor = [UIColor clearColor];
        stitle.font = CommonFontLight(17.0f);
        stitle.textAlignment = NSTextAlignmentLeft;
        stitle.numberOfLines = 0;stitle.textColor = kDefaultRedColor;
        NSString *string1 = @"       认证分为两步，第一步实名认证，第二步支付宝认证，请各位会员本着严肃、认真的态度填写个人信息。";
        NSString *string2 = @"       平台每周批量复查，发现弄虚作假的情况，会严肃处理，后果自负。";
        [stitle setText:[NSString stringWithFormat:@"%@\n%@",string1,string2] lineSpacing:10];
        [headerView addSubview:stitle];
        
        WEAKSELF
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(25,220,SCREEN_WIDTH-50,50);
        button.backgroundColor = GradientColor(3,button.size);
        button.titleLabel.font = CommonFontRegular(18);
        [button setTitle:@"开始认证" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        button.layer.cornerRadius = 5;
        button.layer.masksToBounds = YES;
        [headerView addSubview:button];
        [button actionForButton:^(UIButton *button)
        {
            [UCAlertManager show:@"温馨提示" message:@"请仔细阅读认证说明" cancel:@"取消" sure:@"去认证" click:^(AlertClickType clickType)
            {
                if (clickType == SureType)
                {
                    KYCViewController *kycController = [[KYCViewController alloc] init];
                    [weakSelf.navigationController pushViewController:kycController animated:YES];
                }
                else
                {
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }];
        }];
    }
    
    return _listView;
}

@end
