//
//  CTImagePickerController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/22.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CTPickerController : UIImagePickerController

@end
