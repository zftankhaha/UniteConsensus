//
//  KYCViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/17.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "KYCViewController.h"
#import "KYCViewCell.h"
#import "CTPickerController.h"
#import "LastViewController.h"

@interface KYCViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation KYCViewController

- (void)dealloc {
    
}

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.showTitle = @"实名认证";
    
    [self createListView];
}

- (void)createListView {
    
    self.listPhoto = [NSMutableArray arrayWithObjects:@"1",@"2",nil];
    self.listData = @[@"身份证正面图片",@"支付宝收款二维码"];
    [self.view addSubview:self.listView];
}

- (AuthenManager *)authenManager {
    
    if (!_authenManager)
    {
        _authenManager = [[AuthenManager alloc] init];
    }
    
    return _authenManager;
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = KYCViewCellHeight;
        
        //添加headerView
        _listView.tableHeaderView = [UIHeaderView createSpaceHeaderView:CGRectMake(0,0,SCREEN_WIDTH,70)];
        
        self.enterIdentity = [[UITextField alloc] initWithFrame:CGRectMake(25,10,SCREEN_WIDTH-50,50)];
        self.enterIdentity.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.enterIdentity.backgroundColor = [UIColor clearColor];
        self.enterIdentity.delegate = self;
        self.enterIdentity.rightViewMode = UITextFieldViewModeAlways;
        
        self.enterIdentity.autocapitalizationType = UITextAutocapitalizationTypeNone;
        self.enterIdentity.font = CommonFontLight(15.0f);
        self.enterIdentity.returnKeyType = UIReturnKeyDefault;
        self.enterIdentity.borderStyle = UITextBorderStyleNone;
        self.enterIdentity.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        self.enterIdentity.textColor = [UIColor blackColor];
        self.enterIdentity.placeholder = @"请输入身份证号码";
        [_listView.tableHeaderView addSubview:self.enterIdentity];
        
        //添加footerView
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,120)];
        footerView.backgroundColor = [UIColor whiteColor];
        [footerView bottomLineX:0 width:SCREEN_WIDTH color:nil];
        _listView.tableFooterView = footerView;
        
        WEAKSELF
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(30,30,SCREEN_WIDTH-60,40);
        button.backgroundColor = GradientColor(0,button.size);
        button.titleLabel.font = CommonFontRegular(17);
        [button setTitle:@"提交申请" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [button actionForButton:^(UIButton *button)
        {
            [weakSelf clickUploadAction];
        }];
        
        button.layer.cornerRadius = 5;
        button.layer.masksToBounds = YES;
        [_listView.tableFooterView addSubview:button];
    }
    
    return _listView;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [self.enterIdentity resignFirstResponder];
    
    return YES;
}

- (void)clickUploadAction {
    
    BOOL check = YES;
    
    for (id object in self.listPhoto)
    {
        if ([object isKindOfClass:[NSString class]])
        {
            check = NO;
            NSInteger current = [self.listPhoto indexOfObject:object];
            
            if (0 == current)
            {
                CommonShowTitle(@"请设置身份证正面图片");
            }
            else if (1 == current)
            {
                CommonShowTitle(@"请设置身份证反面图片");
            }
            
            break;
        }
    }
    
    if (check)
    {
        LastViewController *aliController = [[LastViewController alloc] init];
        [self.navigationController pushViewController:aliController animated:YES];
    }
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    KYCViewCell *myCell = [KYCViewCell cellWithTableView:tableView];
    myCell.delegate = self;
    [myCell.actionButton setTitle:self.listData[indexPath.row] forState:UIControlStateNormal];
    return myCell;
}

- (void)clickPickerAction:(id)myCell {
    
    self.selectIndex = [self.listView indexPathForCell:myCell];
    [self.enterIdentity resignFirstResponder];
    
    [UCSheetManager show:nil list:@[@"拍一张",@"去图片库"] cancel:@"取消" click:^(NSInteger index,NSArray *listTitle)
    {
        if (0 <= index)
        {
            CTPickerController *pickerController = [[CTPickerController alloc] init];
            pickerController.modalPresentationStyle = UIModalPresentationFullScreen;
            pickerController.delegate = self;
            
            if (0 == index)
            {
                pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            }
            else if (1 == index)
            {
                pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            }
            
            [UIScrollView appearance].contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentAutomatic;
            CommonShowLoading;
            [self presentViewController:pickerController animated:YES completion:^{CommonExitLoading;}];
        }
    }];
}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    
    picker.delegate = nil;
    UIImage *originalImage = (UIImage *)[info objectForKey:UIImagePickerControllerOriginalImage];
    
    KYCViewCell *myCell = (KYCViewCell *)[self.listView cellForRowAtIndexPath:self.selectIndex];
    [myCell.actionButton setImage:originalImage forState:UIControlStateNormal];
    [self.listPhoto replaceObjectAtIndex:self.selectIndex.row withObject:originalImage];
    
    [picker dismissViewControllerAnimated:YES completion:nil];
  
    QiNiuManager *upManager = [[QiNiuManager alloc] init];
    NSURL *ctUrl = [info objectForKey:UIImagePickerControllerImageURL];
    [upManager startUploadImage:ctUrl.path result:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    picker.delegate = nil;[picker dismissViewControllerAnimated:YES completion:nil];
}

@end
