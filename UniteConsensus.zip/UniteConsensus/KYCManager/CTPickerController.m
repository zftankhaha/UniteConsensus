//
//  CTImagePickerController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/22.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "CTPickerController.h"

@interface CTPickerController ()

@end

@implementation CTPickerController

- (void)dealloc {
    
    [UIScrollView appearance].contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.navigationBar.translucent = NO;
    self.allowsEditing = NO;
}

@end
