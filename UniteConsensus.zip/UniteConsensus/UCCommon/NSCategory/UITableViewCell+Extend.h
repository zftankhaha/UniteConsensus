//
//  UITableViewCell+Extend.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (Extend)

+ (instancetype)cellWithTableView:(UITableView *)tableView;

- (UIImageView *)arrowImageView:(CGFloat)height;

@end
