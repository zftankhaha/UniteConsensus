//
//  UIButton+Create.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UIButton+Create.h"
#import "BCWeakReference.h"

@implementation UIButton (Create)

+ (instancetype)button:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color font:(UIFont *)font radius:(CGFloat)radius {
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;[button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:color forState:UIControlStateNormal];
    button.backgroundColor = [UIColor clearColor];
    button.titleLabel.font = font;
    
    if (0.0f < radius)
    {
        button.layer.cornerRadius = radius;
        button.layer.masksToBounds = YES;
    }
    
    return button;
}


- (void)actionForButton:(void(^)(UIButton *button))completion {
    
    if (completion)
    {
        BCWeakReference *reference = [[BCWeakReference alloc] init];
        reference.completion = completion;
        objc_setAssociatedObject(self,@selector(clickButtonAction),reference,OBJC_ASSOCIATION_RETAIN);
        [self addTarget:self action:@selector(clickButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)clickButtonAction {
    
    BCWeakReference *reference = objc_getAssociatedObject(self,_cmd);
    
    void(^completion)(id action) = reference.completion;
    
    if (completion)
    {
        completion(self);
    }
}

@end
