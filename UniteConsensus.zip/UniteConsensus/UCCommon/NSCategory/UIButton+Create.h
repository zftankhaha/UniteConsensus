//
//  UIButton+Create.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Create)

+ (instancetype)button:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color font:(UIFont *)font radius:(CGFloat)radius;

- (void)actionForButton:(void(^)(UIButton *button))completion;

@end
