//
//  UILabel+Create.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UILabel+Create.h"

@implementation UILabel (Create)

+ (instancetype)createFrame:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color font:(UIFont *)font {
    
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.backgroundColor = [UIColor clearColor];
    label.text = title;
    label.textColor = color;
    label.font = font;
    return label;
}


- (void)setText:(NSString *)text lineSpacing:(CGFloat)lineSpacing {
    
    if (!text || lineSpacing < 0.01)
    {
        self.text = text;
        return;
    }
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:lineSpacing];        //设置行间距
    [paragraphStyle setLineBreakMode:self.lineBreakMode];
    [paragraphStyle setAlignment:self.textAlignment];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:text];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0,[text length])];
    self.attributedText = attributedString;
}

@end
