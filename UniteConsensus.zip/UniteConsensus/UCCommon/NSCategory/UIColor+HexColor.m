//
//  UIColor+HexColor.m
//  BCExchange
//
//  Created by zftank on 2018/7/7.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "UIColor+HexColor.h"

#define DEFAULTCOLOR   [UIColor clearColor]

@implementation UIColor (HexColor)

+ (UIColor *)colorHexString:(NSString *)hex {
    
    return [UIColor colorHexString:hex alpha:1.0f];
}

+ (UIColor *)colorHexString:(NSString *)hex alpha:(CGFloat)alpha {
    
    NSCharacterSet *character = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    
    NSString *cString = [[hex stringByTrimmingCharactersInSet:character] uppercaseString];
    
    if ([cString length] < 6)
    {
        return DEFAULTCOLOR;
    }
    
    if ([cString hasPrefix:@"#"])
    {
        cString = [cString substringFromIndex:1];
    }
    
    if ([cString length] != 6 && [cString length] != 8)
    {
        return DEFAULTCOLOR;
    }
    
    NSRange range;
    
    range.location = 0;
    range.length = 2;
    
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    
    NSString *bString = [cString substringWithRange:range];
    
    unsigned int r, g, b;
    
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    if (cString.length == 8)
    {
        range.location = 6;
        NSString *aString = [cString substringWithRange:range];
        unsigned int aInt;
        [[NSScanner scannerWithString:aString] scanHexInt:&aInt];
        alpha = aInt/255.f;
    }
    
    if (alpha < 0.0f || 1.0f < alpha)
    {
        alpha = 1.0f;
    }
    
    return [UIColor colorWithRed:((CGFloat)r/255.0f)
                           green:((CGFloat)g/255.0f)
                            blue:((CGFloat)b/255.0f)
                           alpha:alpha];
}

+ (instancetype)affectSize:(CGSize)size style:(LinearGradientColorDirection)style
                startColor:(UIColor *)startcolor endColor:(UIColor *)endColor {
    
    if (CGSizeEqualToSize(size, CGSizeZero) || !startcolor || !endColor)
    {
        return nil;
    }
    
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = CGRectMake(0,0,size.width,size.height);
    
    CGPoint startPoint = CGPointMake(0.0,0.0);
    
    if (style == LinearRightToLoft)
    {
        startPoint = CGPointMake(1.0,1.0);
    }
    
    if (style == LinearDirectionUpwardDiagonalLine)
    {
        startPoint = CGPointMake(0.0,1.0);
    }
    
    CGPoint endPoint = CGPointMake(0.0,0.0);
    
    switch (style)
    {
        case LinearLeftToRight:
        {
            endPoint = CGPointMake(1.0,0.0);
            break;
        }
        case LinearRightToLoft:
        {
            endPoint = CGPointMake(0.0,1.0);
            break;
        }
        case LinearDirectionVertical:
        {
            endPoint = CGPointMake(0.0,1.0);
            break;
        }
        case LinearDirectionDownDiagonalLine:
        {
            endPoint = CGPointMake(1.0,1.0);
            break;
        }
        case LinearDirectionUpwardDiagonalLine:
        {
            endPoint = CGPointMake(1.0,0.0);
            break;
        }
        default:
        {
            endPoint = CGPointMake(1.0,0.0);
            break;
        }
    }
    
    gradientLayer.startPoint = startPoint;
    gradientLayer.endPoint = endPoint;
    
    gradientLayer.colors = @[(__bridge id)startcolor.CGColor, (__bridge id)endColor.CGColor];
    UIGraphicsBeginImageContext(size);
    [gradientLayer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return [UIColor colorWithPatternImage:image];
}

@end
