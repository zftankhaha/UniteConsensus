//
//  UILabel+Create.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Create)

+ (instancetype)createFrame:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color font:(UIFont *)font;


- (void)setText:(NSString *)text lineSpacing:(CGFloat)lineSpacing;

@end
