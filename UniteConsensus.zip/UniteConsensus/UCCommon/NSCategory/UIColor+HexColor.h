//
//  UIColor+HexColor.h
//  BCExchange
//
//  Created by zftank on 2018/7/7.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,LinearGradientColorDirection) {
    
    LinearLeftToRight = 0,                     //从左向右水平渐变
    LinearRightToLoft = 1,                     //从右向左水平渐变
    LinearDirectionVertical = 2,               //竖直渐变
    LinearDirectionDownDiagonalLine = 3,       //向下对角线渐变
    LinearDirectionUpwardDiagonalLine = 4,     //向上对角线渐变
};

@interface UIColor (HexColor)

//8位的最后两位代表alpha值
+ (UIColor *)colorHexString:(NSString *)hex;

+ (UIColor *)colorHexString:(NSString *)hex alpha:(CGFloat)alpha;

//渐变颜色
+ (instancetype)affectSize:(CGSize)size style:(LinearGradientColorDirection)style
                startColor:(UIColor *)startcolor endColor:(UIColor *)endColor;
@end
