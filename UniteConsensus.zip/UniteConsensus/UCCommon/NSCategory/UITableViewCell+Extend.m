//
//  UITableViewCell+Extend.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/2.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UITableViewCell+Extend.h"

@implementation UITableViewCell (Extend)

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    static NSString *cellClass = nil;
    
    if (!cellClass)
    {
        cellClass = NSStringFromClass([self class]);
    }
    
    UITableViewCell *myCell = [tableView dequeueReusableCellWithIdentifier:cellClass];
    
    if (!myCell)
    {
        myCell = [[[self class] alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellClass];
    }
    
    return myCell;
}


- (UIImageView *)arrowImageView:(CGFloat)height {
    
    UIImageView *arrowView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-60,0,60,height)];
    arrowView.image = kDefaultArrowImage;
    arrowView.contentMode = UIViewContentModeCenter;
    [self.contentView addSubview:arrowView];
    return arrowView;
}

@end
