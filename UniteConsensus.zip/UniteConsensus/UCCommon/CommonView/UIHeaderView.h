//
//  UIHeaderView.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/18.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIHeaderView : UIView

+ (instancetype)createHeaderView:(CGRect)frame;

+ (instancetype)createSpaceHeaderView:(CGRect)frame;

+ (instancetype)createLineHeaderView;

@end
