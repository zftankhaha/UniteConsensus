//
//  XLCycleView.m
//  IOSMasterPlate
//
//  Created by zhangfeng on 13-6-5.
//  Copyright (c) 2013年 zhangfeng. All rights reserved.
//

#import "XLCycleView.h"

@interface BannerPageManager : UIPageControl

@property (nonatomic,assign) BannerPageStyle pageStyle;

+ (BannerPageManager *)creatBannerPage:(CGRect)rect;

@end

@implementation BannerPageManager

+ (BannerPageManager *)creatBannerPage:(CGRect)rect {
    
    BannerPageManager *bannerPage = [[BannerPageManager alloc] initWithFrame:rect];
    bannerPage.pageStyle = CTPageShapeStyleCircle;
    bannerPage.userInteractionEnabled = NO;
    return bannerPage;
}

- (void)setPageStyle:(BannerPageStyle)pageStyle {
    
    _pageStyle = pageStyle;
    
//    if (_pageStyle == CTPageShapeStyleSquare)
//    {
//        [self setValue:[UIImage imageNamed:@"pageControl_normol"] forKeyPath:@"_pageImage"];
//        
//        [self setValue:[UIImage imageNamed:@"pageControl_selected"] forKeyPath:@"_currentPageImage"];
//    }
}

@end


@interface UICTButton : UIButton

@property (nonatomic,strong) UIImageView *showImageView;

@end

@implementation UICTButton

+ (instancetype)buttonWithFrame:(CGRect)rect {
    
    UICTButton *button = [super buttonWithType:UIButtonTypeCustom];
    button.frame = rect;
    button.backgroundColor = [UIColor clearColor];
    button.exclusiveTouch = YES;
    button.adjustsImageWhenHighlighted = NO;
    
    button.showImageView = [[UIImageView alloc] initWithFrame:button.bounds];
    button.showImageView.userInteractionEnabled = NO;
    button.showImageView.backgroundColor = [UIColor clearColor];
    button.showImageView.contentMode = UIViewContentModeScaleAspectFill;
    button.showImageView.contentScaleFactor = [UIScreen mainScreen].scale;
    button.showImageView.clipsToBounds = YES;
    [button addSubview:button.showImageView];
    
    return button;
}

@end

@interface CTScrollView : UIScrollView

@property (nonatomic,strong) NSTimer *scrollTimer;
@property (nonatomic,assign) CGFloat scrollDuration;

@end

@implementation CTScrollView

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        _scrollDuration = 4.0f;
        self.backgroundColor = [UIColor clearColor];
        self.pagingEnabled = YES;
        self.showsHorizontalScrollIndicator = NO;
        self.scrollEnabled = YES;
        self.scrollsToTop = NO;
    }
    
    return self;
}

- (void)startTimer:(NSTimeInterval)scrollInterval {
    
    [self stopTimer];

    if (0.0f < scrollInterval)
    {
        self.scrollDuration = scrollInterval;
    }

    self.scrollTimer = [NSTimer timerWithTimeInterval:self.scrollDuration target:self
                                             selector:@selector(autoScrollAction:)
                                             userInfo:nil repeats:YES];

    [[NSRunLoop currentRunLoop] addTimer:self.scrollTimer forMode:NSRunLoopCommonModes];
}

- (void)autoScrollAction:(id)sender {
    
    [self setContentOffset:CGPointMake(2*self.bounds.size.width,0) animated:YES];
}

- (void)stopTimer {
    
    [[NSRunLoop currentRunLoop] cancelPerformSelectorsWithTarget:self];
    [self.scrollTimer invalidate];self.scrollTimer = nil;
}

@end


@interface XLCycleView () <UIScrollViewDelegate>

@property (nonatomic,strong) UICTButton *showButton;
@property (nonatomic,strong) CTScrollView *scrollView;
@property (nonatomic,strong) NSMutableArray *contentViews;

@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) BannerPageManager *pageManager;
@property (nonatomic,assign) BannerPageStyle pageStyle;

@property (nonatomic,assign) NSInteger currentPage;
@property (nonatomic,assign) NSInteger numberOfPage;

@property (nonatomic,assign) CGFloat CGWidth;
@property (nonatomic,assign) CGFloat CGHeight;

@end

@implementation XLCycleView

- (void)dealloc {

    _delegate = nil;
    _scrollView.delegate = nil;
    
    for (UICTButton *button in _contentViews)
    {
        [button.showImageView closeImageRequest];
        [button removeFromSuperview];
    }
    
    [_scrollView stopTimer];
    _scrollView = nil;
}

+ (XLCycleView *)showView:(CGRect)frame style:(BannerPageStyle)style {

    XLCycleView *cycleView = [[XLCycleView alloc] initWithFrame:frame];
    cycleView.backgroundColor = [UIColor whiteColor];
    cycleView.userInteractionEnabled = YES;
    cycleView.currentPage = 0;
    cycleView.numberOfPage = 0;
    
    cycleView.autoScroll = YES;
    cycleView.pageStyle = style;
    
    cycleView.CGWidth = frame.size.width;
    cycleView.CGHeight = frame.size.height;
    
    cycleView.contentViews = [NSMutableArray array];
    
    cycleView.showButton = [UICTButton buttonWithFrame:cycleView.bounds];
    [cycleView addSubview:cycleView.showButton];
    [cycleView.contentViews addObject:cycleView.showButton];
    
    return cycleView;
}

- (void)reloadData:(NSArray *)listData duration:(NSTimeInterval)duration {
    
    if (!listData || ![listData isKindOfClass:[NSArray class]])
    {
        return;
    }
    
    if (listData.count <= 0)
    {
        return;
    }
    
    if (self.listData && [self.listData isEqual:listData])
    {
        return;
    }
    
    self.listData = listData;
    
    for (UICTButton *button in self.contentViews)
    {
        [button.showImageView closeImageRequest];
        [button removeFromSuperview];
    }
    
    self.currentPage = 0;
    self.numberOfPage = self.listData.count;
    self.contentViews = [NSMutableArray array];
    
    [self.showButton removeFromSuperview];self.showButton = nil;
    [self.pageManager removeFromSuperview];self.pageManager = nil;
    
    self.scrollView.delegate = nil;[self.scrollView stopTimer];
    [self.scrollView removeFromSuperview];self.scrollView = nil;
    
    if (self.numberOfPage == 1)
    {
        _autoScroll = NO;
        self.showButton = [UICTButton buttonWithFrame:self.bounds];
        [self.showButton addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.showButton];
        [self.contentViews addObject:self.showButton];
        [self requestImage:self.showButton withIndex:0];
    }
    else
    {
        _autoScroll = YES;
        self.scrollView = [[CTScrollView alloc] initWithFrame:self.bounds];
        self.scrollView.delegate = self;
        self.scrollView.contentSize = CGSizeMake(3*self.CGWidth,self.CGHeight);
        self.scrollView.contentOffset = CGPointMake(self.CGWidth,0);
        [self addSubview:self.scrollView];
        
        for (int i=0;i<3;i++)
        {
            CGRect rect = CGRectMake(i*self.CGWidth,0,self.CGWidth,self.CGHeight);
            UICTButton *button = [UICTButton buttonWithFrame:rect];
            [button addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
            [self.scrollView addSubview:button];
            [self.contentViews addObject:button];
        }
        
        self.pageManager = [BannerPageManager creatBannerPage:CGRectMake(0,0,200,20)];
        self.pageManager.center = CGPointMake(self.CGWidth/2,self.CGHeight-15);
        self.pageManager.pageStyle = self.pageStyle;
        self.pageManager.numberOfPages = self.numberOfPage;
        [self addSubview:self.pageManager];
        
        [self refreshDataSource];
        [self.scrollView startTimer:duration];
    }
}

- (void)refreshDataSource {

    self.pageManager.currentPage = self.currentPage;
    
    [self displayCurrentPage];
    
    [self.scrollView setContentOffset:CGPointMake(self.CGWidth,0) animated:NO];
}

- (void)displayCurrentPage {
    
    NSInteger prePage = [self validPageValue:self.currentPage-1];
    
    NSInteger lastPage = [self validPageValue:self.currentPage+1];
    
    for (UICTButton *button in self.contentViews)
    {
        NSUInteger index = [self.contentViews indexOfObject:button];
        
        if (0 == index)
        {
            [self requestImage:button withIndex:prePage];
        }
        else if (1 == index)
        {
            self.showButton = button;
            
            [self requestImage:button withIndex:self.currentPage];
        }
        else if (2 == index)
        {
            [self requestImage:button withIndex:lastPage];
        }
    }
}

- (NSInteger)validPageValue:(NSInteger)value {
    
    if (value == -1)
    {
        value = self.numberOfPage-1;
    }
    
    if (value == self.numberOfPage)
    {
        value = 0;
    }
    
    return value;
}

- (void)requestImage:(UICTButton *)button withIndex:(NSInteger)scrollIndex {
    
    if (scrollIndex < 0)
    {
        return;
    }
    
    if (self.listData.count <= scrollIndex)
    {
        return;
    }
    
    if (self.listData.count <= 0)
    {
        return;
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(showView:title:atIndex:)])
    {
        [self.delegate showView:button.showImageView title:nil atIndex:scrollIndex];
    }
}

- (void)setAutoScroll:(BOOL)autoScroll {
    
    _autoScroll = autoScroll;
    
    if (autoScroll && 1 < self.listData.count)
    {
        [self.scrollView startTimer:self.scrollView.scrollDuration];
    }
    else
    {
        _autoScroll = NO;
        [self.scrollView stopTimer];
    }
}

- (void)refreshCurrentPage:(NSInteger)currentPage {
    
    if (currentPage < 0)
    {
        return;
    }
    
    if (!self.listData)
    {
        return;
    }
    
    if (self.listData.count <= 0 || self.listData.count <= currentPage)
    {
        return;
    }
    
    self.currentPage = currentPage;
    
    [self refreshDataSource];
}

- (NSInteger)currentCoverIndex {
    
    return self.currentPage;
}

#pragma mark -
#pragma mark UIScrollViewDelegate

- (void)scrollViewDidScroll:(CTScrollView *)aScrollView {
    
    NSInteger currentX = aScrollView.contentOffset.x;
    
    if ((2*self.CGWidth) <= currentX)
    {
        self.currentPage = [self validPageValue:self.currentPage+1];
        
        [self refreshDataSource];
    }
    
    if (currentX <= 0)
    {
        self.currentPage = [self validPageValue:self.currentPage-1];
        
        [self refreshDataSource];
    }
}

- (void)scrollViewWillBeginDragging:(CTScrollView *)scrollView {
    
    [self.scrollView stopTimer];
}

- (void)scrollViewDidEndDragging:(CTScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
    if (self.autoScroll && 1 < self.listData.count)
    {
        [self.scrollView startTimer:self.scrollView.scrollDuration];
    }
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    
    self.scrollView.contentOffset = CGPointMake(self.CGWidth,0);
}

- (void)scrollViewDidEndDecelerating:(CTScrollView *)aScrollView {

    [self.scrollView setContentOffset:CGPointMake(self.CGWidth,0) animated:YES];
}

#pragma mark -
#pragma mark XLCycleView Delegate

- (void)clickAction:(UICTButton *)btn {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(xlcycleView:didSelectAtIndex:)])
    {
        [self.delegate xlcycleView:self didSelectAtIndex:self.currentPage];
    }
}

@end
