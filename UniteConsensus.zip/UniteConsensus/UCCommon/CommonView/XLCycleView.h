//
//  XLCycleView.h
//  IOSMasterPlate
//
//  Created by zhangfeng on 13-6-5.
//  Copyright (c) 2013年 zhangfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XLCycleView;

typedef NS_ENUM(NSInteger,BannerPageStyle) {
    
    CTPageShapeStyleCircle = 0,         //默认值，白色小圆点
    CTPageShapeStyleSquare = 1,         //白色矩形
};

@protocol XLCycleViewDelegate <NSObject>

@optional

- (void)showView:(UIImageView *)showView title:(UILabel *)title atIndex:(NSInteger)index;

- (void)xlcycleView:(XLCycleView *)cycleView didSelectAtIndex:(NSInteger)index;

@end

@interface XLCycleView : UIView

@property (nonatomic,weak) id delegate;

@property (nonatomic,assign) BOOL autoScroll;

+ (XLCycleView *)showView:(CGRect)frame style:(BannerPageStyle)style;

- (void)reloadData:(NSArray *)listData duration:(NSTimeInterval)duration;


- (void)refreshCurrentPage:(NSInteger)currentPage;

- (NSInteger)currentCoverIndex;

@end
