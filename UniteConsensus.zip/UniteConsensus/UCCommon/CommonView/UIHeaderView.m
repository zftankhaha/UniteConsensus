//
//  UIHeaderView.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/18.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UIHeaderView.h"

@implementation UIHeaderView

+ (instancetype)createHeaderView:(CGRect)frame {
    
    UIHeaderView *headerView = [[UIHeaderView alloc] initWithFrame:frame];
    headerView.backgroundColor = kBackGroundColor;
    [headerView addSubview:[UIView drawHTLine:CGRectMake(0,-kLineSpace,headerView.width,kLineSpace) color:nil]];
    [headerView bottomLineX:0 width:headerView.width color:nil];
    
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0,0,headerView.width,headerView.height-10)];
    contentView.backgroundColor = [UIColor whiteColor];
    [contentView bottomLineX:0 width:SCREEN_WIDTH color:nil];
    [headerView addSubview:contentView];
    
    return headerView;
}

+ (instancetype)createSpaceHeaderView:(CGRect)frame {
    
    UIHeaderView *headerView = [[UIHeaderView alloc] initWithFrame:frame];
    headerView.backgroundColor = kBackGroundColor;
    [headerView bottomLineX:0 width:headerView.width color:nil];
    
    UIView *currentView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
    currentView.backgroundColor = [UIColor clearColor];
    [headerView addSubview:currentView];
    [currentView bottomLineX:0 width:SCREEN_WIDTH color:nil];
    
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0,10,headerView.width,headerView.height-20)];
    contentView.backgroundColor = [UIColor whiteColor];
    [contentView bottomLineX:0 width:SCREEN_WIDTH color:nil];
    [headerView addSubview:contentView];
    
    return headerView;
}

+ (instancetype)createLineHeaderView {
    
    UIHeaderView *headerView = [[UIHeaderView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
    headerView.backgroundColor = kBackGroundColor;
    [headerView bottomLineX:0 width:headerView.width color:nil];
    return headerView;
}

@end
