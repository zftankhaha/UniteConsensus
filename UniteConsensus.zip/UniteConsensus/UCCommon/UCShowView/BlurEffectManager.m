//
//  BlurEffectManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/12/15.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "BlurEffectManager.h"

#define kBlurID   33309

@implementation BlurEffectManager

+ (void)blurEffect:(UIBlurEffectStyle)style rootView:(UIView *)rootView {
    
    if (rootView && [rootView isKindOfClass:[UIView class]])
    {
        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:style];
        UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:effect];
        blurView.frame = rootView.bounds;blurView.tag = kBlurID;[rootView addSubview:blurView];
    }
}

+ (void)cleanBlurEffect:(UIView *)rootView {
    
    if (rootView && [rootView isKindOfClass:[UIView class]])
    {
        [[rootView viewWithTag:kBlurID] removeFromSuperview];
    }
}

@end
