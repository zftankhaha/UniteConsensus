//
//  BlurEffectManager.h
//  HBankXLoan
//
//  Created by zftank on 2016/12/15.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BlurEffectManager : NSObject

+ (void)blurEffect:(UIBlurEffectStyle)style rootView:(UIView *)rootView;

+ (void)cleanBlurEffect:(UIView *)rootView;

@end
