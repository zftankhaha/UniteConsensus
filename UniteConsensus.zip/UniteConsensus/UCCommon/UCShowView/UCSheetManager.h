//
//  HBSheetManager.h
//  HBankXLoan
//
//  Created by zftank on 2016/11/23.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UCSheetManager : NSObject

+ (void)show:(NSString *)title list:(NSArray *)list cancel:(NSString *)cancel
       click:(void(^)(NSInteger index,NSArray *list))result;

@end
