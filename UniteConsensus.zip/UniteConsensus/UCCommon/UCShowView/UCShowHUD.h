//
//  HBShowHUD.h
//  PanoramicVideo
//
//  Created by zftank on 16/8/23.
//  Copyright © 2016年 PanoramicVideo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#define CommonShowLoading             [UCShowHUD showLoading]
#define CommonExitLoading             [UCShowHUD dismissLoading]

#define CommonShowTitle(title)        [UCShowHUD showTips:title duration:5]

@interface UCShowHUD : NSObject

#pragma mark -
#pragma mark Show Title

+ (void)showTips:(NSString *)title duration:(CGFloat)duration;

#pragma mark -
#pragma mark Show Loading

+ (void)showLoading:(UIView *)rootView;

+ (void)dismissLoading:(UIView *)rootView;

+ (void)showLoading;//覆盖全屏

+ (void)dismissLoading;

@end
