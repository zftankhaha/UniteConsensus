//
//  SystemAlertView.m
//  GJDD
//
//  Created by zhangfeng on 15/1/15.
//  Copyright (c) 2015年 zhangfeng. All rights reserved.
//

#import "UCAlertManager.h"

#define buttonHeight   60

@interface AlertRootView : UIView

@property (nonatomic,strong) UIView *alertView;

@property (nonatomic,copy) void(^alertCallBack)(AlertClickType clickType);

@end

@implementation AlertRootView

- (instancetype)initWithFrame:(CGRect)frame show:(BOOL)show {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        
        if (show)
        {
            UIView *backView = [[UIView alloc] initWithFrame:frame];
            backView.backgroundColor = [UIColor blackColor];
            backView.alpha = 0.65f;[self addSubview:backView];
            
            //[BlurEffectManager blurEffect:UIBlurEffectStyleDark rootView:self];
        }
    }
    
    return self;
}

- (void)showTitle:(NSString *)title message:(NSString *)message alignment:(NSTextAlignment)alignment {
    
    //添加内容视图
    CGFloat alertWidth = SCREEN_WIDTH-60;
    CGFloat alertHeight = 20+18+60+buttonHeight;
    
    self.alertView = [[UIView alloc] initWithFrame:CGRectMake(0,0,alertWidth,alertHeight)];
    
    self.alertView.backgroundColor = kLightWhiteColor;
    self.alertView.center = CGPointMake(SCREEN_WIDTH/2,SCREEN_HEIGHT/2-18);
    self.alertView.layer.cornerRadius = 6;
    self.alertView.layer.masksToBounds = YES;
    [self addSubview:self.alertView];
    
    UILabel *lbtitle = [[UILabel alloc] initWithFrame:CGRectMake(15,10,alertWidth-30,40)];
    lbtitle.backgroundColor = [UIColor clearColor];
    lbtitle.font = CommonFontRegular(18);
    lbtitle.textColor = [UIColor blackColor];
    lbtitle.textAlignment = NSTextAlignmentCenter;
    lbtitle.text = title;
    [self.alertView addSubview:lbtitle];
    
    UILabel *lbmessage = [[UILabel alloc] initWithFrame:CGRectMake(15,lbtitle.bottom-3,alertWidth-30,33)];
    lbmessage.backgroundColor = [UIColor clearColor];
    lbmessage.font = CommonFontLight(17.5);
    lbmessage.textColor = [UIColor blackColor];
    lbmessage.textAlignment = alignment;
    lbmessage.text = message;
    lbmessage.numberOfLines = 0;
    [self.alertView addSubview:lbmessage];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0,alertHeight-buttonHeight-1,alertWidth,1)];
    lineView.backgroundColor = kLineColor;[self.alertView addSubview:lineView];
}

@end

@interface UCAlertManager()

@property (nonatomic,strong) NSPointerArray *weakArray;//弱引用数组

@end

@implementation UCAlertManager

+ (UCAlertManager *)alertInstance {
    
    static dispatch_once_t onceToken;
    
    static UCAlertManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[UCAlertManager alloc] init];
        shareInstance.weakArray = [NSPointerArray pointerArrayWithOptions:NSPointerFunctionsWeakMemory];
    });
    
    return shareInstance;
}

- (void)setShowAlertView:(id)rootView {
    
    if (rootView)
    {
        NSArray *array = self.weakArray.allObjects;
        
        if (![array containsObject:rootView])
        {
            [self.weakArray addPointer:(__bridge void *)(rootView)];
        }
    }
}

#pragma mark -
#pragma mark Public

+ (void)show:(NSString *)title message:(NSString *)message
      cancel:(NSString *)cancel sure:(NSString *)sure
       click:(void(^)(AlertClickType clickType))callback {

    [UCAlertManager show:title message:message alignment:NSTextAlignmentCenter cancel:cancel sure:sure click:callback];
}

+ (void)show:(NSString *)title message:(NSString *)message
   alignment:(NSTextAlignment)alignment
      cancel:(NSString *)cancel sure:(NSString *)sure
       click:(void(^)(AlertClickType clickType))callback {
        
    UCAlertManager *alertManager = [UCAlertManager alertInstance];
    
    //添加rootView
    CGRect aframe = CGRectMake(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
    AlertRootView *rootView = [[AlertRootView alloc] initWithFrame:aframe show:YES];
    rootView.backgroundColor = [UIColor clearColor];
    rootView.alertCallBack = callback;
    [rootView showTitle:title message:message alignment:alignment];
    [CommonDelegate.window addSubview:rootView];
    [alertManager setShowAlertView:rootView];
    
    //添加button事件
    CGFloat alertWidth = rootView.alertView.width;
    CGFloat alertHeight = rootView.alertView.height;
    
    if ([BKCheckValid checkStringValid:sure] && [BKCheckValid checkStringValid:cancel])
    {
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        button1.backgroundColor = [UIColor clearColor];
        button1.frame = CGRectMake(0,alertHeight-buttonHeight,alertWidth/2,buttonHeight);
        [button1 setTitle:cancel forState:UIControlStateNormal];
        [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button1 addTarget:alertManager action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        button1.tag = 0;[rootView.alertView addSubview:button1];
        
        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
        button2.backgroundColor = [UIColor clearColor];
        button2.frame = CGRectMake(alertWidth/2,alertHeight-buttonHeight,alertWidth/2,buttonHeight);
        [button2 setTitle:sure forState:UIControlStateNormal];
        button2.titleLabel.font = CommonFontRegular(19);
        [button2 setTitleColor:kDefaultRedColor forState:UIControlStateNormal];
        [button2 addTarget:alertManager action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        button2.tag = 1;[rootView.alertView addSubview:button2];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(alertWidth/2,alertHeight-buttonHeight,1,buttonHeight)];
        lineView.backgroundColor = kLineColor;[rootView.alertView addSubview:lineView];
    }
    else if ([BKCheckValid checkStringValid:cancel])
    {
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        button1.backgroundColor = [UIColor clearColor];
        button1.frame = CGRectMake(0,alertHeight-buttonHeight,alertWidth,buttonHeight);
        [button1 setTitle:cancel forState:UIControlStateNormal];
        [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button1 addTarget:alertManager action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        button1.tag = 0;[rootView.alertView addSubview:button1];
    }
    else if ([BKCheckValid checkStringValid:sure])
    {
        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
        button2.backgroundColor = [UIColor clearColor];
        button2.frame = CGRectMake(0,alertHeight-buttonHeight,alertWidth,buttonHeight);
        [button2 setTitle:sure forState:UIControlStateNormal];
        [button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button2 addTarget:alertManager action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        button2.tag = 1;[rootView.alertView addSubview:button2];
    }
    
    //做动画
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    animation.duration = 0.08f;
    animation.repeatCount = 1;
    animation.autoreverses = YES;
    animation.fromValue = [NSNumber numberWithFloat:1.0];
    animation.toValue = [NSNumber numberWithFloat:1.05];
    animation.removedOnCompletion = NO;
    [rootView.alertView.layer addAnimation:animation forKey:@"scale-layer"];
}

- (void)clickAction:(UIButton *)button {

    AlertRootView *rootView = (AlertRootView *)button.superview.superview;
    
    if (rootView.alertCallBack)
    {
        rootView.alertCallBack(button.tag);
        rootView.alertCallBack = nil;
    }
    
    [BlurEffectManager cleanBlurEffect:rootView];
    [rootView removeFromSuperview];
}

@end
