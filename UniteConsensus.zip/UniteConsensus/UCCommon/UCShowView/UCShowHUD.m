//
//  HBShowHUD.m
//  PanoramicVideo
//
//  Created by zftank on 16/8/23.
//  Copyright © 2016年 PanoramicVideo. All rights reserved.
//

#import "UCShowHUD.h"

static UIView *titleView = nil;

@implementation UCShowHUD

+ (void)showTips:(NSString *)title duration:(CGFloat)duration {
    
    if ([BKCheckValid checkStringValid:title])
    {
        dispatch_async(dispatch_get_main_queue(),^{
            
            [UCShowHUD displayTips:title duration:duration];
        });
    }
}

+ (void)displayTips:(NSString *)title duration:(CGFloat)duration {

    [UCShowHUD dismissMessage];
    
    if (duration <= 1 || 3 < duration)
    {
        duration = 3.0f;
    }
    
    titleView = [[UIView alloc] initWithFrame:CGRectMake(10,StatusBar_HEIGHT,SCREEN_WIDTH-20,60)];
    titleView.userInteractionEnabled = NO;titleView.alpha = 0.0f;
    titleView.backgroundColor = [UIColor clearColor];
    titleView.layer.cornerRadius = 3;titleView.layer.masksToBounds = YES;
    [CommonDelegate.window addSubview:titleView];
    
    UIView *alphaView = [[UIView alloc] initWithFrame:titleView.bounds];
    alphaView.userInteractionEnabled = NO;
    alphaView.backgroundColor = GradientColor(3,alphaView.size);
    [titleView addSubview:alphaView];
    
    UILabel *lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(10,5,titleView.width-20,titleView.height-10)];
    lbTitle.userInteractionEnabled = NO;
    lbTitle.backgroundColor = [UIColor clearColor];
    lbTitle.font = CommonFontLight(18.0f);
    lbTitle.text = title;
    lbTitle.textColor = [UIColor whiteColor];
    lbTitle.highlightedTextColor = [UIColor whiteColor];
    lbTitle.textAlignment = NSTextAlignmentCenter;
    lbTitle.numberOfLines = 0;
    lbTitle.lineBreakMode = NSLineBreakByWordWrapping;
    [titleView addSubview:lbTitle];
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionAllowUserInteraction animations:^{
        
        titleView.alpha = 1.0f;
    }
    completion:^(BOOL finished)
    {
        [self performSelector:@selector(dismissMessage) withObject:nil afterDelay:duration inModes:@[NSRunLoopCommonModes]];
    }];
}

+ (void)dismissMessage {
    
    [self cancelPreviousPerformRequestsWithTarget:self];
    titleView.hidden = YES;
    [titleView removeFromSuperview];
    titleView = nil;
}

#pragma mark -
#pragma mark Show Loading

+ (void)showLoading:(UIView *)rootView {

    [UCShowHUD dismissLoading:rootView];
    UIView *backView = [[UIView alloc] initWithFrame:rootView.bounds];
    backView.backgroundColor = [UIColor clearColor];
    backView.userInteractionEnabled = YES;
    backView.tag = rootView.hash;
    [rootView addSubview:backView];
    
    UIView *showView = [[UIView alloc] initWithFrame:CGRectMake(0,0,70,70)];
    showView.center = CGPointMake(backView.center.x,backView.center.y);
    showView.backgroundColor = [UIColor blackColor];
    showView.userInteractionEnabled = NO;
    showView.alpha = 0.8f;
    showView.layer.cornerRadius = 8;
    showView.layer.masksToBounds = YES;
    [backView addSubview:showView];
    
    UIActivityIndicatorView *activity = nil;
    UIActivityIndicatorViewStyle style = UIActivityIndicatorViewStyleWhiteLarge;
    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:style];
    activity.center = showView.center;activity.userInteractionEnabled = NO;
    activity.tag = 100;[activity startAnimating];[backView addSubview:activity];
}

+ (void)showLoading {

    [UCShowHUD dismissLoading];
    UIView *backView = [[UIView alloc] initWithFrame:CommonDelegate.window.bounds];
    backView.backgroundColor = [UIColor clearColor];
    backView.userInteractionEnabled = YES;
    backView.tag = CommonDelegate.window.hash;
    [CommonDelegate.window addSubview:backView];
    
    UIView *shadowView = [[UIView alloc] initWithFrame:backView.bounds];
    shadowView.backgroundColor = [UIColor blackColor];shadowView.alpha = 0.15f;
    [backView addSubview:shadowView];
    
    UIView *showView = [[UIView alloc] initWithFrame:CGRectMake(0,0,70,70)];
    showView.center = CGPointMake(CommonDelegate.window.center.x,CommonDelegate.window.center.y);
    showView.backgroundColor = [UIColor blackColor];showView.alpha = 0.85f;
    showView.userInteractionEnabled = NO;
    showView.layer.cornerRadius = 5;
    showView.layer.masksToBounds = YES;
    [backView addSubview:showView];
    
    UIActivityIndicatorView *activity = nil;
    UIActivityIndicatorViewStyle style = UIActivityIndicatorViewStyleWhiteLarge;
    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:style];
    activity.center = showView.center;activity.userInteractionEnabled = NO;
    activity.tag = 100;[activity startAnimating];[backView addSubview:activity];
}

+ (void)dismissLoading {

    [UCShowHUD dismissLoading:CommonDelegate.window];
}

+ (void)dismissLoading:(UIView *)rootView {
    
    UIView *backView = [rootView viewWithTag:rootView.hash];
    
    if (backView)
    {
        UIView *activity = (UIActivityIndicatorView *)[backView viewWithTag:100];
        
        if ([activity isKindOfClass:UIActivityIndicatorView.class])
        {
            UIActivityIndicatorView *activeView = (UIActivityIndicatorView *)activity;
            [activeView stopAnimating];activeView.hidden = YES;[activeView removeFromSuperview];
        }
        
        backView.hidden = YES;[backView removeFromSuperview];
    }
}

@end
