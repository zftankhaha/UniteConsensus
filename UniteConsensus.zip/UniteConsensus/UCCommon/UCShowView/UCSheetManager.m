//
//  HBSheetManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/11/23.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "UCSheetManager.h"

@interface UCSheetManager ()

@property (nonatomic,strong) UIView *rootView;
@property (nonatomic,strong) UIView *atView;

@end

@implementation UCSheetManager

+ (UCSheetManager *)sheetInstance {
    
    static dispatch_once_t onceToken;
    
    static UCSheetManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[UCSheetManager alloc] init];
    });
    
    return shareInstance;
}

+ (void)show:(NSString *)title list:(NSArray *)list cancel:(NSString *)cancel
       click:(void(^)(NSInteger index,NSArray *list))result {
    
    if (![BKCheckValid checkArrayValid:list])
    {
        return;
    }
    
    if (![BKCheckValid checkStringValid:cancel])
    {
        cancel = @"取消";
    }
    
    UCSheetManager *sheet = [UCSheetManager sheetInstance];
    
    sheet.rootView = [[UIView alloc] initWithFrame:UISCREEN_BOUNDS];
    sheet.rootView.backgroundColor = [UIColor clearColor];
    UIView *bkView = [[UIView alloc] initWithFrame:sheet.rootView.bounds];
    bkView.backgroundColor = [UIColor blackColor];
    bkView.alpha = 0.6f;[sheet.rootView addSubview:bkView];
    [CommonDelegate.window addSubview:sheet.rootView];
    
    BOOL haveTitle = NO;CGFloat height = 0.0f;
    
    if ([BKCheckValid checkStringValid:title])
    {
        haveTitle = YES;
        height = 60+65*list.count+20+60+15+Bottom_HEIGHT;
    }
    else
    {
        height = 65*list.count+20+60+15+Bottom_HEIGHT;
    }
    
    sheet.atView = [[UIView alloc] initWithFrame:CGRectMake(0,SCREEN_HEIGHT,SCREEN_WIDTH,height)];
    sheet.atView.backgroundColor = [UIColor clearColor];
    [sheet.rootView addSubview:sheet.atView];
    
    CGRect sheetRect = CGRectZero;CGFloat ftitle = 0.0f;
    
    if (haveTitle)
    {
        ftitle = 60;sheetRect = CGRectMake(10,0,SCREEN_WIDTH-20,60+65*list.count);
    }
    else
    {
        ftitle = 0.0f;sheetRect = CGRectMake(10,0,SCREEN_WIDTH-20,65*list.count);
    }
    
    UIView *sheetView = [[UIView alloc] initWithFrame:sheetRect];
    sheetView.backgroundColor = kLightWhiteColor;
    sheetView.layer.cornerRadius = 12;
    sheetView.layer.masksToBounds = YES;
    [sheet.atView addSubview:sheetView];
    
    if (haveTitle)
    {
        UILabel *lbtitle = [[UILabel alloc] initWithFrame:CGRectMake(0,0,sheetView.width,ftitle)];
        lbtitle.backgroundColor = [UIColor clearColor];
        lbtitle.font = CommonFontRegular(20);
        lbtitle.textColor = kDefaultRedColor;
        lbtitle.textAlignment = NSTextAlignmentCenter;
        lbtitle.text = title;
        [lbtitle bottomLineX:0 width:lbtitle.width color:nil];
        [sheetView addSubview:lbtitle];
    }
    
    for (int index=0;index<list.count;index++)
    {
        UIButton *btnAction = [UIButton buttonWithType:UIButtonTypeCustom];
        btnAction.backgroundColor = [UIColor clearColor];
        btnAction.frame = CGRectMake(0,ftitle+65*index,sheetView.width,65);
        btnAction.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        btnAction.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        btnAction.titleLabel.font = CommonFontLight(19);
        [btnAction setTitle:[list objectAtIndex:index] forState:UIControlStateNormal];
        [btnAction setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [sheetView addSubview:btnAction];
        
        [btnAction actionForButton:^(UIButton *button)
        {
            [sheet clickAction:list withIndex:index click:result];
        }];

        if (index < list.count-1)
        {
            [btnAction bottomLineX:0 width:btnAction.width color:nil];
        }
    }
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(10,sheetView.height+20,SCREEN_WIDTH-20,60);
    button.backgroundColor = GradientColor(1,button.size);
    button.titleLabel.font = CommonFontLight(20);
    button.layer.cornerRadius = 11;button.layer.masksToBounds = YES;
    [button setTitle:cancel forState:UIControlStateNormal];button.tag = 0;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [sheet.atView addSubview:button];
    
    [button actionForButton:^(UIButton *button)
    {
        [sheet clickAction:list withIndex:-1 click:result];
    }];
    
    [UIView animateWithDuration:0.25f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        sheet.atView.frame = CGRectMake(0,SCREEN_HEIGHT-height,SCREEN_WIDTH,height);
    }
    completion:^(BOOL finished)
    {
        
    }];
}

- (void)clickAction:(NSArray *)listTitle withIndex:(NSInteger)index
              click:(void(^)(NSInteger index,NSArray *list))result {

    [UIView animateWithDuration:0.25f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        self.atView.frame = CGRectMake(0,SCREEN_HEIGHT,SCREEN_WIDTH,self.atView.height);
    }
    completion:^(BOOL finished)
    {
        if (result)
        {
            result(index,listTitle);
        }
        
        [self.atView removeFromSuperview];self.atView = nil;
        [self.rootView removeFromSuperview];self.rootView = nil;
    }];
}

@end
