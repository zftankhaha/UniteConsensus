//
//  SystemAlertView.h
//  GJDD
//
//  Created by zhangfeng on 15/1/15.
//  Copyright (c) 2015年 zhangfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger,AlertClickType) {
    
    CancelType = 0,
    SureType = 1,
};

@interface UCAlertManager : NSObject

+ (void)show:(NSString *)title message:(NSString *)message
      cancel:(NSString *)cancel sure:(NSString *)sure
       click:(void(^)(AlertClickType clickType))callback;

@end
