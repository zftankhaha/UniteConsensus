//
//  UIScrollView+Refresh.m
//  HBFinance
//
//  Created by zftank on 16/9/13.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "UIScrollView+Refresh.h"
#import "DragWeakRefresh.h"
#import "DragRefresh.h"

@implementation UIScrollView (Refresh)

- (DragRefresh *)dragRefresh {
    
    return objc_getAssociatedObject(self,_cmd);
}

- (void)setDragRefresh:(DragRefresh *)dragRefresh {

    objc_setAssociatedObject(self,@selector(dragRefresh),dragRefresh,OBJC_ASSOCIATION_RETAIN);
}


- (id)actionDelegate {
    
    return objc_getAssociatedObject(self,_cmd);
}

- (void)setActionDelegate:(id)delegate {
    
    if (delegate)
    {
        DragWeakRefresh *weakDelegate = [[DragWeakRefresh alloc] initWithDelegate:delegate];
        
        objc_setAssociatedObject(self,@selector(actionDelegate),weakDelegate,OBJC_ASSOCIATION_RETAIN);
    }
    else
    {
        objc_setAssociatedObject(self,@selector(actionDelegate),nil,OBJC_ASSOCIATION_RETAIN);
    }
}

#pragma mark -
#pragma mark Hook Dealloc

+ (void)load {
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^{
        
        SEL originalSelector = sel_getUid("dealloc");
        SEL swizzledSelector = @selector(hook_dealloc);
        [self shareSwizzled:originalSelector hookMethod:swizzledSelector];
    });
}

- (void)hook_dealloc {
    
    if ([self respondsToSelector:@selector(closeDragRefresh)])
    {
        [self closeDragRefresh];
    }
    
    [self hook_dealloc];
}

#pragma mark -
#pragma mark DragRefresh Methods

- (void)refresh:(id)delegate header:(BOOL)header footer:(BOOL)footer {
    
    if (self.dragRefresh)
    {
        return;
    }
    
    if (!header && !footer)
    {
        return;
    }
    
    self.actionDelegate = delegate;
    self.dragRefresh = [DragRefresh refresh:self header:header footer:footer];
    self.dragRefresh.delegate = self;
}

- (BOOL)currentLoading {
    
    return self.dragRefresh.isLoading;
}

- (void)completeLoading:(BOOL)haveMore {
    
    [self.dragRefresh completeLoading:haveMore];
}

- (void)autoDropDownAction {
    
    [self.dragRefresh autoDropDownAction];
}

- (void)closeDragRefresh {
    
    [self.dragRefresh completeLoading:NO];
    
    if (self.dragRefresh)
    {
        [self removeObserver:self.dragRefresh forKeyPath:kObserverKey];
        
        [self.dragRefresh closeDragRefresh];self.dragRefresh = nil;
    }
    
    self.actionDelegate = nil;
}

#pragma mark -
#pragma mark DragRefresh Delegate Methods

- (void)letRefreshHeaderAction {
    
    id refreshDelegate = [self.actionDelegate weakDelegate];
    
    if (refreshDelegate && [refreshDelegate respondsToSelector:@selector(refreshDataSource:)])
    {
        [refreshDelegate refreshDataSource:YES];
    }
}

- (void)letRefreshFooterAction {
    
    id refreshDelegate = [self.actionDelegate weakDelegate];
    
    if (refreshDelegate && [refreshDelegate respondsToSelector:@selector(refreshDataSource:)])
    {
        [refreshDelegate refreshDataSource:NO];
    }
}

@end
