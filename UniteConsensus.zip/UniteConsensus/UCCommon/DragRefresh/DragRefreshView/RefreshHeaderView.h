//
//  RefreshHeaderView.h
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "DragRefreshView.h"

@interface RefreshHeaderView : DragRefreshView

+ (RefreshHeaderView *)refreshHeaderView:(CGRect)rect;

@end
