//
//  DragRefreshView.m
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "DragRefreshView.h"

@implementation DragRefreshView

- (void)dealloc {

    _rotateAnimation.delegate = nil;
    _rotateAnimation = nil;
    
    [_rotateView.layer removeAllAnimations];
    [_rotateView removeFromSuperview];
    _rotateView = nil;
}

- (instancetype)initWithFrame:(CGRect)frame {

    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        _state = PullRefreshNormal;
    }
    
    return self;
}

- (void)arrowAnimation:(CGFloat)angle duration:(NSTimeInterval)duration number:(CGFloat)number {
    
    self.rotateAnimation.delegate = nil;
    [self.rotateView.layer removeAllAnimations];
    self.rotateAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    self.rotateAnimation.toValue = [NSNumber numberWithFloat:angle];
    self.rotateAnimation.duration = duration;
    self.rotateAnimation.cumulative = YES;
    self.rotateAnimation.repeatCount = number;
    self.rotateAnimation.removedOnCompletion = NO;
    self.rotateAnimation.delegate = self;
    [self.rotateView.layer addAnimation:self.rotateAnimation forKey:@"rotationAnimation"];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {

}

@end
