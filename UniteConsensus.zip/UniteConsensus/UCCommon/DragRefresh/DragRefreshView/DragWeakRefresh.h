//
//  DragWeakRefresh.h
//  HBFastLoan
//
//  Created by zftank on 2017/4/20.
//  Copyright © 2017年 HBFastLoan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DragWeakRefresh : NSObject

@property (nonatomic,weak,readonly) id weakDelegate;

- (instancetype)initWithDelegate:(id)target;

@end
