//
//  RefreshFooterView.m
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "RefreshFooterView.h"

@implementation RefreshFooterView

+ (RefreshFooterView *)refreshFooterView:(CGRect)rect {

    RefreshFooterView *refreshView = [[RefreshFooterView alloc] initWithFrame:rect];
    refreshView.haveMore = YES;
    
    //箭头
    CGSize size = kRefreshImage.size;
    CGRect arect = CGRectMake(0,0,size.width,size.height);
    refreshView.rotateView = [[UIImageView alloc] initWithFrame:arect];
    refreshView.rotateView.center = CGPointMake(SCREEN_WIDTH/2-65,kDragHeight/2);
    refreshView.rotateView.backgroundColor = [UIColor clearColor];
    refreshView.rotateView.image = kRefreshImage;
    [refreshView addSubview:refreshView.rotateView];
    
    //标题
    CGRect sRect = CGRectMake(0,0,SCREEN_WIDTH,kDragHeight);
    refreshView.showTitle = [[UILabel alloc] initWithFrame:sRect];
    refreshView.showTitle.font = CommonFontRegular(15.0f);
    refreshView.showTitle.backgroundColor = [UIColor clearColor];
    refreshView.showTitle.textAlignment = NSTextAlignmentCenter;
    [refreshView addSubview:refreshView.showTitle];
    
    return refreshView;
}

- (void)setState:(PullRefreshState)currentState {
    
    [super setState:currentState];
    
    switch (currentState)
    {
        case PullRefreshPulling:
        {
            self.showTitle.text = @"松开立即刷新";
            [self arrowAnimation:M_PI duration:kCompletion number:0];
            break;
        }
        case PullRefreshNormal:
        case PullRefreshCancel:
        {
            if (self.haveMore)
            {
                self.showTitle.text = @"上拉加载更多";
            }
            else
            {
                self.showTitle.text = @"最后一页啦...";
            }
            
            [self arrowAnimation:-M_PI duration:kCompletion number:0];
            break;
        }
        case PullRefreshLoading:
        {
            self.showTitle.text = @"正在刷新页面";
            [self arrowAnimation:2*M_PI duration:kDuration number:MAXFLOAT];
            break;
        }
        default:
        {
            break;
        }
    }
}

@end
