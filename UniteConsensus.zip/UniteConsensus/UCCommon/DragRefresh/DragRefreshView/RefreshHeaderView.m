//
//  RefreshHeaderView.m
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "RefreshHeaderView.h"

@implementation RefreshHeaderView

+ (RefreshHeaderView *)refreshHeaderView:(CGRect)rect {

    RefreshHeaderView *refreshView = [[RefreshHeaderView alloc] initWithFrame:rect];
    
    CGRect arect = CGRectMake(0,0,120,kDragHeight);
    refreshView.rotateView = [[UIImageView alloc] initWithFrame:arect];
    refreshView.rotateView.center = CGPointMake(SCREEN_WIDTH/2-2,rect.size.height-kDragHeight/2);
    refreshView.rotateView.backgroundColor = [UIColor clearColor];
    refreshView.rotateView.image = kRefreshImage;
    refreshView.rotateView.contentMode = UIViewContentModeCenter;
    [refreshView addSubview:refreshView.rotateView];
    
    return refreshView;
}

- (void)setState:(PullRefreshState)currentState {
    
    [super setState:currentState];
    
    switch (currentState)
    {
        case PullRefreshPulling:
        {
            [self arrowAnimation:M_PI duration:kCompletion number:0];
            break;
        }
        case PullRefreshNormal:
        {
            [self arrowAnimation:-M_PI duration:kCompletion number:0];
            break;
        }
        case PullRefreshLoading:
        {
            [self arrowAnimation:2*M_PI duration:kDuration number:MAXFLOAT];
            break;
        }
        default:
        {
            break;
        }
    }
}

@end
