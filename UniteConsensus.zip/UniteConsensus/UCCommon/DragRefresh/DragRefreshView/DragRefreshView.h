//
//  DragRefreshView.h
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM (NSInteger,PullRefreshState) {
    
    PullRefreshPulling = 0,         //松手即可刷新
    PullRefreshNormal = 1,          //初始状态//默认值
    PullRefreshLoading = 2,         //正在加载数据
    PullRefreshCancel = 3,          //上拉刷新被下拉刷新取消
};

#define kDuration         0.9f
#define kCompletion       0.25f
#define kDragHeight       66.0f

#define kRefreshImage    [UIImage imageNamed:@"refresha"]

@interface DragRefreshView : UIView <CAAnimationDelegate>

@property (nonatomic,assign) PullRefreshState state;
@property (nonatomic,strong) CABasicAnimation *rotateAnimation;
@property (nonatomic,strong) UIImageView *rotateView;
@property (nonatomic,strong) UILabel *showTitle;

- (void)arrowAnimation:(CGFloat)angle duration:(NSTimeInterval)duration number:(CGFloat)number;

@end
