//
//  HBDragRefresh.m
//  HBFinance
//
//  Created by zftank on 16/9/4.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "DragRefresh.h"
#include <objc/message.h>

@implementation DragRefresh

- (void)dealloc {
    
    [self closeDragRefresh];
}

- (void)closeDragRefresh {

    self.delegate = nil;
    
    if (!UIEdgeInsetsEqualToEdgeInsets(self.scrollView.contentInset,UIEdgeInsetsZero))
    {
        self.scrollView.contentInset = UIEdgeInsetsZero;
    }
    
    self.scrollView = nil;
    
    self.headerView.rotateAnimation.delegate = nil;
    [self.headerView.rotateView.layer removeAllAnimations];
    [self.headerView removeFromSuperview];
    self.headerView = nil;
    
    self.footerView.rotateAnimation.delegate = nil;
    [self.footerView.rotateView.layer removeAllAnimations];
    [self.footerView removeFromSuperview];
    self.footerView = nil;
}

+ (DragRefresh *)refresh:(UIScrollView *)rootView header:(BOOL)header footer:(BOOL)footer {
    
    DragRefresh *manager = [[DragRefresh alloc] init];
    
    manager.isLoading = NO;
    manager.scrollView = rootView;
    
    if (header)
    {
        CGRect hRect = CGRectMake(0,-rootView.height,rootView.width,rootView.height);
        manager.headerView = [RefreshHeaderView refreshHeaderView:hRect];
        [manager.scrollView addSubview:manager.headerView];
    }
    
    if (footer)
    {
        CGRect fRect = CGRectMake(0,rootView.height,rootView.width,rootView.height);
        manager.footerView = [RefreshFooterView refreshFooterView:fRect];
        [manager.scrollView addSubview:manager.footerView];
    }
    
    NSKeyValueObservingOptions options = NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld;
    [manager.scrollView addObserver:manager forKeyPath:kObserverKey options:options context:nil];
    
    return manager;
}

#pragma mark -
#pragma mark KVO Methods

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
                        change:(NSDictionary *)change context:(void *)context {
    
    if (!self.headerView && !self.footerView)
    {
        return;
    }
    
    if (self.footerView)
    {
        CGRect rect = self.footerView.frame;
        
        CGFloat SY = self.scrollView.contentSize.height;
        
        if (SY < self.scrollView.height)
        {
            SY = self.scrollView.height;
        }
        
        self.footerView.frame = CGRectMake(0,SY,rect.size.width,rect.size.height);
    }
    
    if (self.headerView && self.headerView.state == PullRefreshLoading)
    {
        CGFloat offset = MAX(-1*self.scrollView.contentOffset.y,0);
        offset = MIN(offset,kDragHeight);
        self.scrollView.contentInset = UIEdgeInsetsMake(offset,0,0,0);
        
        return;
    }
    
    if (self.scrollView.isDragging)
    {
        if (self.headerView)
        {
            CGFloat OffY = self.scrollView.contentOffset.y;
            
            if ((self.headerView.state == PullRefreshPulling) && (-kDragHeight < OffY) && (OffY < 0))
            {
                self.headerView.state = PullRefreshNormal;
            }
            else if ((self.headerView.state == PullRefreshNormal) && (OffY < -kDragHeight))
            {
                self.headerView.state = PullRefreshPulling;
            }
            
            if (self.scrollView.contentInset.top != 0)
            {
                self.scrollView.contentInset = UIEdgeInsetsZero;
            }
        }
        
        if (self.footerView && self.footerView.haveMore && self.footerView.state != PullRefreshLoading)
        {
            CGFloat OffY = self.scrollView.contentOffset.y;
            CGFloat CSH = self.scrollView.contentSize.height-self.scrollView.height;
            
            CGFloat distance;
            
            if (CSH <= 0)
            {
                distance = kDragHeight;
            }
            else
            {
                distance = CSH+kDragHeight;
            }
            
            if ((self.footerView.state == PullRefreshPulling) && (CSH < OffY) && (OffY < distance))
            {
                self.footerView.state = PullRefreshNormal;
            }
            else if ((self.footerView.state == PullRefreshNormal) && (distance < OffY))
            {
                self.footerView.state = PullRefreshPulling;
            }
            
            if (self.scrollView.contentInset.bottom != 0)
            {
                self.scrollView.contentInset = UIEdgeInsetsZero;
            }
        }
    }
    else
    {
        [self completeDragAction];
    }
}

- (void)completeDragAction {
    
    if (self.headerView && self.headerView.state == PullRefreshPulling)
    {
        self.isLoading = YES;
        
        self.headerView.state = PullRefreshLoading;
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(letRefreshHeaderAction)])
        {
            [self.delegate letRefreshHeaderAction];
        }
        
        if (self.footerView && self.footerView.state == PullRefreshLoading && self.footerView.haveMore)
        {
            self.footerView.state = PullRefreshCancel;
        }
        
        [UIView animateWithDuration:0.15f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^
        {
            self.scrollView.contentInset = UIEdgeInsetsMake(kDragHeight,0,0,0);
        }
        completion:^(BOOL finished)
        {
            
        }];
    }
    
    if (self.footerView && self.footerView.state == PullRefreshPulling && self.footerView.haveMore)
    {
        self.isLoading = YES;
        
        self.footerView.state = PullRefreshLoading;
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(letRefreshFooterAction)])
        {
            [self.delegate letRefreshFooterAction];
        }
        
        CGFloat distance = self.scrollView.height-self.scrollView.contentSize.height;
        
        if (distance < 0)
        {
            distance = 0.0f;
        }
        
        [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^
        {
            self.scrollView.contentInset = UIEdgeInsetsMake(0,0,distance+kDragHeight,0);
        }
        completion:^(BOOL finished)
        {
            self.scrollView.contentInset = UIEdgeInsetsMake(0,0,distance+kDragHeight,0);
        }];
    }
}

- (void)completeLoading:(BOOL)haveMore {
    
    if (self.footerView && (self.footerView.state == PullRefreshLoading || self.footerView.state == PullRefreshCancel))
    {
        self.footerView.haveMore = haveMore;
        self.footerView.state = PullRefreshNormal;
        [self performSelector:@selector(restoreAction) withObject:nil afterDelay:0.0f inModes:@[NSRunLoopCommonModes]];
    }
    else if (self.headerView && self.headerView.state == PullRefreshLoading)
    {
        self.headerView.state = PullRefreshNormal;
        
        self.footerView.haveMore = YES;
        self.footerView.state = PullRefreshNormal;
        [self performSelector:@selector(restoreAction) withObject:nil afterDelay:0.0f inModes:@[NSRunLoopCommonModes]];
    }
}

- (void)restoreAction {

    [UIView animateWithDuration:0.35f animations:^
    {
        self.scrollView.contentInset = UIEdgeInsetsZero;
    }
    completion:^(BOOL finished)
    {
        self.isLoading = NO;
        self.scrollView.contentInset = UIEdgeInsetsZero;
    }];
}

- (void)autoDropDownAction {
    
    if (self.headerView && self.headerView.state == PullRefreshNormal)
    {
        self.headerView.state = PullRefreshPulling;
        self.scrollView.contentOffset = CGPointZero;
        
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^
        {
            self.scrollView.contentOffset = CGPointMake(0,-kDragHeight);
        }
        completion:^(BOOL finished)
        {
            [self completeDragAction];
        }];
    }
}


@end
