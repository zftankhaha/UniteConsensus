//
//  DragWeakRefresh.m
//  HBFastLoan
//
//  Created by zftank on 2017/4/20.
//  Copyright © 2017年 HBFastLoan. All rights reserved.
//

#import "DragWeakRefresh.h"

@interface DragWeakRefresh ()

@property (nonatomic,weak) id weakDelegate;

@end

@implementation DragWeakRefresh

- (instancetype)initWithDelegate:(id)target {

    self = [super init];
    
    if (self)
    {
        self.weakDelegate = target;
    }
    
    return self;
}

@end
