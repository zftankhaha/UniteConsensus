//
//  UIScrollView+Refresh.h
//  HBFinance
//
//  Created by zftank on 16/9/13.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HBDragRereshDelegate <NSObject>

- (void)refreshDataSource:(BOOL)refreshDrop;//开始转圈

@end

@interface UIScrollView (Refresh)

- (void)refresh:(id)delegate header:(BOOL)header footer:(BOOL)footer;//加载下拉刷新

- (BOOL)currentLoading;

- (void)completeLoading:(BOOL)haveMore;//完成刷新，haveMore是否已到最后一页


- (void)autoDropDownAction;//自动显示下拉刷新

- (void)closeDragRefresh;//关闭下拉刷新

@end
