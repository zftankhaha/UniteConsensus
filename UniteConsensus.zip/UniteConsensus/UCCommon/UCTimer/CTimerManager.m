//
//  CTimerManager.m
//  BCExchange
//
//  Created by zftank on 2018/8/29.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "CTimerManager.h"

@interface CTimer : NSObject

@property (nonatomic,weak) id delegate;

@property (nonatomic,strong) NSTimer *countDown;

@property (nonatomic,assign) CGFloat step;

@property (nonatomic,assign) NSInteger number;//当前计数

@end

@implementation CTimer

- (void)dealloc {
    
    _delegate = nil;
    [self stopTimer];
}

- (instancetype)initDelegate:(id)delegate step:(CGFloat)step {
    
    self = [super init];
    
    if (self)
    {
        _delegate = delegate;
        
        _step = step;
        
        _number = 0;
    }
    
    return self;
}

- (void)startCountTimer {
    
    [self stopTimer];
    self.countDown = [NSTimer timerWithTimeInterval:self.step target:self
                                           selector:@selector(countAction:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.countDown forMode:NSRunLoopCommonModes];
}

- (void)stopTimer {
    
    self.number = 0;
    [[NSRunLoop currentRunLoop] cancelPerformSelectorsWithTarget:self];
    [self.countDown invalidate];self.countDown = nil;
}

- (void)countAction:(id)sender {
    
    self.number += self.step;
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(touchTimerAction)])
    {
        [self.delegate touchTimerAction];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(revolutionTimerAction:)])
    {
        [self.delegate revolutionTimerAction:nil];
    }
}

@end

@interface CTimerManager ()

@property (nonatomic,strong) CTimer *hbTimer;

@end

@implementation CTimerManager

- (void)dealloc {
    
    _delegate = nil;
    _hbTimer.delegate = nil;
    [_hbTimer stopTimer];
    _hbTimer = nil;
}

- (instancetype)initDelegate:(id)delegate step:(CGFloat)step {
    
    self = [super init];
    
    if (self)
    {
        _delegate = delegate;
        
        _hbTimer = [[CTimer alloc] initDelegate:self step:step];
    }
    
    return self;
}

- (void)startCountTimer {
    
    self.hbTimer.delegate = self;
    
    [self.hbTimer startCountTimer];
}

- (void)stopTimer {
    
    self.hbTimer.delegate = nil;
    
    [self.hbTimer stopTimer];
}

- (NSInteger)number {
    
    return self.hbTimer.number;
}

- (void)touchTimerAction {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(touchTimerAction)])
    {
        [self.delegate touchTimerAction];
    }
}

- (void)revolutionTimerAction:(CTimerManager *)timer {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(revolutionTimerAction:)])
    {
        [self.delegate revolutionTimerAction:self];
    }
}

@end
