//
//  CTimerManager.h
//  BCExchange
//
//  Created by zftank on 2018/8/29.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CTimerManager;

@protocol CTimerDelegate <NSObject>

@optional

- (void)touchTimerAction;

- (void)revolutionTimerAction:(CTimerManager *)timer;

@end

@interface CTimerManager : NSObject


@property (nonatomic,weak) id delegate;

@property (nonatomic,assign) NSInteger number;//当前计数


- (instancetype)initDelegate:(id)delegate step:(CGFloat)step;//step步长

- (void)startCountTimer;

- (void)stopTimer;

@end
