//
//  NSObject+Hook.m
//  BCExchange
//
//  Created by zftank on 2018/7/11.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "NSObject+Hook.h"

void CommonSwizzled(Class class,SEL currentSEL,SEL hookSEL) {
    
    if (class && currentSEL && hookSEL)
    {
        Method oneMethod = class_getInstanceMethod(class,currentSEL);
        
        Method twoMethod = class_getInstanceMethod(class,hookSEL);
        
        if (class_addMethod(class,currentSEL,method_getImplementation(twoMethod),method_getTypeEncoding(twoMethod)))
        {
            class_replaceMethod(class,hookSEL,method_getImplementation(oneMethod),method_getTypeEncoding(oneMethod));
        }
        else
        {
            method_exchangeImplementations(oneMethod,twoMethod);
        }
    }
}

@implementation NSObject (Hook)

+ (void)shareSwizzled:(SEL)currentSEL hookMethod:(SEL)hookSEL {
    
    CommonSwizzled(self.class,currentSEL,hookSEL);
}

@end
