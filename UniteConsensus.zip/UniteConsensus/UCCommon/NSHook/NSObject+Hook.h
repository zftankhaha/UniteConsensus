//
//  NSObject+Hook.h
//  BCExchange
//
//  Created by zftank on 2018/7/11.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Hook)

+ (void)shareSwizzled:(SEL)currentSEL hookMethod:(SEL)hookSEL;

@end
