//
//  UITableView+Adaptation.m
//  BCExchange
//
//  Created by zftank on 2018/7/19.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "UITableView+Adaptation.h"

@implementation UITableView (Adaptation)

+ (void)load {
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^{
        
        SEL originalSelector = @selector(willMoveToSuperview:);
        SEL swizzledSelector = @selector(hook_willMoveToSuperview:);
        [self shareSwizzled:originalSelector hookMethod:swizzledSelector];
    });
}

- (void)hook_willMoveToSuperview:(UIView *)newSuperview {
    
    [self hook_willMoveToSuperview:newSuperview];
    
    self.estimatedRowHeight = 0;
    self.estimatedSectionHeaderHeight = 0;
    self.estimatedSectionFooterHeight = 0;
}

@end
