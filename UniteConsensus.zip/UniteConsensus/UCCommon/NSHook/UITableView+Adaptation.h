//
//  UITableView+Adaptation.h
//  BCExchange
//
//  Created by zftank on 2018/7/19.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (Adaptation)

@end
