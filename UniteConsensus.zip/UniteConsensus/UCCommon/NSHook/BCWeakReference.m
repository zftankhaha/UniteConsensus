//
//  BCWeakReference.m
//  BCExchange
//
//  Created by zftank on 2018/9/20.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "BCWeakReference.h"

@implementation BCWeakReference

- (instancetype)initWithDelegate:(id)target {

    self = [super init];
    
    if (self)
    {
        self.delegate = target;
    }
    
    return self;
}

@end
