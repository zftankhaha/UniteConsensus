//
//  UIButton+Exclusive.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/17.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "UIButton+Exclusive.h"

@implementation UIButton (Exclusive)

+ (void)load {
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^{
        
        SEL originalSelector = @selector(willMoveToSuperview:);
        SEL swizzledSelector = @selector(hook_willMoveToSuperview:);
        [self shareSwizzled:originalSelector hookMethod:swizzledSelector];
    });
}

- (void)hook_willMoveToSuperview:(UIView *)newSuperview {
    
    [self hook_willMoveToSuperview:newSuperview];
    self.exclusiveTouch = YES;
    self.adjustsImageWhenHighlighted = NO;
}

@end
