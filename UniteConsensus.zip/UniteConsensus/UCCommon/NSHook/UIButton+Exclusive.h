//
//  UIButton+Exclusive.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/17.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Exclusive)

@end
