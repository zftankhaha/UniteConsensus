//
//  BCWeakReference.h
//  BCExchange
//
//  Created by zftank on 2018/9/20.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BCWeakReference : NSObject

@property (nonatomic,weak) id delegate;

@property (nonatomic,copy) void(^completion)(id action);

- (instancetype)initWithDelegate:(id)target;

@end
