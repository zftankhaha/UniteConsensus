//
//  UILabel+AdaptiveSize.m
//  BCExchange
//
//  Created by zftank on 2018/7/11.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "UILabel+AdaptiveSize.h"

@implementation UILabel (AdaptiveSize)

+ (void)load {
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^{
        
        SEL originalSelector = @selector(willMoveToSuperview:);
        SEL swizzledSelector = @selector(hook_willMoveToSuperview:);
        [self shareSwizzled:originalSelector hookMethod:swizzledSelector];
    });
}

- (void)hook_willMoveToSuperview:(UIView *)newSuperview {
    
    [self hook_willMoveToSuperview:newSuperview];
    
    self.adjustsFontSizeToFitWidth = YES;
}

@end
