//
//  UILabel+AdaptiveSize.h
//  BCExchange
//
//  Created by zftank on 2018/7/11.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (AdaptiveSize)

@end
