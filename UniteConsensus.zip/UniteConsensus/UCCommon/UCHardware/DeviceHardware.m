//
//  UserDeviceInfo.m
//  BCExchange
//
//  Created by zftank on 2018/8/24.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "DeviceHardware.h"
#import <sys/utsname.h>

@implementation DeviceHardware

#pragma mark -
#pragma mark 获取设备型号

+ (DeviceType)currentDeviceMode {
    
    static DeviceType deviceType = Unknown;
    
    if (deviceType == Unknown)
    {
        deviceType = [DeviceHardware checkDeviceType];
    }
    
    return deviceType;
}

+ (DeviceType)checkDeviceType {
    
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *plateform = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
  
    if ([plateform isEqualToString:@"i386"] || [plateform isEqualToString:@"x86_64"])
    {
        plateform = NSProcessInfo.processInfo.environment[@"SIMULATOR_MODEL_IDENTIFIER"];
        return Simulator;
        return IPhone_X;
    }
    
    if ([plateform isEqualToString:@"iPhone1,1"])     return IPhone_1G;
    if ([plateform isEqualToString:@"iPhone1,2"])     return IPhone_3G;
    if ([plateform isEqualToString:@"iPhone2,1"])     return IPhone_3GS;
    if ([plateform isEqualToString:@"iPhone3,1"])     return IPhone_4;
    if ([plateform isEqualToString:@"iPhone3,2"])     return IPhone_4;
    if ([plateform isEqualToString:@"iPhone4,1"])     return IPhone_4s;
    if ([plateform isEqualToString:@"iPhone5,1"])     return IPhone_5;
    if ([plateform isEqualToString:@"iPhone5,2"])     return IPhone_5;
    if ([plateform isEqualToString:@"iPhone5,3"])     return IPhone_5C;
    if ([plateform isEqualToString:@"iPhone5,4"])     return IPhone_5C;
    if ([plateform isEqualToString:@"iPhone6,1"])     return IPhone_5S;
    if ([plateform isEqualToString:@"iPhone6,2"])     return IPhone_5S;
    if ([plateform isEqualToString:@"iPhone7,1"])     return IPhone_6P;
    if ([plateform isEqualToString:@"iPhone7,2"])     return IPhone_6;
    if ([plateform isEqualToString:@"iPhone8,1"])     return IPhone_6s;
    if ([plateform isEqualToString:@"iPhone8,2"])     return IPhone_6s_P;
    if ([plateform isEqualToString:@"iPhone8,4"])     return IPhone_SE;
    if ([plateform isEqualToString:@"iPhone9,1"])     return IPhone_7;
    if ([plateform isEqualToString:@"iPhone9,3"])     return IPhone_7;
    if ([plateform isEqualToString:@"iPhone9,2"])     return IPhone_7P;
    if ([plateform isEqualToString:@"iPhone9,4"])     return IPhone_7P;
    if ([plateform isEqualToString:@"iPhone10,1"])    return IPhone_8;
    if ([plateform isEqualToString:@"iPhone10,4"])    return IPhone_8;
    if ([plateform isEqualToString:@"iPhone10,2"])    return IPhone_8P;
    if ([plateform isEqualToString:@"iPhone10,5"])    return IPhone_8P;
    
    if ([plateform isEqualToString:@"iPhone10,3"])    return IPhone_X;
    if ([plateform isEqualToString:@"iPhone10,6"])    return IPhone_X;
    
    if ([plateform isEqualToString:@"iPhone11,2"])    return IPhone_XS;
    if ([plateform isEqualToString:@"iPhone11,4"])    return IPhone_XS_Max;
    if ([plateform isEqualToString:@"iPhone11,6"])    return IPhone_XS_Max;
    if ([plateform isEqualToString:@"iPhone11,8"])    return IPhone_XR;
    
    return Unknown;
}

#pragma mark -
#pragma mark 判断是否IphoneX及以后设备

+ (BOOL)containXAndAbove {
    
    return (IPhone_X <= [DeviceHardware currentDeviceMode]);
}

@end
