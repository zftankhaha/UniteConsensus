//
//  UserDeviceInfo.h
//  BCExchange
//
//  Created by zftank on 2018/8/24.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,DeviceType) {
    
    Unknown = 80800,       //未知类型
    Simulator = 101,       //模拟器
    
    IPhone_1G = 102,
    IPhone_3G = 103,
    IPhone_3GS = 104,
    IPhone_4 = 105,
    IPhone_4s = 106,
    IPhone_5 = 107,
    IPhone_5C = 108,
    IPhone_5S = 109,
    IPhone_SE = 110,
    IPhone_6 = 111,
    IPhone_6P = 112,
    IPhone_6s = 113,
    IPhone_6s_P = 114,
    IPhone_7 = 115,
    IPhone_7P = 116,
    IPhone_8 = 117,
    IPhone_8P = 118,
    
    IPhone_X = 119,
    IPhone_XS = 120,
    IPhone_XS_Max = 121,
    IPhone_XR = 122,
};

@interface DeviceHardware : NSObject

#pragma mark -
#pragma mark 获取设备型号

+ (DeviceType)currentDeviceMode;

#pragma mark -
#pragma mark 判断是否IphoneX及以后设备

+ (BOOL)containXAndAbove;

@end
