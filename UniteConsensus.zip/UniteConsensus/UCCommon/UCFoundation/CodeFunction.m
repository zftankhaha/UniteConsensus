//
//  EDCFunction.m
//  PanoramicVideo
//
//  Created by zftank on 16/9/1.
//  Copyright © 2016年 PanoramicVideo. All rights reserved.
//

#import "CodeFunction.h"
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>

@implementation CodeFunction

+ (NSString *)MD5:(NSString *)string {
    
    if (string && [string isKindOfClass:[NSString class]])
    {
        const char *cStr = [string UTF8String];
        unsigned char result[CC_MD5_DIGEST_LENGTH];
        CC_MD5(cStr,(CC_LONG)strlen(cStr),result);
        
        return [NSString stringWithFormat:@"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                result[0],result[1],result[2],result[3],result[4],result[5],result[6],result[7],
                result[8],result[9],result[10],result[11],result[12],result[13],result[14],result[15]];
    }
    
    return @"";
}

#pragma mark -
#pragma mark base64 Methods

+ (void)base64Data:(NSData *)data result:(void(^)(NSString *encode))result {

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{
        
        NSString *string = nil;
        
        if (data && [data isKindOfClass:[NSData class]])
        {
            string = [data base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
        }
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (result)
            {
                result(string);
            }
        });
    });
}

+ (void)base64Image:(UIImage *)dataImage result:(void(^)(NSString *encode))result {

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{
        
        NSString *strImage = nil;
        
        if (dataImage && [dataImage isKindOfClass:[UIImage class]])
        {
            NSData *originData = UIImagePNGRepresentation(dataImage);
            
            strImage = [originData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
        }
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (result)
            {
                result(strImage);
            }
        });
    });
}

+ (void)base64ImageString:(NSString *)base64Str result:(void(^)(UIImage *image))result {

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
    {
        UIImage *img = nil;
        
        NSData *data = [[NSData alloc] initWithBase64EncodedString:base64Str options:NSDataBase64DecodingIgnoreUnknownCharacters];
        
        if (data && [data isKindOfClass:[NSData class]])
        {
            img = [UIImage imageWithData:data];
        }

        dispatch_async(dispatch_get_main_queue(), ^{

            if (result) {
                result(img);
            }
        });
    });
}

#pragma mark -
#pragma mark JSON Methods

+ (id)objectFromJSONData:(NSString *)json {

    if ([BKCheckValid checkStringValid:json])
    {
        NSData *sourceData = [json dataUsingEncoding:NSUTF8StringEncoding];
    
        return [NSJSONSerialization JSONObjectWithData:sourceData options:NSJSONReadingAllowFragments error:nil];
    }
    
    return nil;
}

+ (NSData *)JSONDataFromObject:(id)object {
    
    if (object)
    {
        return [NSJSONSerialization dataWithJSONObject:object options:0 error:nil];
    }
    
    return nil;
}

+ (NSString *)JSONStringFromObject:(id)object {

    if (object)
    {
        NSData *data = [NSJSONSerialization dataWithJSONObject:object options:0 error:nil];
        
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    
    return nil;
}

@end
