//
//  NSString+Formats.h
//  BCExchange
//
//  Created by zftank on 2018/7/24.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Formats)

/*****************************************/
/*****  在指定范围内计算字符串所占的size  *****/
/*****************************************/

- (CGSize)reckonSpace:(UIFont *)font width:(CGFloat)width;

/********************************/
/***  @"yyyy-MM-dd HH:mm:ss"  ***/
/********************************/

- (NSString *)convertTimeFormat:(NSString *)format;

#pragma mark -
#pragma mark 判断是否浮点数

- (BOOL)checkFloatNumber;

- (BOOL)checkPureNumber;//判断是否整数

#pragma mark -
#pragma mark 判断是否手机号码

- (BOOL)isPhoneNumber;

#pragma mark -
#pragma mark 判断是否固定电话

- (BOOL)validateTelphone;

#pragma mark -
#pragma mark 判断是否邮箱地址

- (BOOL)checkEmailAddress;

#pragma mark -
#pragma mark 判断是否包含condition中的某个字符

- (BOOL)checkContainWithCondition:(NSString *)condition;

#pragma mark -
#pragma mark 检查是否是合法的用户名，只能包含a-z A-Z 0-9

- (BOOL)checkUserName;

#pragma mark -
#pragma mark 检查是否是合法的密码

- (BOOL)checkPassword;

#pragma mark -
#pragma mark 检查是否是合法的GA/邮箱验证码/资金密码

- (BOOL)checkPureNumberPassword;

#pragma mark -
#pragma mark 检查字符串所有字符是否相等

- (BOOL)checkAllCharSame;

//按照字符串第一位生成色值
- (NSString *)colorString;


//字符串长度，汉字算两位
- (NSUInteger)unicodeLength;

//截取字符串，按照unicode编码长度
- (NSString *)substringToUnicodeIndex:(NSUInteger)index;

@end
