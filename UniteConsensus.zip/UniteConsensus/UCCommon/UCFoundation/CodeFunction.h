//
//  EDCFunction.h
//  PanoramicVideo
//
//  Created by zftank on 16/9/1.
//  Copyright © 2016年 PanoramicVideo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface CodeFunction : NSObject

+ (NSString *)MD5:(NSString *)string;

#pragma mark -
#pragma mark base64 Methods

+ (void)base64Data:(NSData *)data result:(void(^)(NSString *encode))result;

+ (void)base64Image:(UIImage *)dataImage result:(void(^)(NSString *encode))result;

+ (void)base64ImageString:(NSString *)base64Str result:(void(^)(UIImage *image))result;

#pragma mark -
#pragma mark JSON Methods

+ (id)objectFromJSONData:(NSString *)json;

+ (NSData *)JSONDataFromObject:(id)object;

+ (NSString *)JSONStringFromObject:(id)object;

@end
