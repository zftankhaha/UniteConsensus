//
//  NSString+Formats.m
//  BCExchange
//
//  Created by zftank on 2018/7/24.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "NSString+Formats.h"

@implementation NSString (Formats)

/*****************************************/
/*****  在指定范围内计算字符串所占的size  *****/
/*****************************************/

- (CGSize)reckonSpace:(UIFont *)font width:(CGFloat)width {
    
    if (!font)
    {
        font = [UIFont systemFontOfSize:13.0f];
    }
    
    if (width < 0.0f || SCREEN_WIDTH < width)
    {
        width = SCREEN_WIDTH;
    }
    
    NSStringDrawingOptions drawMode = NSStringDrawingTruncatesLastVisibleLine |
    NSStringDrawingUsesLineFragmentOrigin |
    NSStringDrawingUsesFontLeading;
    
    return [self boundingRectWithSize:CGSizeMake(width,30000.0f)
                              options:drawMode
                           attributes:[NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName]
                              context:nil].size;
}

/********************************/
/***  @"yyyy-MM-dd HH:mm:ss"  ***/
/********************************/

- (NSString *)convertTimeFormat:(NSString *)format {
    
    long long time = [self longLongValue];
    
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:time];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:format];
    
    return [formatter stringFromDate:date];
}

#pragma mark -
#pragma mark 判断是否浮点数

- (BOOL)checkFloatNumber {
    
    NSScanner *scan = [NSScanner scannerWithString:self];
    
    float val;
    
    BOOL result = [scan scanFloat:&val] && [scan isAtEnd];
    
    return result;
}

- (BOOL)checkPureNumber {
    
    NSScanner* scan = [NSScanner scannerWithString:self];

    int val;

    return[scan scanInt:&val] && [scan isAtEnd];
}

#pragma mark -
#pragma mark 判断是否手机号码

- (BOOL)isPhoneNumber {
    
    return ([self checkPureNumber] && (10 < self.length));
}

#pragma mark -
#pragma mark 判断是否固定电话

- (BOOL)validateTelphone {
    
    NSString *match1 = @"^(0\\d{2,5}-)?[2-9][0-9]{6,7}(-\\d{2,5})?$"; //有0打头的2到5位区号或没有，有分机号或没有
    NSPredicate *matchTest1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",match1];
    BOOL isMatch1 = [matchTest1 evaluateWithObject:self];
    
    NSString *match2 = @"^(?!\\d+(-\\d+){3,})[48]00(-?\\d){7,10}$"; //400或800开头的号码
    NSPredicate *matchTest2 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",match2];
    BOOL isMatch2 = [matchTest2 evaluateWithObject:self];
    
    if ( isMatch1 || isMatch2)
    {
        return TRUE;
    }
    
    return FALSE;
}

#pragma mark -
#pragma mark 判断是否邮箱地址

- (BOOL)checkEmailAddress {
    
    if (self.length <= 0)
    {
        return NO;
    }
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",emailRegex];
    
    return [emailTest evaluateWithObject:self];
}

#pragma mark -
#pragma mark 判断是否包含condition中的某个字符

- (BOOL)checkContainWithCondition:(NSString *)condition {
    
    if (self.length <= 0)
    {
        return NO;
    }
    
    NSRegularExpression *regular = [NSRegularExpression regularExpressionWithPattern:condition
                                                                             options:NSRegularExpressionCaseInsensitive
                                                                               error:nil];
    
    NSInteger number = [regular numberOfMatchesInString:self options:NSMatchingReportProgress
                                                  range:NSMakeRange(0,self.length)];
    
    if (0 < number)
    {
        return YES;
    }
    
    return NO;
}

- (BOOL)checkUserName {
    
    if (self.length <= 0)
    {
        return NO;
    }
    
    NSString *userNameRegex = @"[A-Z0-9a-z._]{5,20}";
    
    NSPredicate *userNameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",userNameRegex];
    
    return [userNameTest evaluateWithObject:self];
}

- (BOOL)checkPassword {
   
    if (self.length < 8 || 32 < self.length)
    {
        return NO;
    }
    
    //判断字母
    BOOL check1 = [self checkContainWithCondition:@"[A-Za-z]"];
    
    //判断数字
    BOOL check2 = [self checkContainWithCondition:@"[0-9]"];
    
    return check1 && check2;
}

- (BOOL)checkPureNumberPassword {
    
    return [self checkPureNumber] && self.length == 6;
}

- (BOOL)checkAllCharSame {
    
    if (self.length <= 1)
    {
        return NO;
    }
    
    unichar c = 0;
    BOOL hasSame = YES;
    
    for (int i = 0; i < self.length; ++i)
    {
        unichar character = [self characterAtIndex:i];
        
        if (c == 0)
        {
            c = character;
        }
        else
        {
            hasSame &= c == character;
        }
    }
    
    return hasSame;
}

- (NSString *)colorString {
    
    static NSArray *colorArray = nil;
    
    if (!colorArray)
    {
        colorArray = @[@"d3773d",@"6d8cca",@"8a9567",@"77ad07",@"9a4b43",@"d3773d",@"6d8cca",@"8a9567",@"77ad07",@"9a4b43"];
    }
    
    if (self.length <= 0){return [colorArray firstObject];}
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    char byte;
    [data getBytes:&byte range:NSMakeRange(data.length-1,1)];
    int index = byte % 10;
    if (index < 0){index += 10;}
    return [colorArray objectAtIndex:index];
}

- (NSUInteger)unicodeLength {
    
    NSUInteger length = 0;
    
    for (NSInteger i = 0; i < self.length; ++i)
    {
        unichar c = [self characterAtIndex:i];
        
        if (c < 255)
        {
            length += 1;
        }
        else
        {
            length += 2;
        }
    }
    return length;
}

- (NSString *)substringToUnicodeIndex:(NSUInteger)index {
    NSUInteger length = 0;
    NSInteger i = 0;
    for (; i < self.length; ++i) {
        unichar c = [self characterAtIndex:i];
        if (c < 0xff) {
            length += 1;
        }
        else {
            length += 2;
        }
        if (length > index) {
            break;
        }
    }
    return [self substringToIndex:i];
}

@end
