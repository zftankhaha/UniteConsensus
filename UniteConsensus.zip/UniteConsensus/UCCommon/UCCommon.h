//
//  UCCommon.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/31.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#ifndef UCCommon_h
#define UCCommon_h

#import "NSObject+Hook.h"
#import "BCWeakReference.h"
#import "UILabel+AdaptiveSize.h"
#import "UIButton+Exclusive.h"
#import "UITableView+Adaptation.h"

#import "UIView+DrawLine.h"
#import "UIView+Coordinate.h"
#import "UIColor+HexColor.h"
#import "UIButton+Create.h"
#import "UILabel+Create.h"
#import "UITableViewCell+Extend.h"

#import "DeviceCommon.h"
#import "DeviceHardware.h"

#import "UCSheetManager.h"
#import "BlurEffectManager.h"
#import "UCShowHUD.h"
#import "UCAlertManager.h"

#import "XLCycleView.h"
#import "UIHeaderView.h"

#import "UIScrollView+Refresh.h"
#import "CTimerManager.h"
#import "FileManager.h"

#import "BKCheckValid.h"
#import "CodeFunction.h"
#import "NSString+Formats.h"

//*************************//
//********* Host **********//
//*************************//

#define kConsensusHost         @"https://coin.hehuoya.com/index.php/"

//*************************//
//******** Common *********//
//*************************//

#define APP_VERSION            [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]
#define APP_SHORT_VERSION      [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
#define APP_BUNDLE_NAME        [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"]

#define System_Version         [[[UIDevice currentDevice] systemVersion] floatValue]//操作系统版本

#define WEAKSELF               __weak typeof(self) weakSelf = self;
#define STRONGSELF             __strong typeof(weakSelf) strongSelf = weakSelf;

#define CommonNotification     [NSNotificationCenter defaultCenter]

#define UISCREEN_BOUNDS        [[UIScreen mainScreen] bounds]//屏幕的bounds
#define SCREEN_WIDTH           UISCREEN_BOUNDS.size.width//屏幕的总宽度
#define SCREEN_HEIGHT          UISCREEN_BOUNDS.size.height//屏幕的总高度

#define ContainXAndAbove       [DeviceHardware containXAndAbove]//判断是否IphoneX及以后设备
        
#define StatusBar_HEIGHT       (ContainXAndAbove?44:20)//顶部状态栏的高度
#define HeadBar_HEIGHT         (ContainXAndAbove?88:64)//顶部导航的高度//包含顶部状态栏的高度

#define TabBar_HEIGHT          (ContainXAndAbove?83:49)//tabBar的高度//包含底部危险区域的高度
#define Bottom_HEIGHT          (ContainXAndAbove?34:0)//底部危险区域的高度

//*************************//
//******** UIFont *********//
//*************************//

#define CommonFontLight(absize)     [UIFont fontWithName:@"HelveticaNeue-Light" size:absize]
#define CommonFontRegular(absize)   [UIFont fontWithName:@"PingFangSC-Regular" size:absize]

//*************************//
//******** UIColor ********//
//*************************//

#define UIHexColor(color)            [UIColor colorHexString:color]

#define kBackGroundColor             UIHexColor(@"F4F5F7")//默认背景颜色
#define kDefaultRedColor             UIHexColor(@"ED5B29")//默认深红色
#define kLightWhiteColor             UIHexColor(@"F9F9F9")//浅白色

#define kBackAColor                  UIHexColor(@"EFAF4E")//浅红黄色
#define kBackBColor                  UIHexColor(@"EE6E33")//深红黄色

//渐变颜色
#define GradientColor(order,size)    [UIColor affectSize:size style:order startColor:kBackAColor endColor:kBackBColor]

//*************************//
//******** UIImage ********//
//*************************//

#define UCImage(name)                [UIImage imageNamed:name]
#define kDefaultArrowImage           [UIImage imageNamed:@"rtarrow"]

#endif /* UCCommon_h */
