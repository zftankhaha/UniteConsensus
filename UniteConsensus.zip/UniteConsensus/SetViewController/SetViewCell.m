//
//  SetViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/17.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "SetViewCell.h"

@implementation SetViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.accessoryType = UITableViewCellAccessoryNone;
        
        _showTitle = [[UILabel alloc] initWithFrame:CGRectMake(20,0,110,kSetCellHeight)];
        _showTitle.backgroundColor = [UIColor clearColor];
        _showTitle.font = CommonFontLight(17);
        _showTitle.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_showTitle];
        
        _arrowView = [self arrowImageView:kSetCellHeight];
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
    }
    
    return self;
}

@end
