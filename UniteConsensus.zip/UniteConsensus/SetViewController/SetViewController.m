//
//  SetViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "SetViewController.h"
#import "SetViewCell.h"
#import "ForgetController.h"

@interface SetViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;

@property (nonatomic,copy) NSArray *listItem;

@property (nonatomic,strong) UIButton *loginButton;

@end

@implementation SetViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"设置";
    
    self.listItem = @[@"重置密码",[NSString stringWithFormat:@"版本  v%@",APP_SHORT_VERSION]];
    [self.view addSubview:self.listView];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    NSString *current = CommonATManager.checkLogin?@"退出登录":@"登录/注册";
    [self.loginButton setTitle:current forState:UIControlStateNormal];
}

#pragma mark -
#pragma mark UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.listItem.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SetViewCell *myCell = [SetViewCell cellWithTableView:tableView];
    myCell.showTitle.text = self.listItem[indexPath.row];
    return myCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row == 0)
    {
        ForgetController *forgetControllr = [[ForgetController alloc] init];
        forgetControllr.fromType = FromSetType;
        [self.navigationController pushViewController:forgetControllr animated:YES];
    }
    else if (indexPath.row == 1)
    {
        [CommonVersion checkVersion:YES result:nil];
    }
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.rowHeight = kSetCellHeight;
        _listView.delegate = self;
        _listView.dataSource = self;
        
        //添加headerView
        UIView *currentView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        currentView.backgroundColor = [UIColor clearColor];
        _listView.tableHeaderView = currentView;
        [currentView bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        //添加footerView
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,100)];
        footerView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footerView;
        [_listView.tableFooterView addSubview:self.loginButton];
    }
    
    return _listView;
}

- (UIButton *)loginButton {
    
    if (!_loginButton)
    {
        _loginButton = [UIButton button:CGRectMake(20,35,SCREEN_WIDTH-40,45) title:@"登录/注册"
                             titleColor:[UIColor whiteColor] font:CommonFontRegular(18.0f) radius:3];
        _loginButton.backgroundColor = GradientColor(3,_loginButton.size);
        [_loginButton addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _loginButton;
}

- (void)loginAction:(UIButton *)button {
    
    if (CommonATManager.checkLogin)
    {
        [UCAlertManager show:@"温馨提示" message:@"确定要退出登录吗?" cancel:@"不，谢谢" sure:@"确定" click:^(AlertClickType clickType)
        {
            if (clickType == 1)
            {
                [CommonATManager logoutUserAccount:^{[self.navigationController popToRootViewControllerAnimated:YES];}];
            }
        }];
    }
    else
    {
        [CommonATManager loginUserAccount:nil];
    }
}

@end
