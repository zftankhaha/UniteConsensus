//
//  MinerViewCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MinerDetails.h"

#define kMinerCellHeight    70

@interface MinerViewCell : UITableViewCell

@property (nonatomic,strong) UILabel *startTime;

@property (nonatomic,strong) UILabel *endTime;

- (void)refreshMinerCell:(MinerDetails *)minerInfo;

@end
