//
//  BankController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"

@interface BankViewController : BaseViewController

@end
