//
//  BankManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BankManager.h"

@implementation BankManager

- (instancetype)init {
    
    self = [super init];
    
    if (self)
    {
        _finishWork = NO;
    }
    
    return self;
}

- (void)currentTaskResult:(void(^)(HTTPDetails *result))retHandler {
    
    static NSString *stringKey = @"api.APIUser/my_task";
    [CommonConnection stopRequest:self withKey:stringKey];
    
    if (CommonATManager.checkLogin)
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,stringKey];
        details.requestKey = stringKey;
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            if (result.success)
            {
                NSDictionary *dty = [result.resultData customForKey:@"data"];
                
                NSInteger inte = [[dty customForKey:@"finished_worker"] integerValue];
                self.finishWork = (inte==0)?NO:YES;
                
                NSArray *array = [dty customForKey:@"worker"];
                NSMutableArray *list1 = [NSMutableArray array];
                NSMutableArray *list2 = [NSMutableArray array];
                NSMutableArray *list3 = [NSMutableArray array];
                NSMutableArray *list4 = [NSMutableArray array];
                NSMutableArray *list5 = [NSMutableArray array];
                NSMutableArray *list6 = [NSMutableArray array];
                
                for (NSDictionary *dty in array)
                {
                    MinerDetails *miner = [[MinerDetails alloc] init];
                    [miner resolutionDataSource:dty];
                    
                    if (miner.minerType == MinerAType)
                    {
                        [list1 addObject:miner];
                    }
                    else if (miner.minerType == MinerBType)
                    {
                        [list2 addObject:miner];
                    }
                    else if (miner.minerType == MinerCType)
                    {
                        [list3 addObject:miner];
                    }
                    else if (miner.minerType == MinerDType)
                    {
                        [list4 addObject:miner];
                    }
                    else if (miner.minerType == MinerEType)
                    {
                        [list5 addObject:miner];
                    }
                    else if (miner.minerType == MinerFType)
                    {
                        [list6 addObject:miner];
                    }
                }
                
                self.listMiners = @[list1,list2,list3,list4,list5,list6];
            }
            
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}


- (void)recruitment:(MinerType)type coin:(NSString *)coin result:(void(^)(HTTPDetails *result))retHandler {
    
    if (CommonATManager.checkLogin)
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/recruitment"];
       
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        [dict setObject:[NSString stringWithFormat:@"%li",type] forKey:@"level"];
        [dict setObject:coin forKey:@"type"];
        details.requestHeader = dict;
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}

@end
