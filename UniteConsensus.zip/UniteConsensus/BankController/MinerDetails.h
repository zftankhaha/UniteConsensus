//
//  MinerInfomation.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger,MinerType) {
    
    MinerAType = 0,          //实习矿工//默认值
    MinerBType = 1,          //初级矿工
    MinerCType = 2,          //中级矿工
    MinerDType = 3,          //高级矿工
    MinerEType = 4,          //超级矿霸
    MinerFType = 5,          //至尊无上
};

@interface MinerDetails : NSObject

@property (nonatomic,assign) MinerType minerType;//矿工类型
@property (nonatomic,copy) NSString *showTitle;//矿工称呼
@property (nonatomic,copy) NSString *activity;//活跃度
@property (nonatomic,copy) NSString *rateMoney;//利息

@property (nonatomic,copy) NSString *dayProduce;//挖矿日产量
@property (nonatomic,copy) NSString *miningCycle;//挖矿周期
@property (nonatomic,copy) NSString *numberLimit;//数量上限
@property (nonatomic,copy) NSString *minerPrice;//招募价格

@property (nonatomic,copy) NSString *startTime;//招募开始时间
@property (nonatomic,copy) NSString *endTime;//退役时间

+ (NSArray *)rawListMiners;//原始数据
+ (NSArray *)currentListMiners;//解析后的数据
+ (MinerDetails *)minerInfomation:(MinerType)minerType;

- (void)resolutionDataSource:(id)dataSource;

- (NSString *)minerEndTime:(NSString *)startTime;

@end
