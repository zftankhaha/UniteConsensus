//
//  BankController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BankViewController.h"
#import "MinerViewController.h"
#import "TaskViewCell.h"
#import "BankManager.h"

@interface BankViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,strong) UIButton *taskButton;
@property (nonatomic,strong) UIView *footerView;

@property (nonatomic,strong) BankManager *bankManager;

@end

@implementation BankViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"我的任务";
    self.bankManager = [[BankManager alloc] init];
    [self.view addSubview:self.listView];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self refreshCurrentView];
    [self refreshDataSource:YES];
}

- (void)refreshDataSource:(BOOL)refreshDrop {
    
    if (CommonATManager.checkLogin)
    {
        [UCShowHUD showLoading:self.navigationController.view];
        
        [self.bankManager currentTaskResult:^(HTTPDetails *result)
        {
            [UCShowHUD dismissLoading:self.navigationController.view];
            
            [self.listView completeLoading:YES];
            
            if (result.success)
            {
                [self.taskButton setTitle:self.bankManager.finishWork?@"已完成":@"去挖矿" forState:UIControlStateNormal];
                [self.listView reloadData];
            }
        }];
    }
}

- (void)refreshCurrentView {
    
    if (CommonATManager.checkLogin)
    {
        self.footerView = nil;
        self.listView.tableFooterView = nil;
        [self.listView refresh:self header:YES footer:NO];
    }
    else
    {
        [self.taskButton setTitle:@"去挖矿" forState:UIControlStateNormal];
        self.listView.tableFooterView = self.footerView;
        [self.listView closeDragRefresh];
    }
    
    [self.listView reloadData];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-TabBar_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kTaskCellHeight;
        
        //加载headerView
        _listView.tableHeaderView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,90)];
        
        UILabel *atitle = [[UILabel alloc] initWithFrame:CGRectMake(20,8,200,40)];
        atitle.backgroundColor = [UIColor clearColor];
        atitle.font = CommonFontLight(16);
        atitle.text = @"今日任务:  浏览广告3分钟";
        [_listView.tableHeaderView addSubview:atitle];
        
        UILabel *btitle = [[UILabel alloc] initWithFrame:CGRectMake(20,atitle.bottom-16,atitle.width,atitle.height)];
        btitle.backgroundColor = [UIColor clearColor];
        btitle.font = CommonFontLight(14);
        btitle.text = @"阅读挖矿，挖掘价值......";
        btitle.textColor = [UIColor grayColor];
        [_listView.tableHeaderView addSubview:btitle];
        
        WEAKSELF
        self.taskButton = [UIButton button:CGRectMake(SCREEN_WIDTH-110-20,19,110,38) title:@"去挖矿"
                                titleColor:[UIColor whiteColor] font:CommonFontRegular(17) radius:3];
        self.taskButton.backgroundColor = GradientColor(0,self.taskButton.size);
        [_listView.tableHeaderView addSubview:self.taskButton];
        [self.taskButton actionForButton:^(UIButton *button)
        {
            if (CommonATManager.checkLogin)
            {
                if (!weakSelf.bankManager.finishWork)
                {
                    CommonDelegate.rootController.currentTabIndex = 0;
                }
            }
            else
            {
                [CommonATManager loginUserAccount:nil];
            }
        }];
    }
    
    return _listView;
}

- (UIView *)footerView {
    
    if (!_footerView)
    {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,_listView.height-_listView.tableHeaderView.height-10)];
        _footerView.backgroundColor = [UIColor whiteColor];
        [_footerView bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        UIButton *button = [UIButton button:CGRectMake(40,_footerView.height/2-50,SCREEN_WIDTH-80,45) title:@"查看我的矿工"
                                 titleColor:[UIColor whiteColor] font:CommonFontRegular(18.0f) radius:3];
        button.backgroundColor = GradientColor(3,button.size);
        [button actionForButton:^(UIButton *button){[CommonATManager loginUserAccount:nil];}];
        [_footerView addSubview:button];
    }
    
    return _footerView;
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (CommonATManager.checkLogin)
    {
        return MinerDetails.rawListMiners.count;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TaskViewCell *myCell = [TaskViewCell cellWithTableView:tableView];
    MinerDetails *minerInfo = [MinerDetails minerInfomation:indexPath.row];
    NSArray *list = self.bankManager.listMiners[indexPath.row];
    [myCell refreshMinerView:minerInfo count:list.count];
    return myCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (CommonATManager.checkLogin)
    {
        MinerViewController *minerController = [[MinerViewController alloc] init];
        minerController.minerType = indexPath.row;
        minerController.listMiners = self.bankManager.listMiners[indexPath.row];
        [self.navigationController pushViewController:minerController animated:YES];
        minerController.refreshBlock = ^(id refresh){[self refreshDataSource:YES];};
    }
}

@end
