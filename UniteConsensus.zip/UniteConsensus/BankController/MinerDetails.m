//
//  MinerInfomation.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "MinerDetails.h"

@implementation MinerDetails

+ (NSArray *)rawListMiners {
    
    static NSArray *listMiner = nil;
    
    if (!listMiner)
    {
        NSString *current = [[NSBundle mainBundle] pathForResource:@"ListMiner" ofType:@"plist"];
        listMiner = [NSArray arrayWithContentsOfFile:current];
    }
    
    return listMiner;
}

+ (MinerDetails *)minerInfomation:(MinerType)minerType {
    
    NSDictionary *dataSource = [MinerDetails.rawListMiners objectAtIndex:minerType];
    
    MinerDetails *minerInfo = [[MinerDetails alloc] init];
    
    minerInfo.minerType = [dataSource[@"minerType"] intValue];
    minerInfo.showTitle = dataSource[@"showTitle"];
    minerInfo.activity = dataSource[@"activity"];
    minerInfo.rateMoney = dataSource[@"rateMoney"];
    
    minerInfo.dayProduce = dataSource[@"dayProduce"];
    minerInfo.miningCycle = dataSource[@"miningCycle"];
    minerInfo.numberLimit = dataSource[@"numberLimit"];
    minerInfo.minerPrice = dataSource[@"minerPrice"];
    
    return minerInfo;
}

+ (NSArray *)currentListMiners {
    
    NSArray *listMiner = MinerDetails.rawListMiners;
    
    NSMutableArray *listInfo = [NSMutableArray array];
    
    for (NSDictionary *dty in listMiner)
    {
        MinerDetails *minerInfo = [[MinerDetails alloc] init];
        
        minerInfo.minerType = [dty[@"minerType"] intValue];
        minerInfo.showTitle = dty[@"showTitle"];
        minerInfo.activity = dty[@"activity"];
        minerInfo.rateMoney = dty[@"rateMoney"];
        
        minerInfo.dayProduce = dty[@"dayProduce"];
        minerInfo.miningCycle = dty[@"miningCycle"];
        minerInfo.numberLimit = dty[@"numberLimit"];
        minerInfo.minerPrice = dty[@"minerPrice"];
        
        [listInfo addObject:minerInfo];
    }
    
    return [listInfo copy];
}

- (void)resolutionDataSource:(id)dataSource {
    
    MinerType minerType = [[dataSource customForKey:@"level"] intValue];
    MinerDetails *minerInfo = [MinerDetails minerInfomation:minerType];
    
    self.minerType = minerInfo.minerType;
    self.showTitle = minerInfo.showTitle;
    self.activity = minerInfo.activity;
    self.rateMoney = minerInfo.rateMoney;
    
    self.dayProduce = minerInfo.dayProduce;
    self.miningCycle = minerInfo.miningCycle;
    self.numberLimit = minerInfo.numberLimit;
    self.minerPrice = minerInfo.minerPrice;
    
    
    //计算矿工招募时间、退役时间
    self.startTime = [dataSource customForKey:@"time"];
    
    self.endTime = [self minerEndTime:self.startTime];
}

- (NSString *)minerEndTime:(NSString *)startTime {

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    
    NSDate *tempDate = [dateFormatter dateFromString:startTime];
    NSTimeInterval oldTime = [tempDate timeIntervalSince1970];
    NSTimeInterval endTime = oldTime+30*24*60*60;
    
    NSDate *detailDate = [NSDate dateWithTimeIntervalSince1970:endTime];
    return [dateFormatter stringFromDate:detailDate];
}

@end
