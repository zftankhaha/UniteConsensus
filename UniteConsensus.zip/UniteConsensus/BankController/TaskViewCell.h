//
//  ListTaskViewCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MinerDetails.h"

#define kTaskCellHeight    70

@interface TaskViewCell : UITableViewCell

@property (nonatomic,strong) UILabel *showTitle;

@property (nonatomic,strong) UILabel *rateTitle;

@property (nonatomic,strong) UILabel *showCount;

- (void)refreshMinerView:(MinerDetails *)minerInfo count:(NSInteger)count;

@end
