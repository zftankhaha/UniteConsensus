//
//  MinerViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "MinerViewCell.h"

@implementation MinerViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.accessoryType = UITableViewCellAccessoryNone;
        
        UIImageView *sView = [[UIImageView alloc] initWithFrame:CGRectMake(20,0,60,kMinerCellHeight)];
        sView.backgroundColor = [UIColor clearColor];
        sView.contentMode = UIViewContentModeScaleAspectFit;
        sView.image = [UIImage imageNamed:@"acMiner"];
        [self.contentView addSubview:sView];
        
        
        UILabel *lbst = [[UILabel alloc] initWithFrame:CGRectMake(sView.right+10,6,90,kMinerCellHeight/2)];
        lbst.backgroundColor = [UIColor clearColor];
        lbst.font = CommonFontLight(16);
        lbst.textAlignment = NSTextAlignmentCenter;
        lbst.text = @"招募时间:";
        [self.contentView addSubview:lbst];
        
        _startTime = [[UILabel alloc] initWithFrame:CGRectMake(lbst.right,5,160,kMinerCellHeight/2)];
        _startTime.backgroundColor = [UIColor clearColor];
        _startTime.font = CommonFontLight(16);
        _startTime.textAlignment = NSTextAlignmentCenter;
        _startTime.textColor = kBackBColor;
        [self.contentView addSubview:_startTime];
        
        
        
        UILabel *lbst1 = [[UILabel alloc] initWithFrame:CGRectMake(lbst.left,kMinerCellHeight/2-4,90,kMinerCellHeight/2)];
        lbst1.backgroundColor = [UIColor clearColor];
        lbst1.font = CommonFontLight(16);
        lbst1.textAlignment = NSTextAlignmentCenter;
        lbst1.text = @"到期时间:";
        [self.contentView addSubview:lbst1];

        _endTime = [[UILabel alloc] initWithFrame:CGRectMake(_startTime.left,kMinerCellHeight/2-4,_startTime.width,_startTime.height)];
        _endTime.backgroundColor = [UIColor clearColor];
        _endTime.font = CommonFontLight(16);
        _endTime.textAlignment = NSTextAlignmentCenter;
        _endTime.textColor = kBackBColor;
        [self.contentView addSubview:_endTime];
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
    }
    
    return self;
}

- (void)refreshMinerCell:(MinerDetails *)minerInfo {
    
    self.startTime.text = minerInfo.startTime;
    self.endTime.text = minerInfo.endTime;
}

@end
