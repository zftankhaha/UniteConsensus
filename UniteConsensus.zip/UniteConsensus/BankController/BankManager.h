//
//  BankManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MinerDetails.h"

@interface BankManager : NSObject

@property (nonatomic,copy) NSArray <NSArray *> *listMiners;

@property (nonatomic,assign) BOOL finishWork;

//我的任务
- (void)currentTaskResult:(void(^)(HTTPDetails *result))retHandler;

//招募矿工
- (void)recruitment:(MinerType)type coin:(NSString *)coin result:(void(^)(HTTPDetails *result))retHandler;

@end
