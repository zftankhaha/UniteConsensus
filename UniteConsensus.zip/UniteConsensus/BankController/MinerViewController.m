//
//  MinerController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "MinerViewController.h"
#import "BankManager.h"
#import "MinerViewCell.h"

@interface MinerViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;

@property (nonatomic,strong) UIView *bottomView;

@property (nonatomic,strong) BankManager *bankManager;

@end

@implementation MinerViewController

- (void)dealloc {
    
    _listView.delegate = nil;
    _listView.dataSource = nil;
    _listView = nil;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = [MinerDetails minerInfomation:self.minerType].showTitle;
    
    self.bankManager = [[BankManager alloc] init];
    
    [self.view addSubview:self.listView];
    [self refreshFooterView];
    
    [self.view addSubview:self.bottomView];
}

- (void)refreshFooterView {
    
    self.listView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,0)];
    
    if (self.listMiners.count <= 0)
    {
        CGFloat height = self.listView.height-self.listView.tableHeaderView.height;
        self.listView.tableFooterView.height = height-10;
        self.listView.tableFooterView.backgroundColor = [UIColor whiteColor];
        UILabel *lbst = [[UILabel alloc] initWithFrame:CGRectMake(0,(height-10)/2-60,SCREEN_WIDTH,20)];
        lbst.backgroundColor = [UIColor clearColor];
        lbst.font = CommonFontLight(18);
        lbst.textColor = kDefaultRedColor;
        lbst.textAlignment = NSTextAlignmentCenter;
        lbst.text = @"点击下方按钮，招募矿工";
        [self.listView.tableFooterView addSubview:lbst];
        [self.listView.tableFooterView bottomLineX:0 width:SCREEN_WIDTH color:nil];
    }
    else
    {
        self.listView.tableFooterView.height = 10;
        self.listView.tableFooterView.backgroundColor = kBackGroundColor;
    }
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT-70);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kMinerCellHeight;
        
        //加载headerView
        _listView.tableHeaderView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,160)];
        
        CGFloat dwidth = (SCREEN_WIDTH-20-20)/3;
        
        UILabel *title1 = [[UILabel alloc] initWithFrame:CGRectMake(20,20,dwidth,20)];
        title1.backgroundColor = [UIColor clearColor];
        title1.font = CommonFontLight(19);
        title1.textAlignment = NSTextAlignmentCenter;
        title1.text = [MinerDetails minerInfomation:self.minerType].dayProduce;
        title1.textColor = kBackBColor;
        [_listView.tableHeaderView addSubview:title1];
        
        title1 = [[UILabel alloc] initWithFrame:CGRectMake(20,title1.bottom+5,dwidth,20)];
        title1.backgroundColor = [UIColor clearColor];
        title1.font = CommonFontLight(15);
        title1.text = @"每日产量";
        title1.textAlignment = NSTextAlignmentCenter;
        [_listView.tableHeaderView addSubview:title1];
        
        UILabel *title2 = [[UILabel alloc] initWithFrame:CGRectMake(title1.right,20,dwidth,20)];
        title2.backgroundColor = [UIColor clearColor];
        title2.font = CommonFontLight(19);
        title2.textAlignment = NSTextAlignmentCenter;
        title2.text = [MinerDetails minerInfomation:self.minerType].miningCycle;
        title2.textColor = kBackBColor;
        [_listView.tableHeaderView addSubview:title2];
        
        title2 = [[UILabel alloc] initWithFrame:CGRectMake(title1.right,title2.bottom+5,dwidth,20)];
        title2.backgroundColor = [UIColor clearColor];
        title2.font = CommonFontLight(15);
        title2.text = @"挖矿周期";
        title2.textAlignment = NSTextAlignmentCenter;
        [_listView.tableHeaderView addSubview:title2];
        
        UILabel *title3 = [[UILabel alloc] initWithFrame:CGRectMake(title2.right,20,dwidth,20)];
        title3.backgroundColor = [UIColor clearColor];
        title3.font = CommonFontLight(19);
        title3.textAlignment = NSTextAlignmentCenter;
        title3.text = [MinerDetails minerInfomation:self.minerType].activity;
        title3.textColor = kBackBColor;
        [_listView.tableHeaderView addSubview:title3];
        
        title3 = [[UILabel alloc] initWithFrame:CGRectMake(title2.right,title3.bottom+5,dwidth,20)];
        title3.backgroundColor = [UIColor clearColor];
        title3.font = CommonFontLight(15);
        title3.textAlignment = NSTextAlignmentCenter;
        title3.text = @"活跃度";
        [_listView.tableHeaderView addSubview:title3];
        
        
        CGFloat swidth = (SCREEN_WIDTH-20-20)/2;
        
        UILabel *title5 = [[UILabel alloc] initWithFrame:CGRectMake(20,83,swidth,20)];
        title5.backgroundColor = [UIColor clearColor];
        title5.font = CommonFontLight(19);
        title5.textAlignment = NSTextAlignmentCenter;
        title5.text = [MinerDetails minerInfomation:self.minerType].numberLimit;
        title5.textColor = kBackBColor;
        [_listView.tableHeaderView addSubview:title5];
        
        title5 = [[UILabel alloc] initWithFrame:CGRectMake(20,title5.bottom+5,swidth,20)];
        title5.backgroundColor = [UIColor clearColor];
        title5.font = CommonFontLight(15);
        title5.textAlignment = NSTextAlignmentCenter;
        title5.text = @"数量上限";
        [_listView.tableHeaderView addSubview:title5];
        
        UILabel *title6 = [[UILabel alloc] initWithFrame:CGRectMake(title5.right,83,swidth,20)];
        title6.backgroundColor = [UIColor clearColor];
        title6.font = CommonFontLight(19);
        title6.textAlignment = NSTextAlignmentCenter;
        title6.text = [MinerDetails minerInfomation:self.minerType].minerPrice;
        title6.textColor = kBackBColor;
        [_listView.tableHeaderView addSubview:title6];
        
        title6 = [[UILabel alloc] initWithFrame:CGRectMake(title5.right,title6.bottom+5,swidth,20)];
        title6.backgroundColor = [UIColor clearColor];
        title6.font = CommonFontLight(15);
        title6.textAlignment = NSTextAlignmentCenter;
        title6.text = @"招募价格";
        [_listView.tableHeaderView addSubview:title6];
    }
    
    return _listView;
}

#pragma mark -
#pragma mark UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listMiners.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MinerViewCell *myCell = [MinerViewCell cellWithTableView:tableView];
    [myCell refreshMinerCell:self.listMiners[indexPath.row]];
    return myCell;
}

#pragma mark -
#pragma mark 买卖按钮

- (UIView *)bottomView {

    if (!_bottomView)
    {
        CGFloat aheight = 70+Bottom_HEIGHT;
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0,SCREEN_HEIGHT-aheight,SCREEN_WIDTH,70+Bottom_HEIGHT)];
        _bottomView.backgroundColor = [UIColor whiteColor];
        [_bottomView topLineX:0 width:SCREEN_WIDTH color:nil];

        WEAKSELF
        UIButton *bdbutton = [UIButton button:CGRectMake(25,13,100,43) title:@"BD招募"
                                   titleColor:[UIColor whiteColor] font:CommonFontLight(16.0f) radius:3];
        bdbutton.backgroundColor = GradientColor(1,bdbutton.size);[_bottomView addSubview:bdbutton];
        [bdbutton actionForButton:^(UIButton *button)
        {
            [weakSelf recruitAction:0];
        }];
        
        UIButton *btbutton = [UIButton button:CGRectMake(SCREEN_WIDTH-25-185,13,185,43) title:@"BT招募"
                                   titleColor:[UIColor whiteColor] font:CommonFontLight(16.0f) radius:3];
        btbutton.backgroundColor = GradientColor(0,btbutton.size);[_bottomView addSubview:btbutton];
        [btbutton actionForButton:^(UIButton *button)
        {
            [weakSelf recruitAction:1];
        }];
    }

    return _bottomView;
}

- (void)recruitAction:(NSUInteger)recruitType {
    
    [self.bankManager recruitment:self.minerType coin:(recruitType==0)?@"bd":@"bt" result:^(HTTPDetails *result)
    {
        if (result.success)
        {
            CommonShowTitle(@"招募成功");
            
            MinerDetails *minerInfo = [MinerDetails minerInfomation:self.minerType];
            NSDate *today = [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
            minerInfo.startTime = [dateFormatter stringFromDate:today];
            minerInfo.endTime = [minerInfo minerEndTime:minerInfo.startTime];
            
            NSMutableArray *list = [NSMutableArray arrayWithArray:self.listMiners];
            [list addObject:minerInfo];
            self.listMiners = list;
            [self.listView reloadData];
            
            [self refreshFooterView];
        }
        else
        {
            CommonShowTitle(result.message);
        }
    }];
}

@end
