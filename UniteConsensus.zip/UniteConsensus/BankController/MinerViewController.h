//
//  MinerController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"
#import "MinerDetails.h"

@interface MinerViewController : BaseViewController

@property (nonatomic,assign) MinerType minerType;

@property (nonatomic,copy) NSArray *listMiners;

@end
