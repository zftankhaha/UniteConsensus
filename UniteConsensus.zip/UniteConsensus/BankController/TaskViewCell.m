//
//  ListTaskViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/9.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "TaskViewCell.h"

@implementation TaskViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        UIImageView *sView = [[UIImageView alloc] initWithFrame:CGRectMake(17,0,60,kTaskCellHeight)];
        sView.backgroundColor = [UIColor clearColor];
        sView.contentMode = UIViewContentModeCenter;
        sView.image = [UIImage imageNamed:@"acMiner"];
        [self.contentView addSubview:sView];
        
        _showTitle = [[UILabel alloc] initWithFrame:CGRectMake(sView.right+16,0,200,kTaskCellHeight)];
        _showTitle.backgroundColor = [UIColor clearColor];
        _showTitle.font = CommonFontRegular(16.5);
        _showTitle.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_showTitle];
        
//        _rateTitle = [[UILabel alloc] initWithFrame:CGRectMake(sView.right+15,30,200,kTaskCellHeight-30)];
//        _rateTitle.backgroundColor = [UIColor clearColor];
//        _rateTitle.font = CommonFontLight(14);
//        _rateTitle.textColor = kDefaultRedColor;
//        _rateTitle.textAlignment = NSTextAlignmentLeft;
//        [self.contentView addSubview:_rateTitle];
        
        
        _showCount = [[UILabel alloc] initWithFrame:CGRectMake(208,0,110,kTaskCellHeight)];
        _showCount.backgroundColor = [UIColor clearColor];
        _showCount.font = CommonFontLight(16);
        _showCount.textColor = kDefaultRedColor;
        _showCount.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_showCount];
        
        [self arrowImageView:kTaskCellHeight];
    }
    
    return self;
}

- (void)refreshMinerView:(MinerDetails *)minerInfo count:(NSInteger)count {
    
    self.showTitle.text = minerInfo.showTitle;
    
    //self.rateTitle.text = minerInfo.rateMoney;
    
    self.showCount.text = [NSString stringWithFormat:@"已招募:  %li 个",count];
}

@end
