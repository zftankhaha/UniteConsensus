//
//  CTNavigationController.m
//  MarketWork
//
//  Created by zhangfeng on 14-3-13.
//  Copyright (c) 2014年 MarketWork. All rights reserved.
//

#import "CTStackController.h"
#import <QuartzCore/QuartzCore.h>

#define kSlideRatio   3

@interface CTShotStackView : UIView

@property (nonatomic,strong) UIImageView *showView;
@property (nonatomic,strong) UIImageView *shadowView;

@end

@implementation CTShotStackView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        
        CGRect rect = CGRectMake(-(SCREEN_WIDTH/kSlideRatio),0,SCREEN_WIDTH,self.height);
        _showView = [[UIImageView alloc] initWithFrame:rect];
        _showView.backgroundColor = [UIColor clearColor];
        _showView.userInteractionEnabled = YES;
        [self addSubview:_showView];
        
        UIView *alphaView = [[UIView alloc] initWithFrame:_showView.bounds];
        alphaView.backgroundColor = [UIColor blackColor];
        alphaView.alpha = 0.15f;[_showView addSubview:alphaView];
        
        _shadowView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,3,self.height)];
        _shadowView.backgroundColor = [UIColor clearColor];
        _shadowView.image = [UIImage imageNamed:@"slideline"];
        _shadowView.userInteractionEnabled = YES;
        [self addSubview:_shadowView];
    }
    
    return self;
}

- (void)refreshShotLeft:(CGFloat)left {
    
    CGRect sframe = self.showView.frame;
    sframe.origin.x = (left/kSlideRatio)-(SCREEN_WIDTH/kSlideRatio);
    self.showView.frame = sframe;
    
    CGRect dframe = self.shadowView.frame;
    dframe.origin.x = left-dframe.size.width;
    self.shadowView.frame = dframe;
}

@end

@interface UCShadowInfomation : NSObject

@property (nonatomic,strong) UIImage *captureImage;
@property (nonatomic,assign) BOOL slideGesture;

@end

@implementation UCShadowInfomation

@end

@interface CTStackController () <UIGestureRecognizerDelegate>

@property (nonatomic,strong) UIPanGestureRecognizer *backGesture;
@property (nonatomic,strong) NSMutableArray *listStackShots;

@property (nonatomic,assign) BOOL isMoving;
@property (nonatomic,assign) CGPoint startTouch;
@property (nonatomic,strong) CTShotStackView *stackView;

@end

@implementation CTStackController

#pragma mark -
#pragma mark initRootController

- (instancetype)initRootController:(UIViewController *)rootController {
    
    self = [super initWithRootViewController:rootController];
    
    if (self)
    {
        [self initWithRootController];
    }
    
    return self;
}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController {

    self = [super initWithRootViewController:rootViewController];
    
    if (self)
    {
        [self initWithRootController];
    }
    
    return self;
}

- (void)initWithRootController {

    self.view.backgroundColor = [UIColor whiteColor];
    self.interactivePopGestureRecognizer.enabled = NO;
    self.barHideOnSwipeGestureRecognizer.enabled = NO;
    self.barHideOnTapGestureRecognizer.enabled = NO;
    self.navigationBarHidden = YES;
    self.navigationBar.prefersLargeTitles = NO;
}

- (void)setSlideGesture:(BOOL)slideGesture {
    
    if (self.viewControllers.count <= 1)
    {
        slideGesture = NO;
    }
    
    _slideGesture = slideGesture;
    self.backGesture.enabled = slideGesture;
    
    if (self.listStackShots && 0 < self.listStackShots.count)
    {
        UCShadowInfomation *shadowInfo = self.listStackShots.lastObject;
        shadowInfo.slideGesture = _slideGesture;
    }
}

- (UIPanGestureRecognizer *)backGesture {
    
    if (!_backGesture)
    {
        _backGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(slideAction:)];
        _backGesture.delegate = self;[self.view addGestureRecognizer:_backGesture];
    }
    
    return _backGesture;
}

#pragma mark -
#pragma mark POP/PushViewController

- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated {
    
    NSArray *listControllers = [super popToRootViewControllerAnimated:animated];
    [self completionStackAction];
    return listControllers;
}

- (NSArray *)popToViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    NSInteger current = [self.viewControllers indexOfObject:viewController];
    
    if (current < self.listStackShots.count)
    {
        [self.listStackShots removeObjectsInRange:NSMakeRange(current,self.listStackShots.count-current)];
    }
    
    NSArray *listControllers = [super popToViewController:viewController animated:animated];
    [self completionStackAction];
    return listControllers;
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated {
    
    [self.listStackShots removeLastObject];
    UIViewController *stackController = [super popViewControllerAnimated:animated];
    [self completionStackAction];
    return stackController;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if (0 < self.viewControllers.count)
    {
        UCShadowInfomation *shadowInfo = [[UCShadowInfomation alloc] init];
        shadowInfo.captureImage = [self captureImage];
        shadowInfo.slideGesture = self.slideGesture;
        [self.listStackShots addObject:shadowInfo];
        
        if (self.tabBarController)
        {
            viewController.hidesBottomBarWhenPushed = YES;
        }
    }
    
    [super pushViewController:viewController animated:animated];
    [self completionStackAction];
}

- (void)completionStackAction {
    
    if (self.viewControllers.count <= 1)
    {
        self.listStackShots = [NSMutableArray array];
        self.slideGesture = NO;
    }
    else
    {
        if (self.listStackShots && 0 < self.listStackShots.count)
        {
            UCShadowInfomation *shadowInfo = self.listStackShots.lastObject;
            self.slideGesture = shadowInfo.slideGesture;
        }
    }
    
    [self.stackView removeFromSuperview];
    self.stackView = nil;
}

- (UIImage *)captureImage {
    
    UIView *stoneView = self.tabBarController?self.tabBarController.view:self.view;
    UIGraphicsBeginImageContextWithOptions(stoneView.bounds.size,stoneView.opaque,0);
    [stoneView drawViewHierarchyInRect:stoneView.bounds afterScreenUpdates:NO];
    UIImage *captureImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return captureImage;
}

#pragma mark -
#pragma mark UIPanGestureRecognizer

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    
    if (self.viewControllers.count <= 1)
    {
        return NO;
    }
    
    UIView *currentView = otherGestureRecognizer.view;
    
    if (currentView && [currentView isKindOfClass:[UITableView class]])
    {
        return NO;
    }
    
    if (currentView && [currentView isKindOfClass:[UIScrollView class]])
    {
        UIScrollView *scrollView = (UIScrollView *)currentView;
        
        if (scrollView.contentOffset.x <= 0 && scrollView.width < scrollView.contentSize.width)
        {
            scrollView.bounces = NO;
            return YES;
        }
        else
        {
            scrollView.bounces = YES;
        }
    }
    
    return NO;
}

- (void)slideAction:(UIPanGestureRecognizer *)recognizer {
    
    if (self.viewControllers.count <= 1)
    {
        return;
    }
    
    CGPoint touchPoint = [recognizer locationInView:CommonDelegate.window];
    
    if (recognizer.state == UIGestureRecognizerStateBegan)
    {
        self.isMoving = YES;
        self.startTouch = touchPoint;
        
        if (self.stackView)
        {
            if (self.stackView.hidden)
            {
                self.stackView.hidden = NO;
            }
        }
        else
        {
            self.stackView = [[CTShotStackView alloc] initWithFrame:self.view.bounds];
            self.stackView.showView.image = [[self.listStackShots lastObject] captureImage];
            [self.view.superview addSubview:self.stackView];
            [self.view.superview insertSubview:self.stackView belowSubview:self.view];
        }
    }
    else if (recognizer.state == UIGestureRecognizerStateEnded)
    {
        if (160 < (touchPoint.x-self.startTouch.x))
        {
            [UIView animateWithDuration:0.3 animations:^{
                
                [self moveViewWithX:self.view.bounds.size.width];
            }
            completion:^(BOOL finished)
            {
                [self popViewControllerAnimated:NO];
                CGRect frame = self.view.frame;
                frame.origin.x = 0;
                self.view.frame = frame;
                self.isMoving = NO;
            }];
        }
        else
        {
            [UIView animateWithDuration:0.3 animations:^{
                
                [self moveViewWithX:0];
            }
            completion:^(BOOL finished)
            {
                self.isMoving = NO;
                self.stackView.hidden = YES;
            }];
        }
        
        return;
    }
    else if (recognizer.state == UIGestureRecognizerStateCancelled)
    {
        [UIView animateWithDuration:0.3 animations:^{
            
            [self moveViewWithX:0];
        }
        completion:^(BOOL finished)
        {
            self.isMoving = NO;
            self.stackView.hidden = YES;
        }];
        
        return;
    }
    
    if (self.isMoving)
    {
        [self moveViewWithX:touchPoint.x-self.startTouch.x];
    }
}

- (void)moveViewWithX:(CGFloat)left {
    
    left = (SCREEN_WIDTH<left)?SCREEN_WIDTH:left;
    left = (left<0)?0:left;
    
    CGRect frame = self.view.frame;
    frame.origin.x = left;
    self.view.frame = frame;
    
    [self.stackView refreshShotLeft:left];
}

@end
