//
//  UIWebController.h
//  BCExchange
//
//  Created by zftank on 2018/7/19.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "BaseViewController.h"
#import <WebKit/WebKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@interface BKWebView : WKWebView

@end

@interface UIWebController : BaseViewController

@property (nonatomic,copy) NSString *webUrl;

@property (nonatomic,copy) NSString *webTitle;

@property (nonatomic,readonly,strong) BKWebView *bkWebView;

- (void)setCommonWebView:(NSString *)currentUrl;

- (void)closeRequestAction;

@end
