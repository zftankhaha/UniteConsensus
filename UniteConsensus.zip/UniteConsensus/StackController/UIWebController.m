//
//  UIWebController.m
//  BCExchange
//
//  Created by zftank on 2018/7/19.
//  Copyright © 2018年 BCExchange. All rights reserved.
//

#import "UIWebController.h"

@implementation BKWebView

@end

@interface UIWebController () <WKUIDelegate,WKNavigationDelegate>

@property (nonatomic,strong) BKWebView *bkWebView;

@property (nonatomic,strong) NSMutableURLRequest *webRequest;

@property (nonatomic,strong) JSContext *JsContext;

@end

@implementation UIWebController

- (void)dealloc {
    
    if (self.refreshBlock)
    {
        self.refreshBlock(nil);
    }
    
    [self closeRequestAction];
    
    NSHTTPCookie *cookie = nil;
    
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    
    for (cookie in [storage cookies])
    {
        [storage deleteCookie:cookie];
    }
    
    //清除UIWebView的缓存
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    NSURLCache *cache = [NSURLCache sharedURLCache];
    [cache removeAllCachedResponses];
    [cache setDiskCapacity:0];
    [cache setMemoryCapacity:0];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    self.showTitle = self.webTitle;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = self.webTitle;
}

- (void)setCommonWebView:(NSString *)currentUrl {
    
    self.webUrl = currentUrl;
    
    if ([BKCheckValid checkStringValid:self.webUrl])
    {
        NSURL *url = [[NSURL alloc] initWithString:self.webUrl];
        
        self.webRequest = [NSMutableURLRequest requestWithURL:url
                                                  cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                              timeoutInterval:120.0f];
        
        CGRect frame = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        self.bkWebView = [[BKWebView alloc] initWithFrame:frame];
        self.bkWebView.UIDelegate = self;
        self.bkWebView.navigationDelegate = self;
        self.bkWebView.backgroundColor = [UIColor clearColor];
        self.bkWebView.opaque = NO;
        [self.bkWebView loadRequest:self.webRequest];
        [self.view addSubview:self.bkWebView];
    }
    else
    {
        [self closeRequestAction];
    }
}

- (void)returnAction:(UIButton *)button {
    
    if ([self.bkWebView canGoBack])
    {
        [self.bkWebView goBack];
    }
    else
    {
        [self closeRequestAction];
        
        [super returnAction:button];
    }
}

- (void)closeRequestAction {
    
    self.JsContext = nil;
    self.webRequest = nil;
    [UCShowHUD dismissLoading:self.view];
    [self.bkWebView stopLoading];
    self.bkWebView.UIDelegate = nil;
    self.bkWebView.navigationDelegate = nil;
    self.bkWebView = nil;
    self.webUrl = nil;
}

#pragma mark -
#pragma mark WKWebView

- (BOOL)webView:(WKWebView *)webView shouldPreviewElement:(WKPreviewElementInfo *)elementInfo {
    
    
    
    return YES;
}

- (void)webViewDidClose:(WKWebView *)webView {
    
    
}

//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
// navigationType:(UIWebViewNavigationType)navigationType {
//
//    NSString *absolute = request.URL.absoluteString;
//
//    if ([self.listIgnore containsObject:absolute])
//    {
//        return NO;
//    }
//
//    return YES;
//}
//
//- (void)webViewDidFinishLoad:(UIWebView *)webView {
//
//    [HBShowHUD dismissLoading:self.view];
//
//    if (!self.webTitle)
//    {
//        NSString *title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
//        self.headerBar.titleView.text = title;
//    }
//}
//
//- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//
//    [HBShowHUD dismissLoading:self.view];
//}
//
//- (void)clickBlankAction {
//
//    [self.bkWebView loadRequest:self.webRequest];
//}

@end
