//
//  CTNavigationController.h
//  MarketWork
//
//  Created by zhangfeng on 14-3-13.
//  Copyright (c) 2014年 MarketWork. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CTStackController : UINavigationController

@property (nonatomic,assign) BOOL slideGesture;

- (instancetype)initRootController:(UIViewController *)rootController;

@end
