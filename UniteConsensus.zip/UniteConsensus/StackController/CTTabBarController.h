//
//  CTTabBarController.h
//  Follow
//
//  Created by zftank on 2020/7/2.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "CTStackController.h"
#import "UIWebController.h"

#import "HomeViewController.h"
#import "BankViewController.h"
#import "TradeViewController.h"
#import "AccountController.h"

@interface CTTabBarController : UITabBarController

@property (nonatomic,strong) HomeViewController *homeController;     //首页
@property (nonatomic,strong) BankViewController *bankController;     //任务
@property (nonatomic,strong) TradeViewController *tradeController;   //交易
@property (nonatomic,strong) AccountController *selfController;      //我的

@property (nonatomic,assign) NSUInteger currentTabIndex;
@property (nonatomic,strong) CTStackController *stackController;     //当前的UINavigationController
@property (nonatomic,strong) BaseViewController *showController;     //当前的UIViewController

@end
