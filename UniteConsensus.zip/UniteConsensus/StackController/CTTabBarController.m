//
//  CTTabBarController.m
//  Follow
//
//  Created by zftank on 2020/7/2.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "CTTabBarController.h"

@interface CTTabButton : UIButton

@property (nonatomic,strong) UIImageView *showIcon;
@property (nonatomic,strong) UIImage *commonImage;
@property (nonatomic,strong) UIImage *selectionImage;
@property (nonatomic,strong) UILabel *showTitle;

@end

@implementation CTTabButton

+ (CTTabButton *)customButton:(CGRect)frame {
    
    CTTabButton *button = [CTTabButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;button.backgroundColor = [UIColor clearColor];
    button.exclusiveTouch = YES;
    button.adjustsImageWhenHighlighted = NO;
    
    button.showIcon = [[UIImageView alloc] initWithFrame:CGRectMake(15,7,button.width-30,button.height-27)];
    button.showIcon.backgroundColor = [UIColor clearColor];
    button.showIcon.contentMode = UIViewContentModeScaleAspectFit;
    [button addSubview:button.showIcon];
    
    button.showTitle = [[UILabel alloc] initWithFrame:CGRectMake(0,button.height-21,button.width,20)];
    button.showTitle.backgroundColor = [UIColor clearColor];
    button.showTitle.font = CommonFontRegular(12.5f);
    button.showTitle.textAlignment = NSTextAlignmentCenter;
    [button addSubview:button.showTitle];
    
    return button;
}

- (void)setSelected:(BOOL)selected {
    
    [super setSelected:selected];
    
    self.showIcon.image = selected?self.selectionImage:self.commonImage;
    self.showTitle.textColor = selected?UIHexColor(@"8558DD"):UIHexColor(@"999999");
}

@end

@interface CTTabBarController ()

@property (nonatomic,strong) UIView *rootView;
@property (nonatomic,strong) CTTabButton *currentButton;
@property (nonatomic,copy) NSArray *listButton;

@end

@implementation CTTabBarController

- (void)dealloc {
    
    _homeController = nil;
    _bankController = nil;
    _tradeController = nil;
    _selfController = nil;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self completionTabBarPlatform];
}

- (void)completionTabBarPlatform {
    
    self.homeController = [[HomeViewController alloc] init];
    CTStackController *home = [[CTStackController alloc] initRootController:self.homeController];
    
    self.bankController = [[BankViewController alloc] init];
    CTStackController *bank = [[CTStackController alloc] initRootController:self.bankController];
    
    self.tradeController = [[TradeViewController alloc] init];
    CTStackController *trade = [[CTStackController alloc] initRootController:self.tradeController];
    
    self.selfController = [[AccountController alloc] init];
    CTStackController *account = [[CTStackController alloc] initRootController:self.selfController];
    
    self.viewControllers = [NSMutableArray arrayWithObjects:home,bank,trade,account,nil];
    
    //自定义UITabBar
    UIImage *clearImage = [[UIImage alloc] init];
    self.tabBar.backgroundImage = clearImage;
    self.tabBar.shadowImage = clearImage;
    self.tabBar.barTintColor = [UIColor clearColor];
    self.tabBar.clipsToBounds = YES;
    
    [self.rootView removeFromSuperview];
    self.rootView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,TabBar_HEIGHT)];
    self.rootView.backgroundColor = [UIColor whiteColor];
    [self.rootView topLineX:0 width:SCREEN_WIDTH color:nil];
    [self.tabBar addSubview:self.rootView];
    
    NSArray *listCommon = @[UCImage(@"atab11"),UCImage(@"atab21"),UCImage(@"atab31"),UCImage(@"atab51")];
    NSArray *listSelection = @[UCImage(@"atab12"),UCImage(@"atab22"),UCImage(@"atab32"),UCImage(@"atab55")];
    NSArray *listTitle = @[@"首页",@"任务",@"交易",@"我的"];
    
    NSInteger listCount = listTitle.count;
    CGFloat ctWidth = (CGFloat)(SCREEN_WIDTH/listCount);
    NSMutableArray *listButton = [NSMutableArray array];
    
    for (int i=0;i<listCount;i++)
    {
        CTTabButton *button = [CTTabButton customButton:CGRectMake(i*ctWidth,0,ctWidth,49)];
        button.commonImage = listCommon[i];button.selectionImage = listSelection[i];
        button.showTitle.text = listTitle[i];button.selected = NO;
        [button addTarget:self action:@selector(clickTabBarAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.rootView addSubview:button];[listButton addObject:button];
    }
    
    self.listButton = listButton;
    self.currentButton = [self.listButton objectAtIndex:0];
    self.currentButton.selected = YES;
}

#pragma mark -
#pragma mark SelectedIndex

- (BOOL)checkSelectIndexInValid:(NSUInteger)selectedIndex {
    
    if (self.listButton && 0 <= self.listButton.count)
    {
        if (0 <= selectedIndex && selectedIndex < self.listButton.count)
        {
            return NO;
        }
    }
    
    return YES;
}

- (void)clickTabBarAction:(UIButton *)button {
    
    NSUInteger selectedIndex = [self.listButton indexOfObject:button];
    
    if ([self checkSelectIndexInValid:selectedIndex])
    {
        return;
    }
    
    if (self.selectedIndex == selectedIndex)
    {
        if ([self.showController respondsToSelector:@selector(clickTabForRepeat)])
        {
            [self.showController clickTabForRepeat];
        }
    }
    else
    {
        self.selectedIndex = selectedIndex;
    }
}

- (void)setSelectedIndex:(NSUInteger)selectedIndex {
    
    [super setSelectedIndex:selectedIndex];
    
    if (![self checkSelectIndexInValid:selectedIndex])
    {
        self.currentButton.selected = NO;
        self.currentButton = [self.listButton objectAtIndex:selectedIndex];
        self.currentButton.selected = YES;
    }
}

- (void)setCurrentTabIndex:(NSUInteger)selectedIndex {
    
    if ([self checkSelectIndexInValid:selectedIndex])
    {
        return;
    }
    
    if (self.stackController && 1 < self.stackController.viewControllers.count)
    {
        if (self.selectedIndex == selectedIndex)
        {
            [self.stackController popToRootViewControllerAnimated:YES];
        }
        else
        {
            [self.stackController popToRootViewControllerAnimated:NO];
            self.selectedIndex = selectedIndex;
        }
    }
    else
    {
        self.selectedIndex = selectedIndex;
    }
}

- (NSUInteger)currentTabIndex {
    
    return self.selectedIndex;
}

#pragma mark -
#pragma mark SelectViewController

- (CTStackController *)stackController {
    
    return (CTStackController *)self.selectedViewController;
}

- (BaseViewController *)showController {
    
    CTStackController *stack = (CTStackController *)self.selectedViewController;
    NSArray *listControllers = stack.viewControllers;
    return (BaseViewController *)listControllers.lastObject;
}

@end
