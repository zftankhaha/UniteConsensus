//
//  BaseViewController.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/24.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@property (nonatomic,copy) void(^refreshBlock)(id refresh);//用于controller之间的block回调
@property (nonatomic,assign) BOOL slideGesture;//滑动返回//默认开启

@property (nonatomic,assign) BOOL showHeaderBar;//代替UINavigationBar//默认已添加在顶部
@property (nonatomic,copy) NSString *showTitle;//顶部标题

- (void)returnAction:(UIButton *)button;//点击返回按钮，子类复写

- (void)refreshRightBarButton:(NSString *)rightTitle action:(SEL)action;

#pragma mark -
#pragma mark 重复点击

- (void)clickTabForRepeat;

@end
