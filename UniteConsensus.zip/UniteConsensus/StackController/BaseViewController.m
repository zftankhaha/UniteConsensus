//
//  BaseViewController.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/24.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "BaseViewController.h"
#import "CTStackController.h"

@interface UIHeaderBar : UIView

@property (nonatomic,strong) UILabel *titleView;
@property (nonatomic,strong) UIButton *returnButton;
@property (nonatomic,strong) UIButton *rightButton;

@end

@implementation UIHeaderBar

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor whiteColor];
        
        CGFloat height = HeadBar_HEIGHT-StatusBar_HEIGHT-6;
        _titleView = [[UILabel alloc] initWithFrame:CGRectMake(0,StatusBar_HEIGHT,SCREEN_WIDTH,height)];
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.font = CommonFontLight(18.5);
        _titleView.textColor = [UIColor blackColor];
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.userInteractionEnabled = NO;
        [self addSubview:_titleView];
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
    }
    
    return self;
}

@end

@interface BaseViewController ()

@property (nonatomic,strong) UIHeaderBar *headerBar;

@end

@implementation BaseViewController

- (void)dealloc {

    [CommonNotification removeObserver:self];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [UIScrollView appearance].contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    
    self.showHeaderBar = YES;
    self.view.backgroundColor = kBackGroundColor;
    self.slideGesture = YES;
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    if (self.showHeaderBar && self.headerBar && self.headerBar.superview)
    {
        self.headerBar.frame = self.headerBar.bounds;
        [self.view bringSubviewToFront:self.headerBar];
    }
}

#pragma mark -
#pragma mark UIHeaderBar

- (void)setShowHeaderBar:(BOOL)show {
    
    _showHeaderBar = show;
    
    if (_showHeaderBar)
    {
        CGRect frame = CGRectMake(0,0,SCREEN_WIDTH,HeadBar_HEIGHT);
        self.headerBar = [[UIHeaderBar alloc] initWithFrame:frame];
        [self.view addSubview:self.headerBar];
        [self.view bringSubviewToFront:self.headerBar];
        [self completionBackAction];
    }
    else
    {
        [self.headerBar.returnButton removeFromSuperview];
        self.headerBar.returnButton = nil;
        [self.headerBar.rightButton removeFromSuperview];
        self.headerBar.rightButton = nil;
        [self.headerBar removeFromSuperview];
        self.headerBar = nil;
    }
}

- (void)setShowTitle:(NSString *)showTitle {
    
    self.headerBar.titleView.text = showTitle;
}

- (NSString *)showTitle {
    
    return self.headerBar.titleView.text;
}

- (void)completionBackAction {
    
    if (self.navigationController)
    {
        Class stack = [CTStackController class];
        NSUInteger number = self.navigationController.viewControllers.count;
        
        BOOL checkStack = (1 < number && [self.navigationController isKindOfClass:stack]);
        BOOL checkPresent = (1 == number && self.presentingViewController);
        
        if (checkStack || checkPresent)
        {
            [self.headerBar.returnButton removeFromSuperview];
            self.headerBar.returnButton = [UIButton buttonWithType:UIButtonTypeCustom];
            self.headerBar.returnButton.frame = CGRectMake(0,StatusBar_HEIGHT,80,HeadBar_HEIGHT-StatusBar_HEIGHT);
            self.headerBar.returnButton.exclusiveTouch = YES;
            self.headerBar.returnButton.adjustsImageWhenHighlighted = NO;
            self.headerBar.returnButton.backgroundColor = [UIColor clearColor];
            [self.headerBar.returnButton addTarget:self action:@selector(returnAction:)
                                  forControlEvents:UIControlEventTouchUpInside];
            [self.headerBar addSubview:self.headerBar.returnButton];
            
            UIImageView *showIcon = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,60,40)];
            showIcon.backgroundColor = [UIColor clearColor];showIcon.contentMode = UIViewContentModeCenter;
            showIcon.image = [UIImage imageNamed:@"bkPhoto"];[self.headerBar.returnButton addSubview:showIcon];
        }
    }
}

- (void)returnAction:(UIButton *)button {
    
    Class stack = [CTStackController class];
    NSUInteger number = self.navigationController.viewControllers.count;
    
    BOOL checkStack = (1 < number && [self.navigationController isKindOfClass:stack]);
    BOOL checkPresent = (1 == number && self.presentingViewController);
    
    if (checkStack)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (checkPresent)
    {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)refreshRightBarButton:(NSString *)rightTitle action:(SEL)action {
    
    if (rightTitle)
    {
        [self.headerBar.rightButton removeFromSuperview];
        self.headerBar.rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.headerBar.rightButton.frame = CGRectMake(SCREEN_WIDTH-123,StatusBar_HEIGHT,100,HeadBar_HEIGHT-StatusBar_HEIGHT);
        self.headerBar.rightButton.backgroundColor = [UIColor clearColor];
        self.headerBar.rightButton.adjustsImageWhenHighlighted = NO;
        self.headerBar.rightButton.exclusiveTouch = YES;
        [self.headerBar.rightButton addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
        [self.headerBar addSubview:self.headerBar.rightButton];
        
        UILabel *title = [[UILabel alloc] initWithFrame:self.headerBar.rightButton.bounds];
        title.height = self.headerBar.rightButton.height-8;title.backgroundColor = [UIColor clearColor];
        title.font = CommonFontLight(18);title.textColor = kDefaultRedColor;
        title.textAlignment = NSTextAlignmentRight;title.text = rightTitle;
        [self.headerBar.rightButton addSubview:title];
    }
    else
    {
        [self.headerBar.rightButton removeFromSuperview];
        self.headerBar.rightButton = nil;
    }
}

- (void)setSlideGesture:(BOOL)slideGesture {
    
    [(CTStackController *)self.navigationController setSlideGesture:slideGesture];
}

- (BOOL)slideGesture {
    
    return [(CTStackController *)self.navigationController slideGesture];
}

#pragma mark -
#pragma mark clickTabForRepeat

- (void)clickTabForRepeat {

}

#pragma mark -
#pragma mark UIStatusBar

- (UIStatusBarStyle)preferredStatusBarStyle {
    
    return UIStatusBarStyleDefault;
}

@end
