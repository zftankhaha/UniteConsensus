//
//  UITradeViewCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderDetails.h"

#define kTradeCellHeight    90

@protocol TradeViewCellDelegate <NSObject>

- (void)selectActionIndexPath:(OrderDetails *)orderInfo;

@end

@interface TradeViewCell : UITableViewCell

@property (nonatomic,weak) id delegate;

@property (nonatomic,strong) OrderDetails *orderInfo;

@property (nonatomic,strong) UILabel *count;
@property (nonatomic,strong) UILabel *price;

@property (nonatomic,strong) UIButton *tradeButton;

- (void)refreshTradeCellSource:(OrderDetails *)orderInfo;

@end
