//
//  TradeViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/6.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"
#import "OrderDetails.h"

@interface TradeViewController : BaseViewController

@end
