//
//  OrderDetails.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/14.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger,OrderState) {
    
    OrderTradable = 0,        //出售中//订单可交易状态//默认值
    OrderLocking = 1,         //交易锁定中//订单处于锁定状态//等待付款
    OrderComplete = 2,        //订单已完成
};

@interface OrderDetails : NSObject

@property (nonatomic,assign) OrderState orderState;//订单状态


@property (nonatomic,copy) NSString *orderID;//订单ID

@property (nonatomic,copy) NSString *UID;//卖家uid

@property (nonatomic,copy) NSString *PID;//买家uid


@property (nonatomic,copy) NSString *coinCount;//出售数量

@property (nonatomic,copy) NSString *coinPrice;//出售单价

- (void)resolutionDataSource:(id)dataSource;

@end
