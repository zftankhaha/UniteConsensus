//
//  OrderDetails.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/14.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "OrderDetails.h"

@implementation OrderDetails

- (void)resolutionDataSource:(id)dataSource {
    
    self.orderState = [[dataSource customForKey:@"state"] intValue];
    
    
    self.orderID = [[dataSource customForKey:@"id"] stringValue];
    
    self.UID = [dataSource customForKey:@"uid"];
    
    self.PID = [dataSource customForKey:@"pid"];
    
    
    self.coinCount = [dataSource customForKey:@"count"];
    
    self.coinPrice = [dataSource customForKey:@"gt"];
}

@end
