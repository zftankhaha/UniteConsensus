//
//  PublishOrderController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "PublishOrderController.h"
#import "UIListViewCell.h"
#import "UICommonView.h"
#import "TradeManager.h"

@interface PublishOrderController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UICommonView *enterPrice;
@property (nonatomic,strong) UICommonView *enterNumber;

@property (nonatomic,strong) TradeManager *tradeManager;

@end

@implementation PublishOrderController

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.showTitle = @"出售BT";
    
    self.enterPrice = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.enterPrice refreshTitle:@"出售单价" enterView:@"请输入大于0的单价"];
    self.enterPrice.enterView.text = self.todayReference.stringValue;
    
    self.enterNumber = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.enterNumber refreshTitle:@"出售数量" enterView:@"请输入大于0，小于300的数量"];
    
    self.listData = @[self.enterPrice,self.enterNumber];
    
    self.tradeManager = [[TradeManager alloc] init];
    
    [self.view addSubview:self.listView];
}

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor whiteColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kListCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        _listView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,20)];
        _listView.tableHeaderView.backgroundColor = [UIColor clearColor];
        
        UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,180)];
        footView.backgroundColor = [UIColor whiteColor];
        _listView.tableFooterView = footView;
        
        UIButton *button = [UIButton button:CGRectMake(25,65,SCREEN_WIDTH-50,45) title:@"发布卖单"
                                 titleColor:[UIColor whiteColor] font:CommonFontLight(18) radius:3];
        button.backgroundColor = GradientColor(3,button.size);
        [button addTarget:self action:@selector(orderPublishAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:button];
    }
    
    return _listView;
}

- (void)orderPublishAction:(UIButton *)button {
    
    if (![self.enterPrice.enterView.text checkFloatNumber])
    {
        CommonShowTitle(@"单价是数字");
        return;
    }
    
    if (self.enterPrice.enterView.text.floatValue < 0)
    {
        CommonShowTitle(@"请输入大于0的单价");
        return;
    }
    
    
    if (![self.enterNumber.enterView.text checkFloatNumber])
    {
        CommonShowTitle(@"数量是数字");
        return;
    }
    
    if (self.enterNumber.enterView.text.floatValue < 0 || 300 < self.enterNumber.enterView.text.floatValue)
    {
        CommonShowTitle(@"请输入大于0，小于200的数量");
        return;
    }
    
    
    NSMutableDictionary *dty = [NSMutableDictionary dictionary];
    [dty setObject:self.enterPrice.enterView.text forKey:@"price"];
    [dty setObject:self.enterNumber.enterView.text forKey:@"count"];
    [self.tradeManager releaseOrder:dty result:^(HTTPDetails *result)
    {
        if (result.success)
        {
            CommonShowTitle(@"发布成功");
            
            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            CommonShowTitle(result.message);
        }
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIListViewCell *myCell = [UIListViewCell cellWithTableView:tableView];
    myCell.accessoryView = [self.listData objectAtIndex:indexPath.row];
    return myCell;
}

@end
