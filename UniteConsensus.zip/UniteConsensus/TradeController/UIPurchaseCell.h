//
//  UIPurchaseCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/10/26.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kPurchaseCellHeight  60

@interface PurchaseSellView : UIView

@property (nonatomic,strong) UILabel *lbt1;
@property (nonatomic,strong) UILabel *lbt2;

@end

@interface UIPurchaseCell : UITableViewCell

@end
