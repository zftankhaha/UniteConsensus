//
//  PurchaseController.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"

@interface PurchaseController : BaseViewController

@property (nonatomic,copy) NSString *orderID;

@end
