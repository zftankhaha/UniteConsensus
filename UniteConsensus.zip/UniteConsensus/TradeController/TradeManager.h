//
//  TradeCoinManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OrderDetails.h"

@interface TradeManager : NSObject

@property (nonatomic,strong) NSNumber *todayReference;
@property (nonatomic,strong) NSNumber *yestodayReference;
@property (nonatomic,copy) NSString *coinRate;

@property (nonatomic,copy) NSArray *listTrade;

//交易首页
- (void)listTradeResult:(void(^)(HTTPDetails *result))retHandler;

//点击出售按钮
- (void)releaseOrder:(NSDictionary *)dict result:(void(^)(HTTPDetails *result))retHandler;


//点击购买按钮
- (void)clickBuy:(NSString *)sid result:(void(^)(HTTPDetails *result))retHandler;

//确认购买
- (void)confirmBuy:(NSString *)sid result:(void(^)(HTTPDetails *result))retHandler;



- (void)completionOrderResult:(void(^)(HTTPDetails *result))retHandler;

@end
