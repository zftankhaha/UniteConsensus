//
//  PurchaseController.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "PurchaseController.h"
#import "TradeManager.h"
#import "UIPurchaseCell.h"

@interface PurchaseController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) TradeManager *tradeManager;

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@end

@implementation PurchaseController

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.showTitle = @"购买BT";
    
    if (CheckString(self.orderID))
    {
        NSMutableArray *list = [NSMutableArray array];
        [list addObject:[self createPurchaseView]];
        [list addObject:[self createPurchaseView]];
        [list addObject:[self createPurchaseView]];
        [list addObject:[self createPurchaseView]];
        [list addObject:[self createPurchaseView]];
        self.listData = list;
        
        [self.view addSubview:self.listView];
        
        WEAKSELF
        [self.tradeManager clickBuy:self.orderID result:^(HTTPDetails *result)
        {
            if (result.success)
            {
                //确认购买
                UIButton *button = [UIButton button:CGRectMake(50,38,SCREEN_WIDTH-100,40) title:@"确认购买"
                                         titleColor:[UIColor whiteColor] font:CommonFontLight(18) radius:3];
                button.backgroundColor = GradientColor(0,button.size);
                [weakSelf.listView.tableFooterView addSubview:button];
                [button actionForButton:^(UIButton *button)
                {
                    [weakSelf.tradeManager confirmBuy:weakSelf.orderID result:^(HTTPDetails *result)
                    {
                        if (result.success)
                        {
                            
                        }
                        else
                        {
                            CommonShowTitle(result.message);
                        }
                    }];
                }];
            }
            else
            {
                CommonShowTitle(result.message);
            }
        }];
    }
}

- (PurchaseSellView *)createPurchaseView {
    
    return [[PurchaseSellView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kPurchaseCellHeight)];
}

#pragma mark -
#pragma mark Get/Set

- (TradeManager *)tradeManager {
    
    if (!_tradeManager)
    {
        _tradeManager = [[TradeManager alloc] init];
    }
    
    return _tradeManager;
}

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kPurchaseCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        _listView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        _listView.tableHeaderView.backgroundColor = [UIColor clearColor];
        
        _listView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,100)];
    }
    
    return _listView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIPurchaseCell *myCell = [UIPurchaseCell cellWithTableView:tableView];
    myCell.accessoryView = [self.listData objectAtIndex:indexPath.row];
    return myCell;
}

@end
