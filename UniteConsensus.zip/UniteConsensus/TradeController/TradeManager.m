//
//  TradeCoinManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "TradeManager.h"

@interface TradeManager ()

@property (nonatomic,copy) NSArray *listRawTrade;

@end

@implementation TradeManager

- (void)listTradeResult:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/sell"];
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (result.success)
        {
            self.todayReference = [result.resultData customForKey:@"data.today_reference_price"];
            self.yestodayReference = [result.resultData customForKey:@"data.yesterday_refefence_price"];
            
            CGFloat today = self.todayReference.floatValue;
            CGFloat yestoday = self.yestodayReference.floatValue;
            CGFloat rate = 100*(today-yestoday)/yestoday;
            self.coinRate = [NSString stringWithFormat:@"%0.2f%@",rate,@"%"];
            
            NSArray *list = [result.resultData customForKey:@"data.sell_list"];
            NSMutableArray *listOrder = [NSMutableArray array];
            
            if (CheckArray(list))
            {
                for (NSDictionary *dty in list)
                {
                    OrderDetails *orderInfo = [[OrderDetails alloc] init];
                    [orderInfo resolutionDataSource:dty];
                    [listOrder addObject:orderInfo];
                }
            }
            
            self.listTrade = listOrder;
        }
        
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

- (void)releaseOrder:(NSDictionary *)dict result:(void(^)(HTTPDetails *result))retHandler {
    
    if (CommonATManager.checkLogin)
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/sell_gt"];
        details.requestHeader = dict;
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}



- (void)clickBuy:(NSString *)sid result:(void(^)(HTTPDetails *result))retHandler {
 
    if (CommonATManager.checkLogin && CheckString(sid))
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/purchase_gt_info"];
        details.requestHeader = [NSDictionary dictionaryWithObject:sid forKey:@"sid"];
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}

- (void)confirmBuy:(NSString *)sid result:(void(^)(HTTPDetails *result))retHandler {
    
    if (CommonATManager.checkLogin && CheckString(sid))
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/purchase_gt"];
        details.requestHeader = [NSDictionary dictionaryWithObject:sid forKey:@"sid"];
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            CommonShowTitle(result.message);
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}

//https://coin.hehuoya.com/index.php/api.SMSQiniu/token


- (void)completionOrderResult:(void(^)(HTTPDetails *result))retHandler {
    
    if (CommonATManager.checkLogin)
    {
        HTTPDetails *details = [[HTTPDetails alloc] init];
        details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APICoin/order"];
        
        [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }
        failure:^(HTTPDetails *result)
        {
            if (retHandler)
            {
                retHandler(result);
            }
        }];
    }
    else
    {
        if (retHandler)
        {
            retHandler(nil);
        }
    }
}



@end
