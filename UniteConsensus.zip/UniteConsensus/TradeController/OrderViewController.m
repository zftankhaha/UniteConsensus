//
//  OrderViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/21.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "OrderViewController.h"
#import "OrderViewCell.h"
#import "TradeManager.h"

@interface OrderViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,strong) UIButton *currentButton;

@property (nonatomic,strong) TradeManager *tradeManager;

@end

@implementation OrderViewController

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.showTitle = @"我的订单";
    
    [self.view addSubview:self.listView];
    
    
    [self.tradeManager completionOrderResult:nil];
}

- (TradeManager *)tradeManager {
    
    if (!_tradeManager)
    {
        _tradeManager = [[TradeManager alloc] init];
    }
    
    return _tradeManager;
}

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.rowHeight = kOrderCellHeight;
        _listView.delegate = self;
        _listView.dataSource = self;
        [_listView refresh:self header:YES footer:NO];
        
        UIHeaderView *headerView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,70)];
        _listView.tableHeaderView = headerView;
        
        
        UIButton *button = [UIButton button:CGRectMake(0,0,SCREEN_WIDTH/3,60) title:@"购买"
                                 titleColor:kDefaultRedColor font:CommonFontLight(19) radius:0];
        button.backgroundColor = [UIColor clearColor];
        [button addTarget:self action:@selector(switchOrderAction:) forControlEvents:UIControlEventTouchUpInside];
        [headerView addSubview:button];self.currentButton = button;
        
        UIButton *button1 = [UIButton button:CGRectMake(button.right,0,SCREEN_WIDTH/3,60) title:@"出售"
                                  titleColor:[UIColor blackColor] font:CommonFontLight(19) radius:0];
        [button1 addTarget:self action:@selector(switchOrderAction:) forControlEvents:UIControlEventTouchUpInside];
        button1.backgroundColor = [UIColor clearColor];[headerView addSubview:button1];
        
        UIButton *button2 = [UIButton button:CGRectMake(button1.right,0,SCREEN_WIDTH/3,60) title:@"已完成"
                                  titleColor:[UIColor blackColor] font:CommonFontLight(19) radius:0];
        [button2 addTarget:self action:@selector(switchOrderAction:) forControlEvents:UIControlEventTouchUpInside];
        button2.backgroundColor = [UIColor clearColor];[headerView addSubview:button2];
        
        
        //添加footerView
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        footerView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footerView;
    }
    
    return _listView;
}

- (void)switchOrderAction:(UIButton *)button {
    
    if (self.currentButton == button)
    {
        return;
    }
    
    [self.currentButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.currentButton = button;
    [self.currentButton setTitleColor:kDefaultRedColor forState:UIControlStateNormal];
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    OrderViewCell *myCell = [OrderViewCell cellWithTableView:tableView];
    
    return myCell;
}

@end
