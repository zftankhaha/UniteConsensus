//
//  OrderViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "OrderViewCell.h"

@implementation OrderViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        
    }
    
    return self;
}

@end
