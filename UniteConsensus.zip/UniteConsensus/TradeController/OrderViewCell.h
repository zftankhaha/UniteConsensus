//
//  OrderViewCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kOrderCellHeight  90

@interface OrderViewCell : UITableViewCell

@end
