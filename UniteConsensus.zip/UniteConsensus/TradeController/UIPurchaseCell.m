//
//  UIPurchaseCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/10/26.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UIPurchaseCell.h"

@implementation PurchaseSellView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        _lbt1 = [[UILabel alloc] initWithFrame:CGRectMake(20,0,110,kPurchaseCellHeight)];
        _lbt1.backgroundColor = [UIColor redColor];
        _lbt1.font = CommonFontLight(18);
        _lbt1.textAlignment = NSTextAlignmentLeft;
        [self addSubview:_lbt1];
        
        _lbt2 = [[UILabel alloc] initWithFrame:CGRectMake(_lbt1.right+10,0,SCREEN_WIDTH-_lbt1.right-10-20,kPurchaseCellHeight)];
        _lbt2.backgroundColor = [UIColor yellowColor];
        _lbt2.font = CommonFontLight(18);
        _lbt2.textAlignment = NSTextAlignmentLeft;
        _lbt2.textColor = kBackBColor;
        [self addSubview:_lbt2];
    }
    
    return self;
}

@end



@implementation UIPurchaseCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
 
    self.accessoryView.frame = CGRectMake(0,0,SCREEN_WIDTH,kPurchaseCellHeight);
}

@end
