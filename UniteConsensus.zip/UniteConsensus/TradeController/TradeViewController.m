//
//  TradeViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/6.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "TradeViewController.h"
#import "OrderViewController.h"
#import "PublishOrderController.h"
#import "PurchaseController.h"
#import "TradeManager.h"
#import "TradeViewCell.h"

@interface TradeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UILabel *todayReference;
@property (nonatomic,strong) UILabel *yesterdayReference;
@property (nonatomic,strong) UILabel *coinRate;

@property (nonatomic,strong) UITableView *listView;

@property (nonatomic,strong) TradeManager *tradeManager;

@property (nonatomic,strong) UIButton *filterButton;

@end

@implementation TradeViewController

- (void)clickTabForRepeat {
    
    if (![self.listView currentLoading])
    {
        [self.listView setContentOffset:CGPointZero animated:YES];
    }
}

- (void)listOrderAction:(UIButton *)button {
    
    [CommonATManager loginUserAccount:^(BOOL completion)
    {
        if (completion)
        {
            OrderViewController *orderController = [[OrderViewController alloc] init];
            [self.navigationController pushViewController:orderController animated:YES];
        }
    }];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"交易";
    [self refreshRightBarButton:@"我的订单" action:@selector(listOrderAction:)];
    self.tradeManager = [[TradeManager alloc] init];
    [self.view addSubview:self.listView];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self refreshDataSource:YES];
}

- (void)refreshDataSource:(BOOL)refreshDrop {
    
    [UCShowHUD showLoading:self.navigationController.view];

    [self.tradeManager listTradeResult:^(HTTPDetails *result)
    {
        [UCShowHUD dismissLoading:self.navigationController.view];

        [self.listView completeLoading:NO];

        if (result.success)
        {
            self.todayReference.text = [NSString stringWithFormat:@"%0.3f",self.tradeManager.todayReference.floatValue];
            self.yesterdayReference.text = [NSString stringWithFormat:@"%0.3f",self.tradeManager.yestodayReference.floatValue];
            self.coinRate.text = [NSString stringWithFormat:@"%@",self.tradeManager.coinRate];

            [self.filterButton setTitle:@"筛选" forState:UIControlStateNormal];
            
            

            [self.listView reloadData];
        }
        else
        {
            CommonShowTitle(result.message);
        }
    }];
}

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGFloat height = SCREEN_HEIGHT-HeadBar_HEIGHT-TabBar_HEIGHT;
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,height);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kTradeCellHeight;
        [_listView refresh:self header:YES footer:NO];
        
        UIHeaderView *referenceView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,149)];
        _listView.tableHeaderView = referenceView;

        UILabel *reference1 = [[UILabel alloc] initWithFrame:CGRectMake(22,11,120,30)];
        reference1.backgroundColor = [UIColor clearColor];
        reference1.font = CommonFontLight(17);
        reference1.textAlignment = NSTextAlignmentLeft;
        reference1.textColor = [UIColor blackColor];
        reference1.text = @"今日参考价";
        [referenceView addSubview:reference1];

        self.todayReference = [[UILabel alloc] initWithFrame:CGRectMake(20,reference1.bottom,120,30)];
        self.todayReference.backgroundColor = [UIColor clearColor];
        self.todayReference.font = CommonFontLight(25);
        self.todayReference.textAlignment = NSTextAlignmentLeft;
        self.todayReference.textColor = kBackBColor;
        self.todayReference.text = @"--";
        [referenceView addSubview:self.todayReference];

        
        UILabel *reference2 = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-165-20,10,98,30)];
        reference2.backgroundColor = [UIColor clearColor];
        reference2.font = CommonFontLight(17);
        reference2.textAlignment = NSTextAlignmentLeft;
        reference2.textColor = [UIColor blackColor];
        reference2.text = @"昨日参考价:";
        [referenceView addSubview:reference2];
        
        self.yesterdayReference = [[UILabel alloc] initWithFrame:CGRectMake(reference2.right,9,70,30)];
        self.yesterdayReference.backgroundColor = [UIColor clearColor];
        self.yesterdayReference.font = CommonFontLight(19);
        self.yesterdayReference.textAlignment = NSTextAlignmentLeft;
        self.yesterdayReference.textColor = [UIColor blackColor];
        self.yesterdayReference.text = @"--";
        [referenceView addSubview:self.yesterdayReference];

        
        UILabel *reference3 = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-165-20,41,48,30)];
        reference3.backgroundColor = [UIColor clearColor];
        reference3.font = CommonFontLight(17);
        reference3.textAlignment = NSTextAlignmentLeft;
        reference3.textColor = [UIColor blackColor];
        reference3.text = @"涨幅:";
        [referenceView addSubview:reference3];
        
        self.coinRate = [[UILabel alloc] initWithFrame:CGRectMake(reference3.right,40,80,30)];
        self.coinRate.backgroundColor = [UIColor clearColor];
        self.coinRate.font = CommonFontLight(19);
        self.coinRate.textAlignment = NSTextAlignmentLeft;
        self.coinRate.textColor = [UIColor blackColor];
        self.coinRate.text = @"--";
        [referenceView addSubview:self.coinRate];

        //订单筛选//出售
        WEAKSELF
        self.filterButton = [UIButton button:CGRectMake(20,85,125,37) title:@"筛选"
                                  titleColor:[UIColor whiteColor] font:CommonFontLight(18) radius:3];
        self.filterButton.backgroundColor = GradientColor(1,self.filterButton.size);
        [referenceView addSubview:self.filterButton];
        [self.filterButton actionForButton:^(UIButton *button)
        {
            [UCSheetManager show:@"选择数量" list:@[@"1 ~ 20",@"21 ~ 100",@"101 ~ 200",@"所有卖单"]
                          cancel:@"取消" click:^(NSInteger index,NSArray *listTitle) {
                
                if (index < 0)
                {
                    return;
                }
                
                if (index == listTitle.count-1)
                {
                    [button setTitle:@"筛选" forState:UIControlStateNormal];
                }
                else
                {
                    [button setTitle:listTitle[index] forState:UIControlStateNormal];
                }
                
                [weakSelf.listView reloadData];
            }];
        }];
        
        UIButton *button = [UIButton button:CGRectMake(SCREEN_WIDTH-125-20,85,125,37) title:@"出售"
                                 titleColor:[UIColor whiteColor] font:CommonFontLight(18) radius:3];
        button.backgroundColor = GradientColor(0,button.size);[referenceView addSubview:button];
        [button actionForButton:^(UIButton *button)
        {
            [CommonATManager loginUserAccount:^(BOOL completion)
            {
                if (completion)
                {
                    PublishOrderController *publishController = [[PublishOrderController alloc] init];
                    publishController.todayReference = weakSelf.tradeManager.todayReference;
                    [weakSelf.navigationController pushViewController:publishController animated:YES];
                }
            }];
        }];
        
        //添加footerView
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        footerView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footerView;
    }
    
    return _listView;
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.tradeManager.listTrade.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TradeViewCell *myCell = [TradeViewCell cellWithTableView:tableView];
    myCell.delegate = self;
    [myCell refreshTradeCellSource:[self.tradeManager.listTrade objectAtIndex:indexPath.row]];
    return myCell;
}

- (void)selectActionIndexPath:(OrderDetails *)orderInfo {

    if (CommonATManager.checkLogin)
    {
        PurchaseController *buyController = [[PurchaseController alloc] init];
        buyController.orderID = orderInfo.orderID;
        [self.navigationController pushViewController:buyController animated:YES];
    }
    else
    {
        [CommonATManager loginUserAccount:nil];
    }
}

@end
