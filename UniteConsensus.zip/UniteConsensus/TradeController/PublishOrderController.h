//
//  PublishOrderController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"

@interface PublishOrderController : BaseViewController

@property (nonatomic,strong) NSNumber *todayReference;

@end
