//
//  UITradeViewCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/12.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "TradeViewCell.h"

@implementation TradeViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        
        UIImageView *sView = [[UIImageView alloc] initWithFrame:CGRectMake(10,0,50,kTradeCellHeight)];
        sView.backgroundColor = [UIColor clearColor];
        sView.contentMode = UIViewContentModeCenter;
        sView.image = [UIImage imageNamed:@"tradeac"];
        [self.contentView addSubview:sView];
        
        self.count = [[UILabel alloc] initWithFrame:CGRectMake(sView.right+10,0,110,53)];
        self.count.backgroundColor = [UIColor clearColor];
        self.count.font = CommonFontLight(18);
        self.count.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:self.count];
        
        self.price = [[UILabel alloc] initWithFrame:CGRectMake(sView.right+10,33,110,kTradeCellHeight-36)];
        self.price.backgroundColor = [UIColor clearColor];
        self.price.font = CommonFontLight(18);
        self.price.textAlignment = NSTextAlignmentLeft;
        self.price.textColor = kBackBColor;
        [self.contentView addSubview:self.price];
        
        
        WEAKSELF
        self.tradeButton = [UIButton button:CGRectMake(SCREEN_WIDTH-20-110,(kTradeCellHeight-35)/2,110,35) title:@"购买"
                                 titleColor:[UIColor whiteColor] font:CommonFontRegular(18) radius:3];
        self.tradeButton.backgroundColor = GradientColor(0,self.tradeButton.size);
        [self.contentView addSubview:self.tradeButton];
        [self.tradeButton actionForButton:^(UIButton *button)
        {
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(selectActionIndexPath:)])
            {
                [weakSelf.delegate selectActionIndexPath:weakSelf.orderInfo];
            }
        }];
    }
    
    return self;
}

- (void)refreshTradeCellSource:(OrderDetails *)orderInfo {
    
    self.orderInfo = orderInfo;
    
    self.price.text = [NSString stringWithFormat:@"单价  %@",self.orderInfo.coinPrice];
    
    self.count.text = [NSString stringWithFormat:@"数量  %@",self.orderInfo.coinCount];
}

@end
