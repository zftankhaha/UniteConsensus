//
//  LoginManager.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/20.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "LoginCommon.h"
#import <Foundation/Foundation.h>

#define CommonATManager    [LoginManager shareInstance]

#define kLoginStateChange  @"kLoginStateChange"

@interface LoginManager : NSObject <LoginCommon>

@property (copy,readonly) NSString *userToken;

@property (readonly) BOOL checkLogin;


- (void)loginUserAccount:(void(^)(BOOL completion))result;

- (void)logoutUserAccount:(void(^)(void))result;

@end
