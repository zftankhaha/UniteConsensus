//
//  AccountManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/13.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "LoginCommon.h"
#import <Foundation/Foundation.h>
#import "CoinInfomation.h"

#define CommonUserManager    [AccountManager accountInstance]

#define CommonUserDetails    [[AccountManager accountInstance] userInfo]

@interface UserDetails : NSObject

@property (copy) NSString *realName;//实名认证//0没有认证//1待审核//2已审核
@property (copy) NSString *ownActivity;//个人活跃度
@property (copy) NSString *unionActivity;//联盟活跃度
@property (copy) NSString *userLevel;//用户级别//T1、2、3

@property (copy) NSString *userMobile;//用户手机
@property (copy) NSString *nickName;//昵称
@property (copy) NSString *ownInviteCode;//我的邀请码

@property (strong) CoinInfomation *btCoin;
@property (strong) CoinInfomation *bdCoin;
@property (strong) CoinInfomation *absCoin;
@property (strong) CoinInfomation *bcCoin;

@end

@interface AccountManager : NSObject <LoginCommon>

@property (strong,readonly) UserDetails *userInfo;

- (void)accountInfomation:(void(^)(HTTPDetails *result))retHandler;

@end
