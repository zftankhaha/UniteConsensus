//
//  LoginCommon.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/20.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

@class LoginManager;
@class AccountManager;
@class VersionManager;

@protocol LoginCommon <NSObject>

@optional

#pragma mark -
#pragma mark LoginManager

+ (LoginManager *)shareInstance;

- (void)renounceAction;

- (void)refreshUserInfomation:(id)dataSource;

- (void)completionLoginAction;

#pragma mark -
#pragma mark AccountManager

+ (AccountManager *)accountInstance;

- (void)clearAccountAction;

#pragma mark -
#pragma mark CheckVersion

+ (VersionManager *)shareVersion;

@end
