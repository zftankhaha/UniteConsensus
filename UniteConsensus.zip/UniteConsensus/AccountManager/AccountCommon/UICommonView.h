//
//  UIEnterView.h
//  Follow
//
//  Created by zftank on 2020/6/28.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UICommonViewDelegate <NSObject>

- (void)clickCheckSMSAction;

@end


@interface UICommonView : UIView <UITextFieldDelegate>

@property (nonatomic,weak) id delegate;

@property (nonatomic,strong) UILabel *lbTitle;

@property (nonatomic,strong) UITextField *enterView;

@property (nonatomic,strong) UIButton *actionButton;

- (void)refreshTitle:(NSString *)title enterView:(NSString *)enter;

- (void)addCheckSMSAction;

@end
