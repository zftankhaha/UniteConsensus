//
//  UIListViewCell.m
//  Follow
//
//  Created by zftank on 2020/6/28.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "UIListViewCell.h"

@implementation UIListViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
 
    self.accessoryView.frame = CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight);
}

@end
