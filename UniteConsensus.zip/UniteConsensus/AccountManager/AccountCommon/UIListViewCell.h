//
//  UIListViewCell.h
//  Follow
//
//  Created by zftank on 2020/6/28.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kListCellHeight   80

@interface UIListViewCell : UITableViewCell

@end
