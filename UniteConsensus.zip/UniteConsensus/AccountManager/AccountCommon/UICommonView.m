//
//  UIEnterView.m
//  Follow
//
//  Created by zftank on 2020/6/28.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "UICommonView.h"

@implementation UICommonView

- (instancetype)initWithFrame:(CGRect)frame {

    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        
        _lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(25,10,SCREEN_WIDTH-50,20)];
        _lbTitle.backgroundColor = [UIColor clearColor];
        _lbTitle.font = CommonFontLight(18.5);
        _lbTitle.textAlignment = NSTextAlignmentLeft;
        _lbTitle.textColor = kDefaultRedColor;
        [self addSubview:_lbTitle];
        
        _enterView = [[UITextField alloc] initWithFrame:CGRectMake(25,_lbTitle.bottom,SCREEN_WIDTH-50,50)];
        _enterView.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _enterView.backgroundColor = [UIColor clearColor];
        
        _enterView.rightViewMode = UITextFieldViewModeAlways;
        _enterView.delegate = self;
        
        _enterView.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _enterView.font = CommonFontLight(18);
        _enterView.returnKeyType = UIReturnKeyDefault;
        _enterView.borderStyle = UITextBorderStyleNone;
        _enterView.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        _enterView.textColor = [UIColor blackColor];
        
        [_enterView bottomLineX:0 width:_enterView.width color:nil];
        
        [self addSubview:_enterView];
    }
    
    return self;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [self.enterView resignFirstResponder];
    
    return YES;
}

- (void)refreshTitle:(NSString *)title enterView:(NSString *)enter {
    
    self.lbTitle.text = title;
    self.enterView.placeholder = enter;
}

- (void)addCheckSMSAction {
    
    self.actionButton = [UIButton button:CGRectMake(0,0,100,self.enterView.height) title:@"获取验证码"
                              titleColor:kDefaultRedColor font:CommonFontLight(17) radius:0];
    [self.actionButton addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
    self.enterView.rightView = self.actionButton;
}

- (void)clickAction:(UIButton *)button {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickCheckSMSAction)])
    {
        [self.delegate clickCheckSMSAction];
    }
}

@end
