//
//  HashCoinManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/19.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "NSModelManager.h"

@interface HashCoinManager : NSModelManager

@end
