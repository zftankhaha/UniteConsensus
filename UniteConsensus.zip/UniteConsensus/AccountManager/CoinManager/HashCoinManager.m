//
//  HashCoinManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/19.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "HashCoinManager.h"

@implementation HashCoinManager

@end
