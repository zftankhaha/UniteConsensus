//
//  CoinViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/15.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "CoinViewController.h"
#import "CoinViewCell.h"

@interface CoinViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,assign) CoinType coinType;

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UILabel *title1;
@property (nonatomic,strong) UILabel *title2;
@property (nonatomic,strong) UILabel *title3;

@end

@implementation CoinViewController

- (instancetype)initWithCoinType:(CoinType)coinType {
    
    self = [super init];
    
    if (self)
    {
        _coinType = coinType;
    }
    
    return self;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    CoinInfomation *coinInfo = [CoinInfomation coinInfomation:self.coinType];
    self.showTitle = coinInfo.showTitle;
    
    [self.view addSubview:self.listView];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        
        //加载headerView
        _listView.tableHeaderView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,128)];
        
        UILabel *atitle = [[UILabel alloc] initWithFrame:CGRectMake(20,7,100,30)];
        atitle.backgroundColor = [UIColor clearColor];
        atitle.font = CommonFontLight(16);
        atitle.text = @"总数量";
        atitle.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:atitle];
        
        self.title1 = [[UILabel alloc] initWithFrame:CGRectMake(atitle.left,atitle.bottom,120,30)];
        self.title1.backgroundColor = [UIColor clearColor];
        self.title1.font = CommonFontLight(20);
        self.title1.text = @"6700.00";
        self.title1.textColor = kBackBColor;
        self.title1.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:self.title1];
        
        UILabel *btitle = [[UILabel alloc] initWithFrame:CGRectMake(atitle.left,5+self.title1.bottom,90,30)];
        btitle.backgroundColor = [UIColor clearColor];
        btitle.font = CommonFontLight(18);
        btitle.text = @"可用数量 :";
        btitle.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:btitle];

        self.title2 = [[UILabel alloc] initWithFrame:CGRectMake(btitle.right,btitle.top,120,30)];
        self.title2.backgroundColor = [UIColor clearColor];
        self.title2.font = CommonFontLight(18);
        self.title2.text = @"6700.00";
        self.title2.textColor = kBackBColor;
        self.title2.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:self.title2];
        
        UILabel *ctitle = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-90-90,8,90,30)];
        ctitle.backgroundColor = [UIColor clearColor];
        ctitle.font = CommonFontLight(17);
        ctitle.text = @"锁仓数量 :";
        ctitle.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:ctitle];

        self.title3 = [[UILabel alloc] initWithFrame:CGRectMake(ctitle.right,8,90,30)];
        self.title3.backgroundColor = [UIColor clearColor];
        self.title3.font = CommonFontLight(17);
        self.title3.text = @"0.0";
        self.title3.textColor = kBackBColor;
        self.title3.textAlignment = NSTextAlignmentLeft;
        [_listView.tableHeaderView addSubview:self.title3];
        
        if (self.coinType == CoinBTType)
        {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(SCREEN_WIDTH-25-110,128-35-27,110,35);
            button.backgroundColor = GradientColor(0,button.size);
            button.titleLabel.font = CommonFontLight(16.0f);
            CoinInfomation *coinInfo = [CoinInfomation coinInfomation:CoinABSType];
            [button setTitle:[NSString stringWithFormat:@"兑换%@",coinInfo.showTitle] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            //[button addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
            //button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
            button.layer.cornerRadius = 5;
            button.layer.masksToBounds = YES;
            [_listView.tableHeaderView addSubview:button];
        }
    }
    
    return _listView;
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

@end
