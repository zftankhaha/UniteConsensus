//
//  CoinViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/15.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"
#import "HashCoinManager.h"

@interface CoinViewController : BaseViewController

- (instancetype)initWithCoinType:(CoinType)coinType;

@end
