//
//  CoinInfomation.h
//  UniteConsensus
//
//  Created by zftank on 2020/8/6.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger,CoinType) {

    CoinBTType = 0,        //BT//基础通证
    CoinBDType = 1,        //BD//推广奖励通证
    CoinABSType = 2,       //ABS//稳定币
    CoinBCType = 3,        //BC//股权通证
};

@interface CoinInfomation : NSObject

@property (assign) CoinType coinType;
@property (copy) NSString *showTitle;
@property (copy) NSString *describe;

@property (strong) NSNumber *coinNumber;//总数量
@property (strong) NSNumber *freeNumber;//可用数量
@property (strong) NSNumber *lockNumber;//锁仓数量

+ (NSArray *)rawListCoin;
+ (NSArray *)currentListCoin;
+ (CoinInfomation *)coinInfomation:(CoinType)coinType;

- (void)refresh:(NSNumber *)freeNumber lockNumber:(NSNumber *)lockNumber;

@end
