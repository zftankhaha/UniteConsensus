//
//  CoinInfomation.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/6.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "CoinInfomation.h"

@implementation CoinInfomation

+ (NSArray *)rawListCoin {
    
    static NSArray *listCoin = nil;
    
    if (!listCoin)
    {
        NSString *current = [[NSBundle mainBundle] pathForResource:@"ListCoin" ofType:@"plist"];
        listCoin = [NSArray arrayWithContentsOfFile:current];
    }
    
    return listCoin;
}

+ (CoinInfomation *)coinInfomation:(CoinType)coinType {
    
    NSDictionary *dataSource = [CoinInfomation.rawListCoin objectAtIndex:coinType];
    
    CoinInfomation *coinInfo = [[CoinInfomation alloc] init];
    coinInfo.coinType = [dataSource[@"coinType"] intValue];
    coinInfo.showTitle = dataSource[@"showTitle"];
    coinInfo.describe = dataSource[@"describe"];
    
    coinInfo.freeNumber = [NSNumber numberWithFloat:0.0];
    coinInfo.lockNumber = [NSNumber numberWithFloat:0.0];
    coinInfo.coinNumber = [NSNumber numberWithFloat:0.0];
    
    return coinInfo;
}

+ (NSArray *)currentListCoin {
    
    NSArray *listCoin = CoinInfomation.rawListCoin;
    
    NSMutableArray *listInfo = [NSMutableArray array];
    
    for (NSDictionary *dty in listCoin)
    {
        CoinInfomation *coinInfo = [[CoinInfomation alloc] init];
        coinInfo.coinType = [dty[@"coinType"] intValue];
        coinInfo.showTitle = dty[@"showTitle"];
        coinInfo.describe = dty[@"describe"];
        
        coinInfo.freeNumber = [NSNumber numberWithFloat:0.0];
        coinInfo.lockNumber = [NSNumber numberWithFloat:0.0];
        coinInfo.coinNumber = [NSNumber numberWithFloat:0.0];
        
        [listInfo addObject:coinInfo];
    }
    
    return [listInfo copy];
}


- (void)refresh:(NSNumber *)freeNumber lockNumber:(NSNumber *)lockNumber {
    
    self.freeNumber = freeNumber;
    self.lockNumber = lockNumber;
    
    CGFloat number = self.freeNumber.floatValue+self.lockNumber.floatValue;
    self.coinNumber = [NSNumber numberWithFloat:number];
}

@end
