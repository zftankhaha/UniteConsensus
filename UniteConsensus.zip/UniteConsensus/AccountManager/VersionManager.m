//
//  VersionManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/24.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "VersionManager.h"

@implementation VersionInfo

- (void)resolutionDataSource:(id)dataSource {
    
    NSString *version = [[dataSource customForKey:@"app_version"] description];
    self.serverVersion = CheckString(version)?version:@"1.0.0";
    
    self.upgradeUrl = [dataSource customForKey:@"app_download_url"];
    self.isUpgrade = [[dataSource customForKey:@"app_should_force_update"] boolValue];
}

@end

@implementation VersionManager

+ (VersionManager *)shareVersion {
    
    static dispatch_once_t onceToken;
    static VersionManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[VersionManager alloc] init];
        shareInstance.versionInfo = [[VersionInfo alloc] init];
        shareInstance.versionInfo.isUpgrade = NO;
    });
    
    return shareInstance;
}

- (void)checkVersion:(BOOL)showTips result:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APIBoot/load",kConsensusHost];
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (result.success)
        {
            VersionInfo *versionInfo = [[VersionInfo alloc] init];
            [versionInfo resolutionDataSource:[result.resultData customForKey:@"data"]];
            self.versionInfo = versionInfo;
            
            if ([APP_SHORT_VERSION compare:self.versionInfo.serverVersion] == NSOrderedAscending)
            {
                [UCAlertManager show:@"升级提示" message:@"需要升级最新版本" cancel:nil sure:@"确定" click:^(AlertClickType clickType)
                {
                    [self openSkipUrl:self.versionInfo.upgradeUrl];
                    [self exitAppAction];
                }];
            }
            else
            {
                if (showTips)
                {
                    CommonShowTitle(@"当前已是最新版本");
                }
            }
        }
        
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

- (void)exitAppAction {
    
    exit(0);
}

- (void)openSkipUrl:(NSString *)strUrl {
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:strUrl]
                                       options:@{UIApplicationOpenURLOptionsSourceApplicationKey:@YES}
                             completionHandler:nil];
}

@end
