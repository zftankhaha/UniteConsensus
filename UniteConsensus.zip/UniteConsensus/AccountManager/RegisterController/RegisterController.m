//
//  RegisterController.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/20.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "RegisterController.h"
#import "RegisterManager.h"
#import "UICommonView.h"
#import "UIListViewCell.h"

@interface RegisterController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UICommonView *nickNameEnter;
@property (nonatomic,strong) UICommonView *phoneEnter;
@property (nonatomic,strong) UICommonView *checkEnter;//短信验证码
@property (nonatomic,strong) UICommonView *passwordEnter;
@property (nonatomic,strong) UICommonView *enterOfInvite;//邀请码

@property (nonatomic,strong) UIButton *registerButton;

@property (nonatomic,strong) RegisterManager *registerManager;

@end

@implementation RegisterController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"欢迎注册";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.listView];
    
    self.nickNameEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.nickNameEnter refreshTitle:@"昵称" enterView:@"请输入昵称"];
    
    self.phoneEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.phoneEnter refreshTitle:@"手机号" enterView:@"请输入手机号码"];
    
    self.checkEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.checkEnter refreshTitle:@"验证码" enterView:@"请输入短信验证码"];
    self.checkEnter.delegate = self;[self.checkEnter addCheckSMSAction];
    
    self.passwordEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    self.passwordEnter.enterView.secureTextEntry = YES;
    [self.passwordEnter refreshTitle:@"密码" enterView:@"请设置密码"];
    
    self.enterOfInvite = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.enterOfInvite refreshTitle:@"邀请码" enterView:@"请输入邀请码"];
    
    self.listData = @[self.nickNameEnter,self.phoneEnter,self.checkEnter,self.passwordEnter,self.enterOfInvite];
}

- (void)clickCheckSMSAction {
    
    if (![self.nickNameEnter.enterView.text isPhoneNumber])
    {
        CommonShowTitle(@"请输入正确的手机号码");
        return;
    }
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kListCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        _listView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        _listView.tableHeaderView.backgroundColor = [UIColor clearColor];
        
        UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,410)];
        footView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footView;
        
        //注册
        self.registerButton = [UIButton button:CGRectMake(25,55,SCREEN_WIDTH-50,45) title:@"注册"
                                    titleColor:[UIColor whiteColor] font:CommonFontRegular(17) radius:3];
        self.registerButton.backgroundColor = GradientColor(3,self.registerButton.size);
        [self.registerButton addTarget:self action:@selector(registerAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:self.registerButton];
    }
    
    return _listView;
}

- (void)registerAction:(UIButton *)button {
    
    if (self.nickNameEnter.enterView.text.length <= 0)
    {
        CommonShowTitle(@"请输入昵称");
        return;
    }
    
    if (![self.phoneEnter.enterView.text isPhoneNumber])
    {
        CommonShowTitle(@"请输入正确的手机号码");
        return;
    }

    if (![self.checkEnter.enterView.text checkPureNumberPassword])
    {
        CommonShowTitle(@"请输入验证码");
        return;
    }

    if (self.passwordEnter.enterView.text.length < 8)
    {
        CommonShowTitle(@"密码至少8位");
        return;
    }
    
    NSMutableDictionary *dty = [NSMutableDictionary dictionary];
    [dty setObject:self.nickNameEnter.enterView.text forKey:@"nickname"];
    [dty setObject:self.phoneEnter.enterView.text forKey:@"phone"];
    [dty setObject:self.checkEnter.enterView.text forKey:@"smscode"];
    [dty setObject:[CodeFunction MD5:self.passwordEnter.enterView.text] forKey:@"pwd"];
    
    NSString *currentInvite = self.enterOfInvite.enterView.text;
    if (currentInvite.length < 2) {currentInvite = @"AAAAAAAA";}
    [dty setObject:currentInvite forKey:@"invitecode"];
    
    CommonShowLoading;
    
    [self.registerManager completion:dty result:^(HTTPDetails *result)
    {
        CommonExitLoading;
        CommonShowTitle(result.message);
        
        if (result.success)
        {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }];
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIListViewCell *myCell = [UIListViewCell cellWithTableView:tableView];
    
    myCell.accessoryView = [self.listData objectAtIndex:indexPath.row];
    
    return myCell;
}

- (RegisterManager *)registerManager {
    
    if (!_registerManager)
    {
        _registerManager = [[RegisterManager alloc] init];
    }
    
    return _registerManager;
}

@end
