//
//  RegisterController.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/20.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "BaseViewController.h"

@interface RegisterController : BaseViewController

@end
