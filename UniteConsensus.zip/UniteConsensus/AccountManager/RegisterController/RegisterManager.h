//
//  RegisterManager.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/23.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "NSModelManager.h"

@interface RegisterManager : NSModelManager

//注册
- (void)completion:(NSDictionary *)dty result:(void(^)(HTTPDetails *result))retHandler;

@end
