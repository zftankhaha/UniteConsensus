//
//  RegisterManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/23.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "RegisterManager.h"

@implementation RegisterManager

//注册
- (void)completion:(NSDictionary *)dty result:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APIUser/regist",kConsensusHost];
    details.andBody = dty;
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

@end
