//
//  LoginManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/20.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "LoginManager.h"
#import "LoginViewController.h"

#define ACUserToken   @"ACUserToken1.0.0"

@interface LoginManager ()

@property (copy) NSString *userToken;

@property (copy) void(^loginHandler)(BOOL completion);
@property (copy) void(^logoutHandler)(void);

@property (strong) CTStackController *stackController;
@property (strong) LoginViewController *loginController;

@end

@implementation LoginManager

+ (LoginManager *)shareInstance {
    
    static dispatch_once_t onceToken;
    static LoginManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[LoginManager alloc] init];
        shareInstance.userToken = [FileManager objectForKey:ACUserToken catalogue:LogDocument];
    });
    
    return shareInstance;
}

- (void)refreshUserInfomation:(id)dataSource {
    
    if (CheckDictionary(dataSource))
    {
        NSString *currentToken = [[dataSource customForKey:@"uid"] description];
        
        if (CheckString(currentToken))
        {
            self.userToken = currentToken;
            [FileManager setObject:self.userToken forKey:ACUserToken catalogue:LogDocument];
        }
    }
    else
    {
        self.userToken = nil;
        [CommonUserManager clearAccountAction];
        
        [FileManager deleteCatalogue:LogDocument];
        [FileManager deleteCatalogue:LogAccount];
    }
}

- (void)cleanMemoryAction {
    
    self.loginHandler = nil;
    self.logoutHandler = nil;
    
    self.loginController = nil;
    self.stackController.delegate = nil;
    self.stackController = nil;
}

- (void)loginStateChange {
    
    [CommonNotification postNotificationName:kLoginStateChange object:nil];
}

#pragma mark -
#pragma mark 退出//放弃登录

- (void)logoutUserAccount:(void(^)(void))result {

    self.logoutHandler = result;
    [self refreshUserInfomation:nil];
    
    if (self.logoutHandler)
    {
        self.logoutHandler();
    }
    
    [self loginStateChange];
    [self cleanMemoryAction];
}

- (void)renounceAction {
    
    if (self.loginHandler)
    {
        self.loginHandler(self.checkLogin);
    }
    
    [self cleanMemoryAction];
}

#pragma mark -
#pragma mark 登录事件

- (BOOL)checkLogin {
    
    return CheckString(self.userToken);
}

- (void)loginUserAccount:(void(^)(BOOL completion))result {

    dispatch_async(dispatch_get_main_queue(),^{
        
        self.loginHandler = result;
        
        if (self.checkLogin)
        {
            if (self.loginHandler)
            {
                self.loginHandler(YES);
            }
            
            [self cleanMemoryAction];
        }
        else
        {
            self.loginController = [[LoginViewController alloc] init];
            self.stackController = [[CTStackController alloc] initRootController:self.loginController];
            self.stackController.modalPresentationStyle = UIModalPresentationFullScreen;
            [CommonDelegate.rootController presentViewController:self.stackController animated:YES completion:nil];
        }
    });
}

- (void)completionLoginAction {
    
    if (!self.checkLogin)
    {
        return;
    }
    
    CommonShowLoading;
    
    dispatch_async(dispatch_get_main_queue(),^{

        [self.stackController dismissViewControllerAnimated:YES completion:^{

            if (self.loginHandler)
            {
                self.loginHandler(YES);
            }

            CommonExitLoading;
            [self loginStateChange];
            [self cleanMemoryAction];
        }];
    });
}

@end
