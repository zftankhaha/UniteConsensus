//
//  ForgetController.m
//  Follow
//
//  Created by zftank on 2020/6/29.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "ForgetController.h"
#import "UICommonView.h"
#import "UIListViewCell.h"
#import "ForgetManager.h"

@interface ForgetController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UICommonView *nameEnter;
@property (nonatomic,strong) UICommonView *checkEnter;
@property (nonatomic,strong) UICommonView *passwordEnter;

@property (nonatomic,strong) UIButton *reviseButton;

@property (nonatomic,strong) ForgetManager *forgetManager;

@end

@implementation ForgetController

- (instancetype)init {
    
    self = [super init];
    
    if (self)
    {
        _fromType = FromCommonType;
    }
    
    return self;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"重置密码";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.listView];
    
    self.nameEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.nameEnter refreshTitle:@"手机号" enterView:@"请输入手机号码"];
    
    self.checkEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.checkEnter refreshTitle:@"验证码" enterView:@"请输入短信验证码"];
    self.checkEnter.delegate = self;[self.checkEnter addCheckSMSAction];
    
    self.passwordEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    self.passwordEnter.enterView.secureTextEntry = YES;
    [self.passwordEnter refreshTitle:@"密码" enterView:@"请设置新密码"];
    
    self.listData = @[self.nameEnter,self.checkEnter,self.passwordEnter];
}

- (void)clickCheckSMSAction {
    
    if (![self.nameEnter.enterView.text isPhoneNumber])
    {
        CommonShowTitle(@"请输入正确的手机号码");
        return;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    [self resignCurrentResponder];
}

- (void)resignCurrentResponder {
    
    [self.nameEnter.enterView resignFirstResponder];
    [self.checkEnter.enterView resignFirstResponder];
    [self.passwordEnter.enterView resignFirstResponder];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kListCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        _listView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        _listView.tableHeaderView.backgroundColor = [UIColor clearColor];
        
        UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,150)];
        footView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footView;
        
        WEAKSELF
        UIButton *returnButton = [UIButton buttonWithType:UIButtonTypeCustom];
        returnButton.frame = footView.bounds;
        returnButton.backgroundColor = [UIColor clearColor];
        [returnButton actionForButton:^(UIButton *button){[weakSelf resignCurrentResponder];}];
        [footView addSubview:returnButton];
        
        //修改密码
        self.reviseButton = [UIButton button:CGRectMake(25,60,SCREEN_WIDTH-50,45) title:@"修改密码"
                                  titleColor:[UIColor whiteColor] font:CommonFontRegular(17) radius:3];
        self.reviseButton.backgroundColor = GradientColor(3,self.reviseButton.size);
        [self.reviseButton addTarget:self action:@selector(reviseAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:self.reviseButton];
    }
    
    return _listView;
}

- (void)reviseAction:(UIButton *)button {
    
    if (![self.nameEnter.enterView.text isPhoneNumber])
    {
        CommonShowTitle(@"请输入正确的手机号码");
        return;
    }
    
    if (![self.checkEnter.enterView.text checkPureNumberPassword])
    {
        CommonShowTitle(@"请输入验证码");
        return;
    }
    
    if (self.passwordEnter.enterView.text.length <= 0)
    {
        CommonShowTitle(@"请输入新密码");
        return;
    }
    
    NSMutableDictionary *dty = [NSMutableDictionary dictionary];
    [dty setObject:self.nameEnter.enterView.text forKey:@"phone"];
    [dty setObject:self.checkEnter.enterView.text forKey:@"sms"];
    [dty setObject:[CodeFunction MD5:self.passwordEnter.enterView.text] forKey:@"pwd"];
    
    CommonShowLoading;
    
    [self.forgetManager completion:dty result:^(HTTPDetails *result)
    {
        CommonExitLoading;
        
        if (result.success)
        {
            [CommonATManager logoutUserAccount:^{
                
                CommonShowTitle(result.message);
                [self.navigationController popToRootViewControllerAnimated:YES];
            }];
        }
        else
        {
            CommonShowTitle(result.message);
        }
    }];
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIListViewCell *myCell = [UIListViewCell cellWithTableView:tableView];
    
    myCell.accessoryView = [self.listData objectAtIndex:indexPath.row];
    
    return myCell;
}

- (ForgetManager *)forgetManager {
    
    if (!_forgetManager)
    {
        _forgetManager = [[ForgetManager alloc] init];
    }
    
    return _forgetManager;
}

@end
