//
//  ForgetController.h
//  Follow
//
//  Created by zftank on 2020/6/29.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "BaseViewController.h"

typedef NS_ENUM (NSInteger,FromType) {
    
    FromCommonType = 0,        //来自登录页面，默认值
    FromSetType = 1,           //来自设置页面
};

@interface ForgetController : BaseViewController

@property (nonatomic,assign) FromType fromType;

@end
