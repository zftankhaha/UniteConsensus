//
//  ForgetManager.m
//  Follow
//
//  Created by zftank on 2020/6/30.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "ForgetManager.h"

@implementation ForgetManager

- (void)completion:(NSDictionary *)dty result:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APIUser/recover_pwd",kConsensusHost];
    details.andBody = dty;
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

@end
