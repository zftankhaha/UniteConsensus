//
//  ForgetManager.h
//  Follow
//
//  Created by zftank on 2020/6/30.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "NSModelManager.h"

@interface ForgetManager : NSModelManager

- (void)completion:(NSDictionary *)dty result:(void(^)(HTTPDetails *result))retHandler;

@end
