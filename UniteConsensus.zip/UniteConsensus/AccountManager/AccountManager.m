//
//  AccountManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/8/13.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "AccountManager.h"

#define ATUserDetails   @"UserInfomation1.0.0"

@implementation UserDetails

- (void)resolutionDataSource:(id)dataSource {
    
    NSDictionary *user = [dataSource customForKey:@"user"];
    NSDictionary *coin = [dataSource customForKey:@"coin"];
    
    if (CheckDictionary(user))
    {
        self.realName = [[user customForKey:@"real_name_state"] description];
        self.ownActivity = [[user customForKey:@"own_activity"] description];
        self.unionActivity = [[user customForKey:@"chain_activity"] description];
        self.userLevel = [[user customForKey:@"level"] description];
        
        self.userMobile = [[user customForKey:@"phone"] description];
        self.nickName = [[user customForKey:@"nickName"] description];
        self.ownInviteCode = [[user customForKey:@"ownCode"] description];
    }
    
    if (CheckDictionary(coin))
    {
        self.btCoin = [CoinInfomation coinInfomation:CoinBTType];
        [self.btCoin refresh:[coin customForKey:@"gt"] lockNumber:[coin customForKey:@"freeze_gt"]];
        
        self.bdCoin = [CoinInfomation coinInfomation:CoinBDType];
        [self.bdCoin refresh:[coin customForKey:@"gd"] lockNumber:[coin customForKey:@"freeze_gd"]];
        
        self.absCoin = [CoinInfomation coinInfomation:CoinABSType];
        [self.absCoin refresh:[coin customForKey:@"gx"] lockNumber:[coin customForKey:@"freeze_gx"]];
        
        self.bcCoin = [CoinInfomation coinInfomation:CoinBCType];
        [self.bcCoin refresh:[coin customForKey:@"gds"] lockNumber:[coin customForKey:@"freeze_gds"]];
    }
}

@end

@interface AccountManager ()

@property (strong) UserDetails *userInfo;

@end

@implementation AccountManager

+ (AccountManager *)accountInstance {
    
    static dispatch_once_t onceToken;
    static AccountManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[AccountManager alloc] init];
        shareInstance.userInfo = [FileManager objectForKey:ATUserDetails catalogue:LogDocument];
    });
    
    return shareInstance;
}

- (void)accountInfomation:(void(^)(HTTPDetails *result))retHandler {
    
    if (!CommonATManager.checkLogin)
    {
        if (retHandler)
        {
            retHandler(nil);
        }
        
        return;
    }
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APIUser/userInfo",kConsensusHost];
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (result.success && CommonATManager.checkLogin)
        {
            NSDictionary *dty = [result.resultData customForKey:@"data"];
            NSString *currentToken = [[dty customForKey:@"user.uid"] description];
            
            if ([CommonATManager.userToken isEqualToString:currentToken])
            {
                UserDetails *userInfo = [[UserDetails alloc] init];
                [userInfo resolutionDataSource:dty];self.userInfo = userInfo;
                [FileManager setObject:self.userInfo forKey:ATUserDetails catalogue:LogDocument];
                
                if (retHandler)
                {
                    retHandler(result);
                }
            }
            else
            {
                [CommonATManager logoutUserAccount:nil];
                
                if (retHandler)
                {
                    retHandler(nil);
                }
            }
        }
        else
        {
            [self clearAccountAction];
            
            if (retHandler)
            {
                retHandler(nil);
            }
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

- (void)clearAccountAction {
    
    self.userInfo = nil;
    [CommonConnection stopDataRequest:self];
}

@end
