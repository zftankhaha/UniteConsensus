//
//  LoginViewManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/23.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "UserManager.h"

@implementation UserManager

- (void)loginAction:(NSDictionary *)dty result:(void(^)(HTTPDetails *result))retHandler {

    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APIUser/login",kConsensusHost];
    details.andBody = dty;
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (result.success)
        {
            [CommonATManager refreshUserInfomation:[result.resultData customForKey:@"data"]];
        }
        
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

@end
