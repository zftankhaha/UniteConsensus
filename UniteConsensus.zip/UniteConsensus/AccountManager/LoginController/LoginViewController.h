//
//  LoginController.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/21.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController

@end
