//
//  LoginController.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/21.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterController.h"
#import "ForgetController.h"
#import "UICommonView.h"
#import "UIListViewCell.h"
#import "UserManager.h"

@interface LoginViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *listView;
@property (nonatomic,copy) NSArray *listData;

@property (nonatomic,strong) UICommonView *phoneEnter;
@property (nonatomic,strong) UICommonView *passwordEnter;

@property (nonatomic,strong) UIButton *loginButton;
@property (nonatomic,strong) UIButton *forgetButton;
@property (nonatomic,strong) UIButton *registerButton;

@property (nonatomic,strong) UserManager *userManager;

@end

@implementation LoginViewController

- (void)dealloc {
    
    _listView.delegate = nil;
    _listView.dataSource = nil;
    
    _phoneEnter.enterView.delegate = nil;
    _passwordEnter.enterView.delegate = nil;
}

- (void)returnAction:(UIButton *)button {
    
    [super returnAction:button];
    [CommonATManager renounceAction];
}

#pragma mark -
#pragma mark ViewDidLoad

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"登录";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.listView];
    
    self.phoneEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    [self.phoneEnter refreshTitle:@"手机号" enterView:@"请输入手机号码"];
    
    self.passwordEnter = [[UICommonView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,kListCellHeight)];
    self.passwordEnter.enterView.secureTextEntry = YES;
    [self.passwordEnter refreshTitle:@"密码" enterView:@"请输入密码"];
    
    self.listData = @[self.phoneEnter,self.passwordEnter];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    [self resignCurrentResponder];
}

- (void)resignCurrentResponder {
    
    [self.phoneEnter.enterView resignFirstResponder];
    [self.passwordEnter.enterView resignFirstResponder];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-HeadBar_HEIGHT-Bottom_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kListCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        _listView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,10)];
        _listView.tableHeaderView.backgroundColor = [UIColor clearColor];
        
        //加载footerView
        UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,280)];
        footView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footView;
        
        WEAKSELF
        UIButton *returnButton = [UIButton buttonWithType:UIButtonTypeCustom];
        returnButton.frame = footView.bounds;
        returnButton.backgroundColor = [UIColor clearColor];
        [footView addSubview:returnButton];
        [returnButton actionForButton:^(UIButton *button)
        {
            [weakSelf resignCurrentResponder];
        }];
        
        //忘记密码、登录、手机注册
        self.forgetButton = [UIButton button:CGRectMake(SCREEN_WIDTH-140,0,120,65) title:@"    忘记密码"
                                  titleColor:kDefaultRedColor font:CommonFontLight(18) radius:0];
        [self.forgetButton addTarget:self action:@selector(forgetAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:self.forgetButton];
        
        self.loginButton = [UIButton button:CGRectMake(25,70,SCREEN_WIDTH-50,45) title:@"登录"
                                 titleColor:[UIColor whiteColor] font:CommonFontLight(18) radius:3];
        self.loginButton.backgroundColor = GradientColor(3,self.loginButton.size);
        [self.loginButton addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:self.loginButton];
        
        self.registerButton = [UIButton button:CGRectMake((SCREEN_WIDTH-150)/2,138,150,43) title:@"手机快速注册"
                                    titleColor:kDefaultRedColor font:CommonFontLight(18) radius:0];
        [self.registerButton addTarget:self action:@selector(registerAction:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:self.registerButton];
    }
    
    return _listView;
}

- (void)forgetAction:(UIButton *)button {
    
    ForgetController *forgetController = [[ForgetController alloc] init];
    [self.navigationController pushViewController:forgetController animated:YES];
}

- (void)registerAction:(UIButton *)button {
    
    RegisterController *registerController = [[RegisterController alloc] init];
    [self.navigationController pushViewController:registerController animated:YES];
}

- (void)loginAction:(UIButton *)button {

    if (![self.phoneEnter.enterView.text isPhoneNumber])
    {
        CommonShowTitle(@"请输入正确的手机号码");
        return;
    }
    
    if (!self.passwordEnter.enterView.text || self.passwordEnter.enterView.text.length <= 0)
    {
        CommonShowTitle(@"请输入密码");
        return;
    }
    
    NSMutableDictionary *dty = [NSMutableDictionary dictionary];
    [dty setObject:self.phoneEnter.enterView.text forKey:@"phone"];
    [dty setObject:[CodeFunction MD5:self.passwordEnter.enterView.text] forKey:@"pwd"];
    
    CommonShowLoading;
    
    [self.userManager loginAction:dty result:^(HTTPDetails *result)
    {
        CommonExitLoading;
        
        if (result.success)
        {
            if (CommonATManager.checkLogin)
            {
                [CommonATManager completionLoginAction];
            }
            else
            {
                CommonShowTitle(@"服务器被劫持啦......");
            }
        }
        else
        {
            CommonShowTitle(result.message);
        }
    }];
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIListViewCell *myCell = [UIListViewCell cellWithTableView:tableView];
    
    myCell.accessoryView = [self.listData objectAtIndex:indexPath.row];
    
    return myCell;
}

- (UserManager *)userManager {
    
    if (!_userManager)
    {
        _userManager = [[UserManager alloc] init];
    }
    
    return _userManager;
}

@end
