//
//  VersionManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/24.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "LoginCommon.h"
#import <Foundation/Foundation.h>

#define CommonVersion   [VersionManager shareVersion]

@interface VersionInfo : NSObject

@property (nonatomic,copy) NSString *serverVersion;//服务器最新版本号
@property (nonatomic,assign) BOOL isUpgrade;//是否需要升级//默认不需要

@property (nonatomic,copy) NSString *upgradeUrl;//升级地址
@property (nonatomic,copy) NSString *showTitle;//升级描述

@end

@interface VersionManager : NSObject <LoginCommon>

@property (nonatomic,strong) VersionInfo *versionInfo;

- (void)checkVersion:(BOOL)showTips result:(void(^)(HTTPDetails *result))retHandler;

@end
