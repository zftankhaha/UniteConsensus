//
//  AppDelegate.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CTTabBarController.h"

#define CommonDelegate   ((AppDelegate *)[[UIApplication sharedApplication] delegate])

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic) UIWindow *window;
@property (strong,nonatomic) CTTabBarController *rootController;

- (void)refreshTabBarController;

@end

