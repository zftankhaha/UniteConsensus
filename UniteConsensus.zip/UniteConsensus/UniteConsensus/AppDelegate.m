//
//  AppDelegate.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self refreshTabBarController];
    
    //APP启动事件//
    [self applicationLaunchOptions];
    
    return YES;
}

- (void)applicationLaunchOptions {
    
    [CommonVersion checkVersion:NO result:nil];
}

#pragma mark -
#pragma mark refreshTabBarController

- (void)refreshTabBarController {
    
    self.rootController.viewControllers = nil;
    self.rootController = [[CTTabBarController alloc] init];
    self.window.rootViewController = self.rootController;
    [self.window makeKeyAndVisible];
}

@end
