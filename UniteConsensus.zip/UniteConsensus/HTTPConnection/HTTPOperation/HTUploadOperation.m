//
//  HBUploadOperation.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/29.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "HTUploadOperation.h"

@implementation HTUploadOperation

- (void)main {
    
    @autoreleasepool
    {
        if (self.isCancelled || self.breakSession)
        {
            [self.httpTask cancel];
        }
        else
        {
            [self.httpTask resume];
        }
    }
}

- (void)createTaskWithSession:(NSURLSession *)httpSession {
    
    @autoreleasepool
    {
        NSURL *strUrl = [NSURL URLWithString:self.resultInfo.requestUrl];
        
        NSMutableURLRequest *HTTPRequest = [NSMutableURLRequest requestWithURL:strUrl];
        
        HTTPRequest.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        
        HTTPRequest.timeoutInterval = self.resultInfo.timeoutInterval;
        
        if (self.resultInfo.requestMethod == PostMethod)
        {
            HTTPRequest.HTTPMethod = kPostMethod;
        }
        else if (self.resultInfo.requestMethod == PutMethod)
        {
            HTTPRequest.HTTPMethod = kPUTMethod;
        }
        
        [self setRequestHTTPHeader:HTTPRequest];
        
        [self setRequestHTTPBody:HTTPRequest];
        
        self.httpTask = [httpSession uploadTaskWithRequest:HTTPRequest fromData:self.resultInfo.fromData
                                         completionHandler:^(NSData *data,NSURLResponse *response,NSError *error) {
        
            if (self.isCancelled || self.breakSession)
            {
                [self.httpTask cancel];
            }
            else
            {
                [self completeTask:data respone:response error:error];
            }
        }];
    }
}

- (void)completeTask:(NSData *)data respone:(NSURLResponse *)response error:(NSError *)error {
    
    if (data && !error)
    {
        self.resultInfo.requestHeader = self.httpTask.currentRequest.allHTTPHeaderFields;
        
        self.resultInfo.resultHeader = [(NSHTTPURLResponse *)response allHeaderFields];
        
        self.resultInfo.resultData = [NSJSONSerialization JSONObjectWithData:data
                                                                     options:NSJSONReadingAllowFragments
                                                                       error:nil];
        [self checkCurrentNetworkStatus:error];
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (self.manager && self.successBlock)
            {
                self.successBlock(self.resultInfo);
            }
            
            self.successBlock = nil;
            
            [self showCurrentNetworkStatus];
        });
    }
    else
    {
        self.resultInfo.requestHeader = self.httpTask.currentRequest.allHTTPHeaderFields;
        
        self.resultInfo.resultHeader = [(NSHTTPURLResponse *)response allHeaderFields];
        
        [self checkCurrentNetworkStatus:error];
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (self.manager && self.failureBlock)
            {
                self.failureBlock(self.resultInfo);
            }
            
            self.failureBlock = nil;
            
            [self showCurrentNetworkStatus];
        });
    }
    
    [self.httpTask cancel];
}

@end
