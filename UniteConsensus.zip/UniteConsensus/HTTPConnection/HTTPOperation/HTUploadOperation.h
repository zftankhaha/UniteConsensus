//
//  HBUploadOperation.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/29.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "BaseOperation.h"

@interface HTUploadOperation : BaseOperation

@end
