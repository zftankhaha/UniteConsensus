//
//  BaseOperation.h
//  GJDD
//
//  Created by zftank on 14-10-28.
//  Copyright (c) 2014年 zftank. All rights reserved.
//

#import "HTTPConnection.h"
#import "CheckPattern.h"

#define kGetMethod         @"GET"
#define kPostMethod        @"POST"
#define kPUTMethod         @"PUT"
#define kByteOfRecerver    @"countOfBytesReceived"

@interface BaseOperation : NSOperation

@property (weak) id manager;
@property (strong) HTTPDetails *resultInfo;

@property (assign) BOOL breakSession;
@property (strong) NSURLSessionTask *httpTask;

@property (copy) void(^cumulationBlock)(int64_t receive,int64_t complete,CGFloat ratio);
@property (copy) void(^successBlock)(HTTPDetails *result);
@property (copy) void(^failureBlock)(HTTPDetails *result);

+ (id)create:(id)master details:(HTTPDetails *)details
  cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
     success:(void(^)(HTTPDetails *result))success
     failure:(void(^)(HTTPDetails *result))failure;

- (void)createTaskWithSession:(NSURLSession *)httpSession;

- (void)stopOperation;
- (void)checkOperation:(id)master;
- (void)checkOperation:(id)master withCode:(id)code;

- (void)checkCurrentNetworkStatus:(NSError *)error;
- (void)showCurrentNetworkStatus;//必须在主线程调用

- (void)setRequestHTTPHeader:(NSMutableURLRequest *)HTTPRequest;
- (void)setRequestHTTPBody:(NSMutableURLRequest *)HTTPRequest;

@end
