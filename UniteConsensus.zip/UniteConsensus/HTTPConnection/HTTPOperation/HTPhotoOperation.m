//
//  HTPhotoOperation.m
//  BCExchange
//
//  Created by zftank on 2018/12/24.
//  Copyright © 2018 BCExchange. All rights reserved.
//

#import "HTPhotoOperation.h"
#import "HPCachePhotoManager.h"

@implementation HTPhotoOperation

+ (id)create:(id)master details:(HTTPDetails *)details
  cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
     success:(void(^)(HTTPDetails *result))success
     failure:(void(^)(HTTPDetails *result))failure {
    
    HTPhotoOperation *operation = [[HTPhotoOperation alloc] init];
    
    operation.breakSession = NO;
    
    operation.manager = master;
    
    operation.resultInfo = details;
    
    operation.resultInfo.timeoutInterval = 60.0f;
    
    operation.cumulationBlock = cumulation;
    
    operation.successBlock = success;
    
    operation.failureBlock = failure;
    
    if ([master respondsToSelector:@selector(setOperationItem:)])
    {
        [master setOperationItem:operation];
    }
    
    return operation;
}

- (void)dealloc {
    
    if (self.cumulationBlock)
    {
        [self.httpTask removeObserver:self forKeyPath:kByteOfRecerver];
    }
}

#pragma mark -
#pragma mark Close Methods

- (void)stopOperation {
    
    [self cancel];
    
    self.breakSession = YES;
    
    [self.httpTask cancel];
}

- (void)closeOperationAction {
    
    self.resultInfo.success = NO;
    
    [self.httpTask cancel];
}

#pragma mark -
#pragma mark Action Methods

- (void)main {
    
    @autoreleasepool
    {
        if (self.isCancelled || self.breakSession)
        {
            [self closeOperationAction];
        }
        else
        {
            [self.httpTask resume];
        }
    }
}

- (void)createTaskWithSession:(NSURLSession *)httpSession {
    
    @autoreleasepool
    {
        NSURL *imageUrl = [NSURL URLWithString:self.resultInfo.requestUrl];
        
        NSMutableURLRequest *HTTPRequest = [NSMutableURLRequest requestWithURL:imageUrl];
        
        HTTPRequest.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        
        HTTPRequest.timeoutInterval = self.resultInfo.timeoutInterval;
        
        HTTPRequest.HTTPMethod = kGetMethod;
        
        [HTTPRequest setValue:@"keep-alive" forHTTPHeaderField:@"Connection"];
        [HTTPRequest setValue:@"image/jpeg" forHTTPHeaderField:@"Content-Type"];
        [HTTPRequest setValue:@"filter-header" forHTTPHeaderField:@"filter-key"];
        
        self.httpTask = [httpSession dataTaskWithRequest:HTTPRequest
                                       completionHandler:^(NSData *data,NSURLResponse *response,NSError *error) {
                                           
            if (self.isCancelled || self.breakSession)
            {
                [self closeOperationAction];
            }
            else
            {
                [self completeTask:data respone:response error:error];
            }
        }];
        
        if (self.cumulationBlock)
        {
            [self.httpTask addObserver:self forKeyPath:kByteOfRecerver options:NSKeyValueObservingOptionNew context:NULL];
        }
    }
}

- (void)completeTask:(NSData *)data respone:(NSURLResponse *)response error:(NSError *)error {
    
    if (data && !error)
    {
        self.resultInfo.requestHeader = self.httpTask.currentRequest.allHTTPHeaderFields;
        
        self.resultInfo.resultHeader = [(NSHTTPURLResponse *)response allHeaderFields];
        
        [HPCacheImageManager checkImageType:data withInfo:self.resultInfo];
        
        if (self.resultInfo.resultData)
        {
            [HPCacheImageManager setImageForMemoryCache:self.resultInfo];
            
            [HPCacheImageManager createCache:self.resultInfo.cachePath content:data];
            
            [self completeImageSession:YES];
        }
        else
        {
            [self completeImageSession:NO];
        }
    }
    else
    {
        [self completeImageSession:NO];
    }
}

- (void)completeImageSession:(BOOL)complete {
    
    if (self.isCancelled || self.breakSession)
    {
        [self closeOperationAction];
    }
    else
    {
        if (complete)
        {
            self.resultInfo.success = YES;
            
            if (self.manager && self.successBlock)
            {
                dispatch_async(dispatch_get_main_queue(),^{
                    
                    self.successBlock(self.resultInfo);
                    
                    self.successBlock = nil;
                });
            }
        }
        else
        {
            self.resultInfo.success = NO;
            
            if (self.manager && self.failureBlock)
            {
                dispatch_async(dispatch_get_main_queue(),^{
                    
                    self.failureBlock(self.resultInfo);
                    
                    self.failureBlock = nil;
                });
            }
        }
        
        [self.httpTask cancel];
    }
}

#pragma mark -
#pragma mark KVO Methods

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
                        change:(NSDictionary *)change context:(void *)context {
    
    if (self.cumulationBlock)
    {
        dispatch_async(dispatch_get_main_queue(),^{
            
            CGFloat receive = (CGFloat)self.httpTask.countOfBytesReceived;
            
            CGFloat complete = (CGFloat)self.httpTask.countOfBytesExpectedToReceive;
            
            if (0 < complete)
            {
                CGFloat ratio = (CGFloat)(receive/complete);
                
                self.cumulationBlock(receive,complete,ratio);
            }
        });
    }
}

@end
