//
//  HTDataOperation.m
//  BCExchange
//
//  Created by zftank on 2018/12/24.
//  Copyright © 2018 BCExchange. All rights reserved.
//

#import "HTDataOperation.h"

@implementation HTDataOperation

- (void)main {
    
    @autoreleasepool
    {
        if (self.isCancelled || self.breakSession)
        {
            [self.httpTask cancel];
        }
        else
        {
            [self.httpTask resume];
        }
    }
}

- (void)createTaskWithSession:(NSURLSession *)httpSession {
    
    @autoreleasepool
    {
        NSURL *strUrl = [NSURL URLWithString:[CheckPattern URLEncode:self.resultInfo.requestUrl]];
        
        NSMutableURLRequest *HTTPRequest = [NSMutableURLRequest requestWithURL:strUrl];
        
        HTTPRequest.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        
        HTTPRequest.timeoutInterval = self.resultInfo.timeoutInterval;
        
        if (self.resultInfo.requestMethod == GetMethod)
        {
            HTTPRequest.HTTPMethod = kGetMethod;
        }
        else if (self.resultInfo.requestMethod == PostMethod)
        {
            HTTPRequest.HTTPMethod = kPostMethod;
        }
        
        [self setRequestHTTPHeader:HTTPRequest];
        
        [self setRequestHTTPBody:HTTPRequest];
        
        self.httpTask = [httpSession dataTaskWithRequest:HTTPRequest
                                       completionHandler:^(NSData *data,NSURLResponse *response,NSError *error) {
                                           
            if (self.isCancelled || self.breakSession)
            {
               [self.httpTask cancel];
            }
            else
            {
               [self completeTask:data respone:response error:error];
            }
        }];
    }
}

- (void)completeTask:(NSData *)data respone:(NSURLResponse *)response error:(NSError *)error {
    
    if (data && !error)
    {
        self.resultInfo.requestHeader = self.httpTask.currentRequest.allHTTPHeaderFields;
        self.resultInfo.resultHeader = [(NSHTTPURLResponse *)response allHeaderFields];
        
        if (self.resultInfo.analyticType == AnalyticFromJson)
        {
            self.resultInfo.resultData = [NSJSONSerialization JSONObjectWithData:data
                                                                     options:NSJSONReadingAllowFragments
                                                                       error:nil];
        }
        else
        {
            self.resultInfo.resultData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        }
        
        [self checkCurrentNetworkStatus:error];
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (self.manager && self.successBlock)
            {
                self.successBlock(self.resultInfo);
            }
            
            self.successBlock = nil;
            
            [self showCurrentNetworkStatus];
        });
    }
    else
    {
        self.resultInfo.requestHeader = self.httpTask.currentRequest.allHTTPHeaderFields;
        self.resultInfo.resultHeader = [(NSHTTPURLResponse *)response allHeaderFields];
        [self checkCurrentNetworkStatus:error];
        
        dispatch_async(dispatch_get_main_queue(),^{
            
            if (self.manager && self.failureBlock)
            {
                self.failureBlock(self.resultInfo);
            }
            
            self.failureBlock = nil;
            
            [self showCurrentNetworkStatus];
        });
    }
    
    [self.httpTask cancel];
}

@end
