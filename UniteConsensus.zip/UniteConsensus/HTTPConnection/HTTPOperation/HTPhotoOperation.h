//
//  HTPhotoOperation.h
//  BCExchange
//
//  Created by zftank on 2018/12/24.
//  Copyright © 2018 BCExchange. All rights reserved.
//

#import "BaseOperation.h"

@interface HTPhotoOperation : BaseOperation

@end
