//
//  UIImage+ForceDecode.h
//  SoYoungMobile40
//
//  Created by zftank on 2018/1/12.
//  Copyright © 2018年 soyoung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ForceDecode)

+ (UIImage *)decodedImageWithImage:(UIImage *)image;

@end
