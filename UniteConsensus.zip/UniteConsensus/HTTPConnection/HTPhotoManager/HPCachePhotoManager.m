//
//  HPCachePhotoManager.m
//  SoYoungMobile40
//
//  Created by zftank on 2018/1/12.
//  Copyright © 2018年 soyoung. All rights reserved.
//

#import "HPCachePhotoManager.h"
#import "FilePhotoManager.h"
#import <ImageIO/ImageIO.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "NSData+UIImageType.h"
#import "FLAnimatedImage.h"
#import "UIImage+ForceDecode.h"

#define kCountLimit    50

@interface HPCachePhotoManager ()

@property (strong) NSCache *cacheOfImage;

@property (strong) NSOperationQueue *IOImageQueue;

@end

@implementation HPCachePhotoManager

+ (HPCachePhotoManager *)shareImageInstance {
    
    static dispatch_once_t onceToken;
    
    static HPCachePhotoManager *shareInstance = nil;
    
    dispatch_once(&onceToken,^{
        
        shareInstance = [[HPCachePhotoManager alloc] init];
        shareInstance.IOImageQueue = [[NSOperationQueue alloc] init];
        shareInstance.IOImageQueue.maxConcurrentOperationCount = 1;
    });
    
    return shareInstance;
}

- (void)createCacheOfPhoto {
    
    //创建硬盘缓存
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    
    NSString *folderPath = [FilePhotoManager getImageFolderOfCache];
    
    if ([fileManager fileExistsAtPath:folderPath])
    {
        //大于8000张图片删除文件夹
        NSDirectoryEnumerator *fileEnumerator = [fileManager enumeratorAtPath:folderPath];
        
        NSUInteger cacheCount = fileEnumerator.allObjects.count;
        
        if (8000 < cacheCount)
        {
            [fileManager removeItemAtPath:folderPath error:NULL];
            [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:NULL];
        }
    }
    else
    {
        [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    
    //创建内存缓存，GIF图不缓存
    self.cacheOfImage = [[NSCache alloc] init];
    self.cacheOfImage.countLimit = kCountLimit;

    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidReceiveMemoryWarningNotification
                                                      object:nil queue:[NSOperationQueue currentQueue]
                                                  usingBlock:^(NSNotification *note) {
        [self.cacheOfImage removeAllObjects];
    }];
}

#pragma mark -
#pragma mark 检查图片缓存

- (void)checkCache:(id)master details:(HTTPDetails *)details
        cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
        completion:(void(^)(BOOL cacheImage))completion {
    
    if (completion)
    {
        completion([self checkCacheOfPhoto:details]);
    }
}

- (BOOL)checkCacheOfPhoto:(HTTPDetails *)details {
    
    //检查内存
    [details setValue:[FilePhotoManager cacheImageName:details.requestUrl] forKey:@"cacheName"];
    
    details.resultData = [self.cacheOfImage objectForKey:details.cacheName];

    if (details.resultData)
    {
        [details setValue:[NSNumber numberWithInteger:FromCacheType] forKey:@"fromType"];
        [details setValue:[NSNumber numberWithInteger:UIImagePNGType] forKey:@"CGImageType"];

        return YES;
    }
    
    //检查硬盘
    [details setValue:[FilePhotoManager cacheImageStoragePath:details.cacheName] forKey:@"cachePath"];
    
    NSFileManager *fileManager = [[NSFileManager alloc] init];

    NSData *dataImage = [fileManager contentsAtPath:details.cachePath];
    
    [self checkImageType:dataImage withInfo:details];
    
    if (details.resultData)
    {
        [self setImageForMemoryCache:details];
        
        [details setValue:[NSNumber numberWithInteger:FromDiskType] forKey:@"fromType"];
        
        return YES;
    }
    else
    {
        [details setValue:[NSNumber numberWithInteger:FromServerType] forKey:@"fromType"];
        
        return NO;
    }
}

#pragma mark -
#pragma mark 判断、解析图片类型

- (void)checkImageType:(NSData *)data withInfo:(HTTPDetails *)details {
    
    if (!data)
    {
        details.resultData = nil;
        
        [details setValue:[NSNumber numberWithInteger:UIImageNoneType] forKey:@"CGImageType"];
        
        return;
    }
    
    //判断图片类型
    UIImageType CGImageType = [NSData checkImageTypeFromData:data];
    
    if (CGImageType == UIImageGIFType)
    {
        FLAnimatedImage *FLImage = [FLAnimatedImage animatedImageWithGIFData:data];
        
        if (details.showPosterImageForGIF)
        {
            details.resultData = [FLImage posterImage];
        }
        else
        {
            details.resultData = FLImage;
        }
        
        [details setValue:[NSNumber numberWithInteger:UIImageGIFType] forKey:@"CGImageType"];
    }
    else
    {
        details.resultData = [[UIImage alloc] initWithData:data];
        
        [details setValue:[NSNumber numberWithInteger:UIImagePNGType] forKey:@"CGImageType"];
    }
    
    if (!details.resultData)
    {
        [details setValue:[NSNumber numberWithInteger:UIImageNoneType] forKey:@"CGImageType"];
    }
}

- (void)decodeImageFromImage:(HTTPDetails *)details {
    
    //图片解压缩
    if (details.CGImageType == UIImagePNGType)
    {
        UIImage *resultImage = details.resultData;

        details.resultData = [UIImage decodedImageWithImage:resultImage];
    }
}

#pragma mark -
#pragma mark 缓存图片

- (void)setImageForMemoryCache:(HTTPDetails *)details {
    
    if (details.CGImageType == UIImagePNGType)
    {
        if (details.resultData && details.cacheName)
        {
            [self.cacheOfImage setObject:details.resultData forKey:details.cacheName];
        }
    }
}

- (BOOL)createCache:(NSString *)filePath content:(NSData *)content {
    
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    
    NSString *folderPath = [FilePhotoManager getImageFolderOfCache];
    
    if ([fileManager fileExistsAtPath:folderPath] == NO)
    {
        [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    
    return [fileManager createFileAtPath:filePath contents:content attributes:nil];
}

#pragma mark -
#pragma mark 计算图片缓存

- (void)clearDiskCacheCompletion:(void(^)(BOOL complete))resultBlock {
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{
        
        NSFileManager *fileManager = [[NSFileManager alloc] init];
        
        NSString *folderPath = [FilePhotoManager getImageFolderOfCache];
        
        BOOL complete = [fileManager removeItemAtPath:folderPath error:NULL];
        
        [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:NULL];
        
        if (resultBlock)
        {
            dispatch_async(dispatch_get_main_queue(),^{
                
                resultBlock(complete);
            });
        }
    });
}

- (void)calculationDiskCacheCompletion:(void(^)(unsigned long long complete))resultBlock {
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{
        
        unsigned long long size = [FilePhotoManager calculationDiskCacheForImage];
        
        if (resultBlock)
        {
            dispatch_async(dispatch_get_main_queue(),^{
                
                resultBlock(size);
            });
        }
    });
}

@end
