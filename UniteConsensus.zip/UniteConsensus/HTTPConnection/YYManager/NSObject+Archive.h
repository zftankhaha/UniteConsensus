//
//  NSObject+Archive.h
//  HBFinance
//
//  Created by zftank on 16/9/21.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+SafeSelection.h"
#import "YYModel.h"

@interface NSObject (Archive)

@end
