//
//  HTTPDetails.m
//  JiuTianWaiApp
//
//  Created by zhangfeng on 13-6-21.
//  Copyright (c) 2013年 MasterPlate. All rights reserved.
//

#import "HTTPDetails.h"
#import "CheckPattern.h"

@implementation HTTPDetails

- (instancetype)init {

    self = [super init];
    
    if (self)
    {
        _requestUrl = nil;
        _requestKey = nil;
        
        _requestMethod = PostMethod;
        _timeoutInterval = 30.0f;
        _analyticType = AnalyticFromJson;
        
        _requestHeader = nil;
        [self refreshCommonHeader];
        
        _hashBody = nil;
        _listBody = nil;
        _andBody = nil;
        _stringBody = nil;
        _customData = nil;
        
        _fromData = nil;
        
        _siteImage = nil;
        _errorImage = nil;
        
        _radiusOfRectangle = 0.0f;
        _runLoopMode = NSDefaultRunLoopMode;
        
        _showPosterImageForGIF = NO;
        _childThreadCheckCache = NO;
        
        _contentMode = UIViewContentModeScaleAspectFit;
        _defaultMode = UIViewContentModeScaleAspectFit;
        
        _CGImageType = UIImageNoneType;
        
        _animationType = UIAnimationNone;
        _fromType = FromServerType;
        
        _cacheName = nil;
        _cachePath = nil;
        
        _success = YES;
        _httpState = HTTPNetworkNormal;
        _message = @"";
        
        _resultHeader = nil;
        _resultData = nil;
    }
    
    return self;
}

- (void)refreshCommonHeader {
    
    NSMutableDictionary *shareHeader = [[NSMutableDictionary alloc] init];
    
    [shareHeader setObject:@"IOS" forKey:@"platform"];
    
    if (CommonATManager.checkLogin)
    {
        [shareHeader setObject:CommonATManager.userToken forKey:@"uid"];
    }
    
    self.commonHeader = shareHeader;
}

@end
