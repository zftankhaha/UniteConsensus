//
//  NSDictionary+Resolve.h
//  WYTourism
//
//  Created by aoyipower on 14/11/23.
//  Copyright (c) 2014年 WYTourism. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Resolve)

- (id)customForKey:(id)aKey;
- (id)safeObjectForKey:(id)aKey;

@end
