//
//  NSArray+SafeAccess.h
//  51TalkTeacher
//
//  Created by zftank on 2017/12/19.
//  Copyright © 2017年 51TalkTeacher. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (SafeAccess)

@end
