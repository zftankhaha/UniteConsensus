//
//  NSCrashFromMethod.m
//  51TalkTeacher
//
//  Created by zftank on 2017/12/19.
//  Copyright © 2017年 51TalkTeacher. All rights reserved.
//

#import "NSCrashFromMethod.h"

@implementation NSCrashFromMethod

- (void)dealloc {
    
    _claseName = nil;
    _methodName = nil;
}

- (void)replaceMethod {
    
    NSString *message = [NSString stringWithFormat:@"%@ 异常调用",self.methodName];
    
    [NSCrashFromMethod showMessage:self.claseName crashMessage:message];
}

+ (void)showCrashMessage:(NSString *)cName crashMethod:(NSString *)mName {
    
    [NSCrashFromMethod showMessage:cName crashMessage:mName];
}

+ (void)showMessage:(NSString *)className crashMessage:(NSString *)message {
    
#if DEBUG || SANDBOX
    
    NSArray *callArray = [NSThread callStackSymbols];

    NSArray *stackArray = [NSThread callStackReturnAddresses];
    
    NSLog(@"%@",callArray);
    
    NSLog(@"%@",stackArray);
    
    dispatch_async(dispatch_get_main_queue(),^{
        
        [UCAlertManager show:className message:message cancel:@"确定" sure:nil click:nil];
    });
    
#endif

}

@end
