//
//  DownloadManager.h
//  HBFinance
//
//  Created by zftank on 16/9/27.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "HTTPManager.h"
#import "DownloadOperation.h"

@interface DownloadManager : HTTPManager

#pragma mark -
#pragma mark 创建管理器

+ (DownloadManager *)createDownloadManager;

#pragma mark -
#pragma mark 加载网络任务

- (void)createTask:(id)master details:(HTTPDetails *)details
        cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
           success:(void(^)(HTTPDetails *result))success
           failure:(void(^)(HTTPDetails *result))failure;

@end
