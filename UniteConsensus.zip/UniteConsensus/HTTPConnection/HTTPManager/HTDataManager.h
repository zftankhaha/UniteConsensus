//
//  HBSessionManager.h
//  HBFinance
//
//  Created by zftank on 16/9/17.
//  Copyright © 2016年 zftank. All rights reserved.
//

#import "HTTPManager.h"
#import "HTDataOperation.h"

@interface HTDataManager : HTTPManager

#pragma mark -
#pragma mark 创建管理器

+ (HTDataManager *)createDataManager;

#pragma mark -
#pragma mark 加载网络任务

- (void)createTask:(id)master details:(HTTPDetails *)details
        cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
           success:(void(^)(HTTPDetails *result))success
           failure:(void(^)(HTTPDetails *result))failure;

#pragma mark -
#pragma mark 关闭网络任务

- (void)stopDataRequest:(id)manager;

- (void)stopDataRequest:(id)manager withKey:(NSString *)key;

- (void)closeCompleteRequest;

@end
