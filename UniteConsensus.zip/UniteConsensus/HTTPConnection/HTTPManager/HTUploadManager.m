//
//  HBUploadManager.m
//  HBankXLoan
//
//  Created by zftank on 2016/10/29.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "HTUploadManager.h"
#import "HTUploadOperation.h"

@implementation HTUploadManager

#pragma mark -
#pragma mark 创建管理器

+ (HTUploadManager *)createUploadManager {

    HTUploadManager *manager = [[HTUploadManager alloc] init];
    
    //创建并行队列
    manager.taskQueue = [[NSOperationQueue alloc] init];
    manager.taskQueue.maxConcurrentOperationCount = 3;
    
    //创建NSURLSession
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    configuration.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    configuration.URLCache = nil;configuration.HTTPCookieStorage = nil;
    
    manager.httpSession = [NSURLSession sessionWithConfiguration:configuration
                                                        delegate:manager delegateQueue:manager.taskQueue];
    
    return manager;
}

#pragma mark -
#pragma mark 加载网络任务

- (void)createTask:(id)master details:(HTTPDetails *)details
        cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
           success:(void(^)(HTTPDetails *result))success
           failure:(void(^)(HTTPDetails *result))failure {
    
    HTUploadOperation *upload = [HTUploadOperation create:master details:details
                                               cumulation:cumulation success:success failure:failure];
    
    [upload createTaskWithSession:self.httpSession];[self.taskQueue addOperation:upload];
}

#pragma mark -
#pragma mark 关闭网络任务

- (void)stopUploadData:(id)manager {
    
    if (manager)
    {
        NSArray *commons = self.taskQueue.operations;
        
        for (id commonTask in commons)
        {
            if ([commonTask respondsToSelector:@selector(checkOperation:)])
            {
                [commonTask checkOperation:manager];
            }
        }
    }
}

@end
