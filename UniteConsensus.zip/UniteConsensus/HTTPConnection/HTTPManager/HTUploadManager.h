//
//  HBUploadManager.h
//  HBankXLoan
//
//  Created by zftank on 2016/10/29.
//  Copyright © 2016年 HBankXLoan. All rights reserved.
//

#import "HTTPManager.h"
#import "HTTPDetails.h"

@interface HTUploadManager : HTTPManager

#pragma mark -
#pragma mark 创建管理器

+ (HTUploadManager *)createUploadManager;

#pragma mark -
#pragma mark 加载网络任务

- (void)createTask:(id)master details:(HTTPDetails *)details
        cumulation:(void(^)(int64_t receive,int64_t complete,CGFloat ratio))cumulation
           success:(void(^)(HTTPDetails *result))success
           failure:(void(^)(HTTPDetails *result))failure;

#pragma mark -
#pragma mark 关闭网络任务

- (void)stopUploadData:(id)manager;

@end
