//
//  NSModelManager.h
//  51TalkTeacher
//
//  Created by zftank on 2017/11/16.
//  Copyright © 2017年 51TalkTeacher. All rights reserved.
//

#import "YYModel.h"
#import <Foundation/Foundation.h>
#import "NSObject+Archive.h"
#import "HTTPDetails.h"

@interface NSModelManager : NSObject

//********
 
//管理网络请求
 
//管理Model数据
 
//禁止Manager之间互相调用
 
//********

@end
