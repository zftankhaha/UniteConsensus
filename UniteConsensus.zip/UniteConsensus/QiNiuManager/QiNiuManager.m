//
//  QiNiuManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/11/15.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "QiNiuManager.h"
#import <QiniuSDK.h>

@implementation QiNiuManager

- (void)startUploadImage:(NSString *)filePath result:(void(^)(NSString *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.SMSQiniu/token"];
    details.analyticType = AnalyticFromSting;
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        if (CheckString(result.resultData))
        {
            [self uploadImageResult:result.resultData filePath:filePath];
        }
    }
    failure:^(HTTPDetails *result)
    {
        
    }];
}

- (void)uploadImageResult:(NSString *)token filePath:(NSString *)filePath {

    QNConfiguration *config = [QNConfiguration build:^(QNConfigurationBuilder *builder){builder.useHttps = YES;}];
    QNUploadManager *upManager = [[QNUploadManager alloc] initWithConfiguration:config];
    
    [upManager putFile:filePath key:nil token:token complete:^(QNResponseInfo *info, NSString *key, NSDictionary *resp)
    {
        if(info.ok)
        {
            NSLog(@"请求成功");
            CommonShowTitle(@"sdfsdf");
        }
        else
        {
            NSLog(@"失败");
            //如果失败，这里可以把info信息上报自己的服务器，便于后面分析上传错误原因
            
            CommonShowTitle(@"123123");
        }
    }
    option:nil];
}

@end
