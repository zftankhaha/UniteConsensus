//
//  QiNiuManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/11/15.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QiNiuManager : NSObject

- (void)startUploadImage:(NSString *)filePath result:(void(^)(NSString *result))retHandler;

@end
