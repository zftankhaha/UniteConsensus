//
//  ShowCoinView.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/7.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowCoinView : UIView

@property (nonatomic,strong) UILabel *lbTitle;

@property (nonatomic,strong) UILabel *lbContent;

@property (nonatomic,strong) UIButton *actionButton;

- (instancetype)initFrame:(CGRect)frame order:(BOOL)order;

@end
