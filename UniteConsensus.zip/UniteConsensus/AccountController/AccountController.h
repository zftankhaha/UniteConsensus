//
//  AccountController.h
//  Follow
//
//  Created by zftank on 2020/7/3.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "BaseViewController.h"

@interface AccountController : BaseViewController

@end
