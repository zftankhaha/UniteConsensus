//
//  UIAccountCell.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/5.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "AccountCell.h"

@implementation AccountCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        [self bottomLineX:0 width:SCREEN_WIDTH color:nil];
        
        _showView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,75,kAccountCellHeight)];
        _showView.backgroundColor = [UIColor clearColor];
        _showView.contentMode = UIViewContentModeCenter;
        [self.contentView addSubview:_showView];
        
        _showTitle = [[UILabel alloc] initWithFrame:CGRectMake(_showView.right-11,0,110,kAccountCellHeight)];
        _showTitle.backgroundColor = [UIColor clearColor];
        _showTitle.font = CommonFontLight(18);
        _showTitle.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_showTitle];
        
        [self arrowImageView:kAccountCellHeight];
    }
    
    return self;
}

@end
