//
//  UIAccountCell.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/5.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kAccountCellHeight    60

@interface AccountCell : UITableViewCell

@property (nonatomic,strong) UIImageView *showView;

@property (nonatomic,strong) UILabel *showTitle;

@end
