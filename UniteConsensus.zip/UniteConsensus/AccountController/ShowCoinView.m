//
//  ShowCoinView.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/7.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "ShowCoinView.h"

@implementation ShowCoinView

- (instancetype)initFrame:(CGRect)frame order:(BOOL)order {
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.layer.cornerRadius = 3;
        self.layer.masksToBounds = YES;
        self.backgroundColor = order?GradientColor(1,self.size):GradientColor(0,self.size);
        
        _lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(10,0,50,self.height)];
        _lbTitle.backgroundColor = [UIColor clearColor];
        _lbTitle.font = CommonFontRegular(17.0f);
        _lbTitle.textAlignment = NSTextAlignmentCenter;
        _lbTitle.textColor = [UIColor whiteColor];
        [self addSubview:_lbTitle];
        
        UIView *line = [UIView drawVTLine:CGRectMake(_lbTitle.right,15,1,self.height-29) color:[UIColor whiteColor]];
        [self addSubview:line];
        
        _lbContent = [[UILabel alloc] initWithFrame:CGRectMake(_lbTitle.right+13,0,self.width-20-50-13,self.height)];
        _lbContent.backgroundColor = [UIColor clearColor];
        _lbContent.font = CommonFontRegular(18.0f);
        _lbContent.textAlignment = NSTextAlignmentLeft;
        _lbContent.textColor = [UIColor whiteColor];
        [self addSubview:_lbContent];
        
        _actionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _actionButton.frame = self.bounds;
        _actionButton.backgroundColor = [UIColor clearColor];
        [self addSubview:_actionButton];
    }
    
    return self;
}

@end
