//
//  AccountController.m
//  Follow
//
//  Created by zftank on 2020/7/3.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "AccountController.h"
#import "AccountCell.h"
#import "ShowCoinView.h"
#import "CoinViewController.h"
#import "ShowViewController.h"
#import "FriendsController.h"
#import "OrderViewController.h"
#import "UnionViewController.h"
#import "SetViewController.h"

@interface AccountController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,copy) NSArray *listIcon;
@property (nonatomic,copy) NSArray *listTitle;
@property (nonatomic,copy) NSArray *listClass;

@property (nonatomic,strong) UITableView *listView;

@property (nonatomic,strong) UIButton *nickButton;
@property (nonatomic,strong) UILabel *showActivity;

@property (nonatomic,strong) ShowCoinView *ACoinView;
@property (nonatomic,strong) ShowCoinView *BCoinView;
@property (nonatomic,strong) ShowCoinView *CCoinView;
@property (nonatomic,strong) ShowCoinView *DCoinView;

@end

@implementation AccountController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = APP_BUNDLE_NAME;
    
    NSMutableArray *listImage = [NSMutableArray array];
    [listImage addObject:[UIImage imageNamed:@"checkcc"]];
    [listImage addObject:[UIImage imageNamed:@"ucshare"]];
    [listImage addObject:[UIImage imageNamed:@"listorder"]];
    [listImage addObject:[UIImage imageNamed:@"acmeng"]];
    [listImage addObject:[UIImage imageNamed:@"shezhi"]];
    self.listIcon = listImage;
    self.listTitle = @[@"认证中心",@"邀请好友",@"我的订单",@"我的联盟",@"设置"];
    
    NSMutableArray *listFrom = [NSMutableArray array];
    [listFrom addObject:@"ShowViewController"];
    [listFrom addObject:@"FriendsController"];
    [listFrom addObject:@"OrderViewController"];
    [listFrom addObject:@"UnionViewController"];
    [listFrom addObject:@"SetViewController"];
    self.listClass = listFrom;
    
    [self.view addSubview:self.listView];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self refreshAccountView];
    [self refreshDataSource:YES];
}

- (void)refreshDataSource:(BOOL)refreshDrop {
    
    if (CommonATManager.checkLogin)
    {
        [CommonUserManager accountInfomation:^(HTTPDetails *result)
        {
            [self.listView completeLoading:NO];

            if (result.success)
            {
                [self refreshAccountView];
            }
            else
            {
                CommonShowTitle(result.message);
            }
        }];
    }
}

- (void)refreshAccountView {
    
    if (CommonATManager.checkLogin)
    {
        [self.listView refresh:self header:YES footer:NO];
        [self.nickButton setTitle:[CommonUserDetails.nickName uppercaseString] forState:UIControlStateNormal];
        self.showActivity.text = CommonUserDetails.ownActivity;
        
        self.ACoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.btCoin.coinNumber.floatValue];
        self.BCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.bdCoin.coinNumber.floatValue];
        self.CCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.absCoin.coinNumber.floatValue];
        self.DCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.bcCoin.coinNumber.floatValue];
    }
    else
    {
        [self.listView closeDragRefresh];
        [self.nickButton setTitle:@"登录/注册" forState:UIControlStateNormal];
        self.showActivity.text = @"0";
        
        self.ACoinView.lbContent.text = @"0.00";
        self.BCoinView.lbContent.text = @"0.00";
        self.CCoinView.lbContent.text = @"0.00";
        self.DCoinView.lbContent.text = @"0.00";
    }
}

#pragma mark -
#pragma mark UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listTitle.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    AccountCell *myCell = [AccountCell cellWithTableView:tableView];
    myCell.showView.image = [self.listIcon objectAtIndex:indexPath.row];
    myCell.showTitle.text = [self.listTitle objectAtIndex:indexPath.row];
    return myCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (4 == indexPath.row)
    {
        SetViewController *setController = [[SetViewController alloc] init];
        [self.navigationController pushViewController:setController animated:YES];
    }
    else
    {
        [CommonATManager loginUserAccount:^(BOOL completion)
        {
            if (completion)
            {
                Class class = NSClassFromString(self.listClass[indexPath.row]);
                BaseViewController *controller = (BaseViewController *)[[class alloc] init];
                [self.navigationController pushViewController:controller animated:YES];
            }
        }];
    }
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,HeadBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-TabBar_HEIGHT-HeadBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kAccountCellHeight;
        
        //添加headerView
        _listView.tableHeaderView = [UIHeaderView createHeaderView:CGRectMake(0,0,SCREEN_WIDTH,218)];
        
        UIImage *image = [UIImage imageNamed:@"acMiner"];
        UIImageView *iconView = [[UIImageView alloc] initWithImage:image];
        iconView.frame = CGRectMake(13,1,70,70);
        iconView.contentMode = UIViewContentModeCenter;
        iconView.backgroundColor = [UIColor clearColor];
        [_listView.tableHeaderView addSubview:iconView];
        
        _nickButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _nickButton.frame = CGRectMake(iconView.right+6,12,120,kAccountCellHeight-8);
        _nickButton.backgroundColor = [UIColor clearColor];
        _nickButton.titleLabel.font = CommonFontRegular(18.5);
        [_nickButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_nickButton actionForButton:^(UIButton *button){[CommonATManager loginUserAccount:nil];}];
        _nickButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_listView.tableHeaderView addSubview:_nickButton];
        
        
        self.showActivity = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-20-110,8,110,25)];
        self.showActivity.backgroundColor = [UIColor clearColor];
        self.showActivity.font = CommonFontLight(18.5f);
        self.showActivity.textAlignment = NSTextAlignmentCenter;
        self.showActivity.textColor = kDefaultRedColor;
        [_listView.tableHeaderView addSubview:self.showActivity];
        
        UILabel *lbat = [[UILabel alloc] initWithFrame:CGRectMake(self.showActivity.left,self.showActivity.bottom,110,25)];
        lbat.backgroundColor = [UIColor clearColor];
        lbat.font = CommonFontLight(17.0f);
        lbat.textAlignment = NSTextAlignmentCenter;
        lbat.textColor = [UIColor blackColor];
        lbat.text = @"活跃度";
        [_listView.tableHeaderView addSubview:lbat];
        
        
        CGFloat height = 45;
        CGFloat width = (SCREEN_WIDTH-20-20-20)/2;
        
        CGRect aframe = CGRectMake(20,_nickButton.bottom+12,width,height);
        self.ACoinView = [[ShowCoinView alloc] initFrame:aframe order:YES];
        self.ACoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.btCoin.coinNumber.floatValue];
        self.ACoinView.actionButton.tag = 0;
        self.ACoinView.lbTitle.text = [[CoinInfomation coinInfomation:self.ACoinView.actionButton.tag] showTitle];
        [self.ACoinView.actionButton addTarget:self action:@selector(coinInfomation:) forControlEvents:UIControlEventTouchUpInside];
        [_listView.tableHeaderView addSubview:self.ACoinView];
        
        CGRect bframe = CGRectMake(self.ACoinView.right+20,self.ACoinView.top,width,height);
        self.BCoinView = [[ShowCoinView alloc] initFrame:bframe order:NO];
        self.BCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.bdCoin.coinNumber.floatValue];
        self.BCoinView.actionButton.tag = 1;
        self.BCoinView.lbTitle.text = [[CoinInfomation coinInfomation:self.BCoinView.actionButton.tag] showTitle];
        [self.BCoinView.actionButton addTarget:self action:@selector(coinInfomation:) forControlEvents:UIControlEventTouchUpInside];
        [_listView.tableHeaderView addSubview:self.BCoinView];
        
        
        CGRect cframe = CGRectMake(20,self.ACoinView.bottom+21,width,height);
        self.CCoinView = [[ShowCoinView alloc] initFrame:cframe order:YES];
        self.CCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.absCoin.coinNumber.floatValue];
        self.CCoinView.actionButton.tag = 2;
        self.CCoinView.lbTitle.text = [[CoinInfomation coinInfomation:self.CCoinView.actionButton.tag] showTitle];
        [self.CCoinView.actionButton addTarget:self action:@selector(coinInfomation:) forControlEvents:UIControlEventTouchUpInside];
        [_listView.tableHeaderView addSubview:self.CCoinView];
        
        
        CGRect dframe = CGRectMake(self.CCoinView.right+20,self.CCoinView.top,width,height);
        self.DCoinView = [[ShowCoinView alloc] initFrame:dframe order:NO];
        self.DCoinView.lbContent.text = [NSString stringWithFormat:@"%0.2f",CommonUserDetails.bcCoin.coinNumber.floatValue];
        self.DCoinView.actionButton.tag = 3;
        self.DCoinView.lbTitle.text = [[CoinInfomation coinInfomation:self.DCoinView.actionButton.tag] showTitle];
        [self.DCoinView.actionButton addTarget:self action:@selector(coinInfomation:) forControlEvents:UIControlEventTouchUpInside];
        [_listView.tableHeaderView addSubview:self.DCoinView];
        
        
        //添加footerView
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,SCREEN_WIDTH,30)];
        footerView.backgroundColor = [UIColor clearColor];
        _listView.tableFooterView = footerView;
    }
    
    return _listView;
}

- (void)coinInfomation:(UIButton *)button {
    
    [CommonATManager loginUserAccount:^(BOOL completion)
    {
        if (completion)
        {
            CoinViewController *coinController = [[CoinViewController alloc] initWithCoinType:button.tag];
            [self.navigationController pushViewController:coinController animated:YES];
        }
    }];
}

@end
