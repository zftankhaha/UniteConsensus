//
//  AboutViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/17.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"

@interface UnionViewController : BaseViewController

@end
