//
//  AboutViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/17.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "UnionViewController.h"

@interface UnionViewController ()

@end

@implementation UnionViewController

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.showTitle = @"我的联盟";
}

@end
