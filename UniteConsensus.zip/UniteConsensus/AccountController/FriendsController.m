//
//  FriendsViewController.m
//  Follow
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "FriendsController.h"

@interface FriendsController ()

@end

@implementation FriendsController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showTitle = @"邀请好友";
}

@end
