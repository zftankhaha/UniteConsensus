//
//  UIAnnularView.h
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UIAnnularViewDelegate <NSObject>

- (void)completionAnnularAnimation;

@end

@interface UIAnnularView : UIView

@property (nonatomic,weak) id delegate;

- (void)startAnnularAnimation:(NSNumber *)duration;

- (void)closeAnnularAnimation;

+ (NSNumber *)currentCount;

@end
