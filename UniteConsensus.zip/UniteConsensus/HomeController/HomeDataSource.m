//
//  HomeDataSource.m
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "HomeDataSource.h"

@implementation HomeDataSource

- (void)resolutionHomeDataSource:(id)dataSource {
    
    self.newsTitle = [dataSource customForKey:@"title"];
    
    self.newsImage1 = [dataSource customForKey:@"thumbnail_pic_s0"];
    
    self.newsImage2 = [dataSource customForKey:@"thumbnail_pic_s1"];
    
    self.newsImage3 = [dataSource customForKey:@"thumbnail_pic_s2"];
    
    self.detailsUrl = [dataSource customForKey:@"content"];
}

@end
