//
//  HomeManager.h
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HomeDataSource.h"

@interface HomeManager : NSObject

@property (nonatomic,copy) NSArray *listBanner;

@property (nonatomic,copy) NSArray *listContent;

- (void)requstInfomation:(void(^)(HTTPDetails *result))retHandler;

@end
