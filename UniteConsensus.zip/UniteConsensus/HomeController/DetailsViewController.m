//
//  DetailsViewController.m
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "DetailsViewController.h"
#import "UIAnnularView.h"
#import "DetailsManager.h"

@interface DetailsViewController ()

@property (nonatomic,strong) UIAnnularView *annularView;

@property (nonatomic,strong) DetailsManager *detailsManager;

@end

@implementation DetailsViewController

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.webTitle = @"详情";
    [self setCommonWebView:@"https://www.baidu.com"];
    
    if (CommonATManager.checkLogin)
    {
        [self.view addSubview:self.annularView];
        [self.annularView startAnnularAnimation:[UIAnnularView currentCount]];
        
        [CommonNotification addObserver:self selector:@selector(backgroundAction)
                                   name:UIApplicationDidEnterBackgroundNotification object:nil];
        
        [CommonNotification addObserver:self selector:@selector(foregroundAction)
                                   name:UIApplicationWillEnterForegroundNotification object:nil];
    }
}

- (void)backgroundAction {
    
    [self.annularView closeAnnularAnimation];
    [self.annularView removeFromSuperview];
    self.annularView = nil;
}

- (void)foregroundAction {

    NSNumber *number = [UIAnnularView currentCount];
    
    if (0 < number.integerValue)
    {
        [self.view addSubview:self.annularView];
        [self.annularView startAnnularAnimation:number];
    }
}

- (UIAnnularView *)annularView {
    
    if (!_annularView)
    {
        _annularView = [[UIAnnularView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-80,80,60,60)];
        _annularView.backgroundColor = [UIColor clearColor];
        _annularView.delegate = self;
    }
    
    return _annularView;
}

- (void)completionAnnularAnimation {
    
    CommonShowLoading;
    
    [self.detailsManager requstInfomation:^(HTTPDetails *result)
    {
        CommonExitLoading;
        
        if (result.success)
        {
            CommonShowTitle(result.message);
        }
        else
        {
            CommonShowTitle(@"失败啦，囧，请重新阅读");
        }
    }];
}

- (DetailsManager *)detailsManager {
    
    if (!_detailsManager)
    {
        _detailsManager = [[DetailsManager alloc] init];
    }
    
    return _detailsManager;
}

@end
