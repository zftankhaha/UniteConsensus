//
//  DetailsViewController.h
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "UIWebController.h"

@interface DetailsViewController : UIWebController

@end
