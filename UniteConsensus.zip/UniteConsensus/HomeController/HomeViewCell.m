//
//  HomeViewCell.m
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "HomeViewCell.h"

@implementation HomeViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self topLineX:0 width:SCREEN_WIDTH color:nil];
        
        _showView = [[UIImageView alloc] initWithFrame:CGRectMake(8,5,100,80)];
        _showView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_showView];
        
        _showTitle = [UILabel createFrame:CGRectMake(116,5,SCREEN_WIDTH-124,80) title:nil titleColor:nil font:CommonFontLight(15)];
        _showTitle.numberOfLines = 0;
        _showTitle.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_showTitle];
    }
    
    return self;
}

- (void)refreshViewSource:(HomeDataSource *)dataSource {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = dataSource.newsImage1;
    [self.showView setImage:details cumulation:nil success:nil failure:nil];
    
    self.showTitle.text = dataSource.newsTitle;
}

@end
