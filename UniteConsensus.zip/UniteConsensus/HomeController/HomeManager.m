//
//  HomeManager.m
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "HomeManager.h"

@implementation HomeManager

- (instancetype)init {
    
    self = [super init];
    
    if (self)
    {
        _listBanner = [[NSArray alloc] init];
        _listContent = [[NSArray alloc] init];
    }
    
    return self;
}

- (void)requstInfomation:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@%@",kConsensusHost,@"api.APITouTiao/select?cat=2"];
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
        NSArray *array = [result.resultData customForKey:@"data"];
        
        if ([BKCheckValid checkArrayValid:array])
        {
            NSMutableArray *mBanner = [[NSMutableArray alloc] init];
            NSMutableArray *mContent = [[NSMutableArray alloc] init];
            
            for (int index=0;index<array.count;index++)
            {
                if (index<=0)
                {
                    HomeDataSource *data = [[HomeDataSource alloc] init];
                    [data resolutionHomeDataSource:[array objectAtIndex:index]];
                    [mBanner addObject:data];
                }
                else
                {
                    HomeDataSource *data = [[HomeDataSource alloc] init];
                    [data resolutionHomeDataSource:[array objectAtIndex:index]];
                    [mContent addObject:data];
                }
            }
            
            self.listBanner = mBanner;
            self.listContent = mContent;
        }
        
        if (retHandler)
        {
            retHandler(result);
        }
    }
    failure:^(HTTPDetails *result)
    {
        if (retHandler)
        {
            retHandler(result);
        }
    }];
}

@end
