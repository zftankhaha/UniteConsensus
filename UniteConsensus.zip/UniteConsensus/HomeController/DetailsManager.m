//
//  DetailsManager.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "DetailsManager.h"

@implementation DetailsManager

- (void)requstInfomation:(void(^)(HTTPDetails *result))retHandler {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    details.requestUrl = [NSString stringWithFormat:@"%@api.APICoin/dailyRewards",kConsensusHost];
    
    [CommonConnection requestData:self details:details success:^(HTTPDetails *result)
    {
         if (retHandler)
         {
             retHandler(result);
         }
    }
    failure:^(HTTPDetails *result)
    {
         if (retHandler)
         {
             retHandler(result);
         }
    }];
}

@end
