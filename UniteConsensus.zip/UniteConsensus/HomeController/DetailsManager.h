//
//  DetailsManager.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/4.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "NSModelManager.h"

@interface DetailsManager : NSModelManager

- (void)requstInfomation:(void(^)(HTTPDetails *result))retHandler;

@end
