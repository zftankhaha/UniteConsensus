//
//  HomeViewCell.h
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeDataSource.h"

#define kHomeCellHeight   90

@interface HomeViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *showView;

@property (nonatomic,strong) UILabel *showTitle;

- (void)refreshViewSource:(HomeDataSource *)dataSource;

@end
