//
//  HomeViewController.h
//  UniteConsensus
//
//  Created by zftank on 2020/7/10.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
