//
//  UIAnnularView.m
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import "UIAnnularView.h"

static NSNumber *numberCount;

#define kDefaultDuration    180

@interface UIAnnularView () <CAAnimationDelegate>

@property (nonatomic,strong) CAShapeLayer *circleLayer;

@property (nonatomic,strong) UILabel *showTitle;

@property (nonatomic,strong) CTimerManager *timer;

@end

@implementation UIAnnularView

+ (void)initialize {
    
    numberCount = [NSNumber numberWithInteger:kDefaultDuration];
}

+ (NSNumber *)currentCount {
    
    return numberCount;
}

- (void)dealloc {
    
    [self closeAnnularAnimation];
}

- (void)startAnnularAnimation:(NSNumber *)duration {

    numberCount = duration;
    
    [self closeAnnularAnimation];
    
    self.circleLayer = [CAShapeLayer layer];
    self.circleLayer.strokeStart = 0.0f;
    self.circleLayer.strokeEnd = 1.0f;
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.frame.size.width/2,self.frame.size.height/2)
                                                        radius:self.frame.size.width/2
                                                    startAngle:1.5*M_PI
                                                      endAngle:3.5*M_PI clockwise:YES];
    
    self.circleLayer.path = path.CGPath;
    self.circleLayer.fillColor = [UIColor clearColor].CGColor;
    self.circleLayer.lineWidth = 2.0f;
    self.circleLayer.strokeColor = kBackBColor.CGColor;
    
    CABasicAnimation *basicAnimation = [CABasicAnimation animationWithKeyPath:@"strokeStart"];
    basicAnimation.fromValue = @(0.0);
    basicAnimation.toValue = @(1.0);
    basicAnimation.duration = numberCount.integerValue;
    basicAnimation.fillMode = kCAFillModeForwards;
    basicAnimation.removedOnCompletion = NO;
    [self.circleLayer addAnimation:basicAnimation forKey:nil];
    [self.layer addSublayer:self.circleLayer];
    
    //倒计时
    self.showTitle = [[UILabel alloc] initWithFrame:CGRectMake(0,0,self.width,self.height)];
    self.showTitle.backgroundColor = [UIColor clearColor];
    self.showTitle.textColor = kDefaultRedColor;
    self.showTitle.font = CommonFontLight(18);
    self.showTitle.textAlignment = NSTextAlignmentCenter;
    self.showTitle.text = [NSString stringWithFormat:@"%lis",numberCount.integerValue];
    [self addSubview:self.showTitle];
    
    //启动倒计时
    [self.timer startCountTimer];
}

- (CTimerManager *)timer {
    
    if (!_timer)
    {
        _timer = [[CTimerManager alloc] initDelegate:self step:1];
    }
    
    return _timer;
}

- (void)touchTimerAction {
    
    NSInteger inte = numberCount.integerValue;
    --inte;numberCount = [NSNumber numberWithInteger:inte];
    
    self.showTitle.text = [NSString stringWithFormat:@"%@s",numberCount];
    
    if (0 == inte)
    {
        [self closeAnnularAnimation];
        numberCount = [NSNumber numberWithInteger:kDefaultDuration];
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(completionAnnularAnimation)])
        {
            [self.delegate completionAnnularAnimation];
        }
    }
}

- (void)closeAnnularAnimation {
    
    [self.circleLayer removeAllAnimations];
    [self.circleLayer removeFromSuperlayer];
    self.circleLayer = nil;
    
    [self.showTitle removeFromSuperview];
    
    [self.timer stopTimer];
}

@end
