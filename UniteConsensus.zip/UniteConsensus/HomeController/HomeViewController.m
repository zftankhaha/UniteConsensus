//
//  HomeViewController.m
//  UniteConsensus
//
//  Created by zftank on 2020/7/10.
//  Copyright © 2020 UniteConsensus. All rights reserved.
//

#import "HomeViewController.h"
#import "DetailsViewController.h"
#import "HomeViewCell.h"
#import "XLCycleView.h"
#import "HomeManager.h"

@interface HomeViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) XLCycleView *cycleView;

@property (nonatomic,strong) UITableView *listView;

@property (nonatomic,strong) HomeManager *homeManager;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.showHeaderBar = NO;
    
    [self.view addSubview:self.listView];
    
    [self refreshDataSource:YES];
}

- (void)refreshDataSource:(BOOL)refreshDrop {
    
    [self.homeManager requstInfomation:^(HTTPDetails *result)
    {
        [self.listView completeLoading:NO];

        if (result.success)
        {
            [self.cycleView reloadData:self.homeManager.listBanner duration:6];
            [self.listView reloadData];
        }
    }];
}

#pragma mark -
#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.homeManager.listContent.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeViewCell *myCell = [HomeViewCell cellWithTableView:tableView];
    [myCell refreshViewSource:[self.homeManager.listContent objectAtIndex:indexPath.row]];
    return myCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DetailsViewController *detailsController = [[DetailsViewController alloc] init];
    [self.navigationController pushViewController:detailsController animated:YES];
}

#pragma mark -
#pragma mark XLCycleView Delegate

- (void)showView:(UIImageView *)showView title:(UILabel *)title atIndex:(NSInteger)index {
    
    HTTPDetails *details = [[HTTPDetails alloc] init];
    HomeDataSource *dataSource = [self.homeManager.listBanner objectAtIndex:index];
    details.requestUrl = dataSource.newsImage1;
    details.siteImage = [UIImage imageNamed:@"acMiner"];
    details.defaultMode = UIViewContentModeCenter;
    [showView setImage:details cumulation:nil success:nil failure:nil];
}

- (void)xlcycleView:(XLCycleView *)cycleView didSelectAtIndex:(NSInteger)index {
    
    DetailsViewController *detailsController = [[DetailsViewController alloc] init];
    [self.navigationController pushViewController:detailsController animated:YES];
}

#pragma mark -
#pragma mark Get/Set

- (UITableView *)listView {
    
    if (!_listView)
    {
        CGRect listRect = CGRectMake(0,StatusBar_HEIGHT,SCREEN_WIDTH,SCREEN_HEIGHT-TabBar_HEIGHT-StatusBar_HEIGHT);
        _listView = [[UITableView alloc] initWithFrame:listRect style:UITableViewStylePlain];
        _listView.backgroundColor = [UIColor clearColor];
        _listView.delegate = self;
        _listView.dataSource = self;
        _listView.rowHeight = kHomeCellHeight;
        _listView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listView.showsVerticalScrollIndicator = NO;
        
        [_listView refresh:self header:YES footer:NO];
        
        _cycleView = [XLCycleView showView:CGRectMake(0,0,SCREEN_WIDTH,150) style:0];
        _cycleView.backgroundColor = [UIColor clearColor];
        _cycleView.delegate = self;_listView.tableHeaderView = _cycleView;
        
        //加载分割线
        _listView.tableFooterView = [UIView drawHTLine:CGRectMake(0,0,SCREEN_WIDTH,kLineSpace) color:nil];
    }
    
    return _listView;
}

- (HomeManager *)homeManager {
    
    if (!_homeManager)
    {
        _homeManager = [[HomeManager alloc] init];
    }
    
    return _homeManager;
}

@end
