//
//  HomeDataSource.h
//  Follow
//
//  Created by zftank on 2020/6/27.
//  Copyright © 2020 zftank. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeDataSource : NSObject

@property (nonatomic,copy) NSString *newsTitle;

@property (nonatomic,copy) NSString *newsImage1;

@property (nonatomic,copy) NSString *newsImage2;

@property (nonatomic,copy) NSString *newsImage3;

@property (nonatomic,copy) NSString *detailsUrl;

- (void)resolutionHomeDataSource:(id)dataSource;

@end
